const LOCAL_IP = "127.0.0.1"
const API_PORT = "5001"

export const API_BASE = `http://${LOCAL_IP}:${API_PORT}`

export default {
  LOCAL_IP,
  API_PORT,
  API_BASE
}
