import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

import Layout from '@/components/Layout/Layout.vue'

export default new Router({

  mode: 'hash',

  routes: [

    // =====================
    // 登录页
    // =====================

    {
      path: '/login',
      component: () => import('@/views/login/index.vue')
    },

    // =====================
    // 后台主界面
    // =====================

    {
      path: '/',

      component: Layout,

      redirect: '/dashboard',

      children: [

        {
          path: 'dashboard',
          component: () => import('@/views/dashboard/index.vue')
        },

        {
          path: 'prototype/manage',
          component: () => import('@/views/prototype/index.vue')
        },

        {
          path: 'asset/list',
          component: () => import('@/views/asset/assetList.vue')
        },

        {
          path: 'asset/materials',
          component: () => import('@/views/dashboard/index.vue')
        },

        {
          path: 'asset/catalog',
          component: () => import('@/views/catalog/index.vue')
        },

        {
          path: 'asset/inventory',
          component: () => import('@/views/inventory/index.vue')
        },

        {
          path: 'asset/prototype',
          component: () => import('@/views/prototype/index.vue')
        },

        {
          path: 'asset/add',
          component: () => import('@/views/asset/assetAdd.vue')
        },

        {
          path: 'warehouse/in',
          component: () => import('@/views/warehouse/inStock.vue')
        },

        {
          path: 'warehouse/out',
          component: () => import('@/views/warehouse/outStock.vue')
        },

        {
          path: 'user/list',
          component: () => import('@/views/user/userList.vue')
        },

        {
          path: 'agent',
          component: () => import('@/views/agent/index.vue')
        },

        {
          path: 'project/resource',
          component: () => import('@/views/projectScrap/index.vue')
        },

        {
          path: 'project/scrap',
          redirect: '/project/resource'
        },

        {
          path: 'log',
          component: () => import('@/views/log/operationLog.vue')
        },

        {
          path: 'setting',
          component: () => import('@/views/setting/systemSetting.vue')
        }

      ]

    }

  ]

})
