export function isSameData(currentData, nextData) {
  return JSON.stringify(currentData) === JSON.stringify(nextData)
}
