<template>
    <router-view />
</template>

<script>
// import Layout from './components/Layout/Layout.vue'

export default {
  // components: { Layout }
}
</script>