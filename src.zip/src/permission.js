import router from './router'

router.beforeEach((to, from, next) => {

  // 登录页直接放行
  if (to.path === '/login') {

    next()

    return
  }

  // 获取用户信息
  const user = localStorage.getItem("user")

  // 未登录
  if (!user) {

    next('/login')

    return
  }

  // 已登录
  next()

})