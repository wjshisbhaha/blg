<template>
  <div class="login-box">

    <el-card class="card">

      <h2 class="title">
        台账管理系统
      </h2>

      <!-- 工号 -->
      <el-input
        v-model="form.username"
        placeholder="请输入工号"
        style="margin-bottom: 20px"
      />

      <!-- 密码 -->
      <el-input
        v-model="form.password"
        placeholder="请输入密码"
        show-password
        style="margin-bottom: 20px"
      />

      <!-- 登录 -->
      <el-button
        type="primary"
        style="width:100%"
        @click="login"
      >
        登录
      </el-button>

    </el-card>

  </div>
</template>

<script>

import axios from "axios"
import { API_BASE } from "../../config/appConfig"

export default {

  data() {
    return {

      form: {
        username: "",
        password: ""
      }

    }
  },

  methods: {

    login() {

      // 简单验证
      const loginForm = {
        username: (this.form.username || "").trim(),
        password: (this.form.password || "").trim()
      }

      if (!loginForm.username) {

        this.$message.error("请输入工号")

        return
      }

      if (!loginForm.password) {

        this.$message.error("请输入密码")

        return
      }

      // 请求后端
      axios.post(
        `${API_BASE}/login`,
        loginForm
      ).then(res => {

        console.log(res.data)

        // 登录成功
        if (res.data.code === 200) {

          // ======================
          // 保存用户信息
          // ======================

          localStorage.setItem(
            "user",
            JSON.stringify(res.data.data)
          )

          // ======================
          // 提示
          // ======================

          this.$message.success("登录成功")

          // ======================
          // 跳转首页
          // ======================

          this.$router.push("/dashboard")

        } else {

          this.$message.error(res.data.msg)

        }

      }).catch(err => {

        console.log(err)

        this.$message.error("服务器连接失败")

      })

    }

  }

}
</script>

<style scoped>

.login-box {

  width: 100%;
  height: 100vh;

  display: flex;

  justify-content: center;
  align-items: center;

  background: #2d3a4b;
}

.card {

  width: 400px;

  padding: 30px;
}

.title {

  text-align: center;

  margin-bottom: 30px;
}

</style>
