<template>

  <div>

    <el-card>

      <div slot="header">
        资产列表
      </div>

      <!-- 搜索 -->
      <el-form inline>

        <el-form-item>
          <el-input
            placeholder="请输入资产名称"
          />
        </el-form-item>

        <el-form-item>
          <el-button type="primary">
            搜索
          </el-button>
        </el-form-item>

      </el-form>

      <!-- 表格 -->
      <el-table
        :data="tableData"
        border
        style="width:100%"
      >

        <el-table-column
          prop="id"
          label="ID"
          width="80"
        />

        <el-table-column
          prop="name"
          label="资产名称"
        />

        <el-table-column
          prop="category"
          label="分类"
        />

        <el-table-column
          prop="status"
          label="状态"
        />

        <el-table-column
          label="操作"
          width="220"
        >

          <template slot-scope="scope">

            <el-button
              type="primary"
              size="mini"
            >
              编辑
            </el-button>

            <el-button
              type="danger"
              size="mini"
            >
              删除
            </el-button>

          </template>

        </el-table-column>

      </el-table>

    </el-card>

  </div>

</template>

<script>
export default {

  data() {
    return {

      tableData: [
        {
          id: 1,
          name: 'PI六轴平台',
          category: '运动控制',
          status: '正常'
        },
        {
          id: 2,
          name: 'AQ6370D',
          category: '光谱仪',
          status: '使用中'
        }
      ]

    }
  }

}
</script>