<template>

  <div>

    <el-card>

      <div
        slot="header"
        class="card-header"
      >
        <span>用户列表</span>

        <div class="header-actions">
          <el-button
            v-if="isAdmin"
            size="small"
            icon="el-icon-document"
            @click="downloadTemplate"
          >
            导入模板
          </el-button>

          <el-upload
            v-if="isAdmin"
            action="#"
            :auto-upload="false"
            :show-file-list="false"
            accept=".csv"
            :on-change="handleImportChange"
          >
            <el-button
              size="small"
              icon="el-icon-upload"
            >
              导入
            </el-button>
          </el-upload>

          <el-button
            size="small"
            icon="el-icon-download"
            @click="exportUsers"
          >
            导出
          </el-button>

          <el-button
            type="primary"
            size="small"
            icon="el-icon-plus"
            @click="openAddDialog"
          >
            新增用户
          </el-button>
        </div>
      </div>

      <el-table
        v-loading="loading"
        :data="tableData"
        border
        style="width:100%"
      >

        <el-table-column
          prop="username"
          label="工号"
        />

        <el-table-column
          prop="name"
          label="姓名"
        />

        <el-table-column
          prop="engineer"
          label="工程师"
        />

        <el-table-column
          prop="team"
          label="所在团队"
        />

        <el-table-column
          prop="email"
          label="邮箱"
          min-width="180"
          show-overflow-tooltip
        />

        <el-table-column
          prop="category"
          label="类别"
          width="100"
        />

        <el-table-column
          label="权限"
          width="240"
        >
          <template slot-scope="scope">
            <div class="permission-tags">
              <el-tag :type="permissionTagType(scope.row.permissions)">
                {{ permissionText(scope.row.permissions) }}
              </el-tag>
              <el-tag
                v-for="role in additionalRoleList(scope.row.additionalRole)"
                :key="role"
                type="success"
              >
                {{ role }}
              </el-tag>
            </div>
          </template>
        </el-table-column>

        <el-table-column
          label="操作"
          width="360"
        >
          <template slot-scope="scope">
            <el-button
              type="primary"
              size="mini"
              @click="openPermissionDialog(scope.row)"
            >
              修改权限
            </el-button>

            <el-button
              type="warning"
              size="mini"
              @click="openResetPasswordDialog(scope.row)"
            >
              重置密码
            </el-button>

            <el-button
              type="danger"
              size="mini"
              @click="deleteUser(scope.row)"
            >
              删除
            </el-button>
          </template>
        </el-table-column>

      </el-table>

    </el-card>

    <el-dialog
      title="新增用户"
      :visible.sync="addDialogVisible"
      width="420px"
      @close="resetAddForm"
    >
      <el-form
        ref="addForm"
        :model="addForm"
        :rules="addRules"
        label-width="80px"
      >
        <el-form-item
          label="工号"
          prop="username"
        >
          <el-input
            v-model="addForm.username"
            autocomplete="off"
          />
        </el-form-item>

        <el-form-item
          label="姓名"
          prop="name"
        >
          <el-input
            v-model="addForm.name"
            autocomplete="off"
          />
        </el-form-item>

        <el-form-item
          label="密码"
          prop="password"
        >
          <el-input
            v-model="addForm.password"
            show-password
            autocomplete="off"
          />
        </el-form-item>

        <el-form-item
          label="权限"
          prop="permissions"
        >
          <el-select
            v-model="addForm.permissions"
            style="width:100%"
            @change="handleAddPermissionChange"
          >
            <el-option
              v-for="item in permissionOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="工程师" prop="engineer">
          <el-input
            v-model="addForm.engineer"
            autocomplete="off"
          />
        </el-form-item>

        <el-form-item label="类别">
          <el-select v-model="addForm.category" style="width:100%" @change="handleAddCategoryChange">
            <el-option label="技师" value="技师" />
            <el-option label="工程师" value="工程师" />
          </el-select>
        </el-form-item>

        <el-form-item label="附加角色">
          <el-select v-model="addForm.additionalRole" multiple collapse-tags clearable style="width:100%">
            <el-option label="项目经理" value="项目经理" />
            <el-option label="交付接口人" value="交付接口人" />
            <el-option label="复盘人" value="复盘人" />
            <el-option label="实验室主任" value="实验室主任" />
            <el-option label="高级专家" value="高级专家" />
          </el-select>
        </el-form-item>

        <el-form-item label="所在团队">
          <el-select
            v-model="addForm.team"
            filterable
            allow-create
            clearable
            default-first-option
            style="width:100%"
          >
            <el-option
              v-for="team in teamOptions"
              :key="team"
              :label="team"
              :value="team"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="邮箱">
          <el-input
            v-model="addForm.email"
            autocomplete="off"
          />
        </el-form-item>
      </el-form>

      <span slot="footer">
        <el-button @click="addDialogVisible = false">
          取消
        </el-button>

        <el-button
          type="primary"
          @click="addUser"
        >
          保存
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="修改用户信息"
      :visible.sync="permissionDialogVisible"
      width="420px"
    >
      <el-form label-width="80px">
        <el-form-item label="工号">
          <el-input
            v-model="currentUser.username"
            disabled
          />
        </el-form-item>

        <el-form-item label="姓名">
          <el-input
            v-model="permissionForm.name"
          />
        </el-form-item>

        <el-form-item label="权限">
          <el-select
            v-model="permissionForm.permissions"
            style="width:100%"
          >
            <el-option
              v-for="item in permissionOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="工程师">
          <el-input
            v-model="permissionForm.engineer"
          />
        </el-form-item>

        <el-form-item label="类别">
          <el-select v-model="permissionForm.category" style="width:100%">
            <el-option label="技师" value="技师" />
            <el-option label="工程师" value="工程师" />
          </el-select>
        </el-form-item>

        <el-form-item label="附加角色">
          <el-select v-model="permissionForm.additionalRole" multiple collapse-tags clearable style="width:100%">
            <el-option label="项目经理" value="项目经理" />
            <el-option label="交付接口人" value="交付接口人" />
            <el-option label="复盘人" value="复盘人" />
            <el-option label="实验室主任" value="实验室主任" />
            <el-option label="高级专家" value="高级专家" />
          </el-select>
        </el-form-item>

        <el-form-item label="所在团队">
          <el-select
            v-model="permissionForm.team"
            filterable
            allow-create
            clearable
            default-first-option
            style="width:100%"
          >
            <el-option
              v-for="team in teamOptions"
              :key="team"
              :label="team"
              :value="team"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="邮箱">
          <el-input v-model="permissionForm.email" />
        </el-form-item>
      </el-form>

      <span slot="footer">
        <el-button @click="permissionDialogVisible = false">
          取消
        </el-button>

        <el-button
          type="primary"
          @click="updatePermission"
        >
          保存
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="重置密码"
      :visible.sync="resetPasswordDialogVisible"
      width="420px"
      @close="resetPasswordForm"
    >
      <el-form
        ref="resetPasswordForm"
        :model="resetPasswordForm"
        :rules="resetPasswordRules"
        label-width="90px"
      >
        <el-form-item label="工号">
          <el-input
            v-model="currentUser.username"
            disabled
          />
        </el-form-item>

        <el-form-item
          label="新密码"
          prop="password"
        >
          <el-input
            v-model="resetPasswordForm.password"
            show-password
            autocomplete="off"
          />
        </el-form-item>
      </el-form>

      <span slot="footer">
        <el-button @click="resetPasswordDialogVisible = false">
          取消
        </el-button>

        <el-button
          type="primary"
          @click="resetUserPassword"
        >
          保存
        </el-button>
      </span>
    </el-dialog>

  </div>

</template>

<script>
import axios from "axios"
import { API_BASE } from "../../config/appConfig"
import { isSameData } from "../../utils/dataChange"

export default {

  data() {
    return {
      loading: false,
      tableData: [],
      addDialogVisible: false,
      permissionDialogVisible: false,
      resetPasswordDialogVisible: false,
      currentUser: {},
      user: {},
      refreshTimer: null,
      teamOptions: [
        "星际光",
        "成像光",
        "空间光",
        "光电封装"
      ],
      addForm: {
        username: "",
        name: "",
        password: "",
        permissions: 0,
        engineer: "",
        team: "",
        email: "",
        category: "技师",
        additionalRole: []
      },
      permissionForm: {
        name: "",
        permissions: 0,
        engineer: "",
        team: "",
        email: "",
        category: "技师",
        additionalRole: []
      },
      resetPasswordForm: {
        password: ""
      },
      addRules: {
        username: [
          { required: true, message: "请输入工号", trigger: "blur" }
        ],
        password: [
          { required: true, message: "请输入密码", trigger: "blur" },
          { min: 6, message: "密码至少6位", trigger: "blur" }
        ],
        permissions: [
          { required: true, message: "请选择权限", trigger: "change" }
        ],
        engineer: [
          { validator: this.validateAddEngineer, trigger: "blur" },
          { validator: this.validateAddEngineer, trigger: "change" }
        ]
      },
      resetPasswordRules: {
        password: [
          { required: true, message: "请输入新密码", trigger: "blur" },
          { min: 6, message: "新密码至少6位", trigger: "blur" }
        ]
      }
    }
  },

  created() {
    const user = localStorage.getItem("user")

    if (user) {
      this.user = JSON.parse(user)
    }

    this.getUserList()
    this.getTeamOptions()
    this.refreshTimer = setInterval(() => this.getUserList(true), 15000)
  },

  beforeDestroy() {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer)
    }
  },

  computed: {
    isAdmin() {
      return Number(this.user.permissions) === 1
    },

    permissionOptions() {
      const permission = Number(this.user.permissions)

      return [
        { label: "管理员", value: 1 },
        { label: "普通用户", value: 0 }
      ]
    }
  },

  methods: {

    getUserList(silent = false) {
      silent = silent === true
      if (!silent) {
        this.loading = true
      }

      axios.get(`${API_BASE}/user/list`, {
        params: {
          permissions: this.user.permissions,
          team: this.user.team
        }
      }).then(res => {
        if (res.data.code === 200) {
          const nextData = res.data.data || []
          if (!isSameData(this.tableData, nextData)) {
            this.tableData = nextData
          }
        } else if (!silent) {
          this.$message.error(res.data.msg)
        }
      }).catch(err => {
        console.log(err)
        if (!silent) {
          this.$message.error("服务器连接失败")
        }
      }).finally(() => {
        if (!silent) {
          this.loading = false
        }
      })
    },

    openAddDialog() {
      this.addDialogVisible = true
    },

    handleAddPermissionChange() {},

    getTeamOptions() {
      axios.get(`${API_BASE}/user/team_engineers`).then(res => {
        if (res.data.code === 200) {
          this.teamOptions = ["星际光", "成像光", "空间光", "光电封装"]
        }
      }).catch(() => {})
    },

    addUser() {
      this.$refs.addForm.validate(valid => {
        if (!valid) {
          return
        }

        axios.post(
          `${API_BASE}/user/add`,
          this.addForm
        ).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.addDialogVisible = false
            this.getUserList()
          } else {
            this.$message.error(res.data.msg)
          }
        }).catch(err => {
          console.log(err)
          this.$message.error("服务器连接失败")
        })
      })
    },

    validateAddEngineer(rule, value, callback) {
      if (this.addForm.category === "技师" && !value) {
        callback(new Error("技师必须填写工程师"))
        return
      }

      callback()
    },

    handleAddCategoryChange() {
      if (this.$refs.addForm) {
        this.$refs.addForm.validateField("engineer")
      }
    },

    openPermissionDialog(row) {
      this.currentUser = Object.assign({}, row)
      this.permissionForm = {
        name: row.name || "",
        permissions: row.permissions,
        engineer: row.engineer || "",
        team: row.team || "",
        email: row.email || "",
        category: row.category || "技师",
        additionalRole: this.additionalRoleList(row.additionalRole)
      }
      this.permissionDialogVisible = true
    },

    updatePermission() {
      const additionalRole = this.roleArrayToString(this.permissionForm.additionalRole)

      axios.post(
        `${API_BASE}/user/update_info`,
        {
          id: this.currentUser.id,
          name: this.permissionForm.name,
          permissions: this.permissionForm.permissions,
          engineer: this.permissionForm.engineer,
          team: this.permissionForm.team,
          email: this.permissionForm.email,
          category: this.permissionForm.category,
          additionalRole
        }
      ).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          if (this.currentUser.username === this.user.username) {
            this.user = Object.assign({}, this.user, this.permissionForm, { additionalRole })
            localStorage.setItem("user", JSON.stringify(this.user))
          }
          this.permissionDialogVisible = false
          this.getUserList()
        } else {
          this.$message.error(res.data.msg)
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("服务器连接失败")
      })
    },

    permissionText(value) {
      const permission = Number(value)

      if (permission === 1) {
        return "管理员"
      }

      return "普通用户"
    },

    permissionTagType(value) {
      const permission = Number(value)

      if (permission === 1) {
        return "danger"
      }

      return "success"
    },

    openResetPasswordDialog(row) {
      this.currentUser = Object.assign({}, row)
      this.resetPasswordDialogVisible = true
    },

    resetUserPassword() {
      this.$refs.resetPasswordForm.validate(valid => {
        if (!valid) {
          return
        }

        axios.post(
          `${API_BASE}/user/reset_password`,
          {
            id: this.currentUser.id,
            password: this.resetPasswordForm.password
          }
        ).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.resetPasswordDialogVisible = false
          } else {
            this.$message.error(res.data.msg)
          }
        }).catch(err => {
          console.log(err)
          this.$message.error("服务器连接失败")
        })
      })
    },

    deleteUser(row) {
      this.$confirm(
        `确认删除用户 ${row.username}？`,
        "提示",
        {
          type: "warning"
        }
      ).then(() => {
        axios.delete(
          `${API_BASE}/user/delete/${row.id}`
        ).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.getUserList()
          } else {
            this.$message.error(res.data.msg)
          }
        }).catch(err => {
          console.log(err)
          this.$message.error("服务器连接失败")
        })
      }).catch(() => {})
    },

    handleImportChange(file) {
      const formData = new FormData()
      formData.append("file", file.raw)
      formData.append("permissions", this.user.permissions)
      formData.append("team", this.user.team || "")

      axios.post(
        `${API_BASE}/user/import`,
        formData
      ).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.getUserList()
          this.getTeamOptions()
        } else {
          this.$message.error(res.data.msg)
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("导入失败，请检查文件格式")
      })
    },

    exportUsers() {
      axios.get(`${API_BASE}/user/export`, {
        params: {
          permissions: this.user.permissions,
          team: this.user.team
        },
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `用户列表_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      }).catch(err => {
        console.log(err)
        this.$message.error("导出失败，请检查后端是否启动")
      })
    },

    downloadTemplate() {
      axios.get(`${API_BASE}/user/template`, {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `用户导入模板_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      }).catch(err => {
        console.log(err)
        this.$message.error("模板下载失败，请检查后端是否启动")
      })
    },

    formatExportTime() {
      const date = new Date()
      const pad = value => String(value).padStart(2, "0")

      return [
        date.getFullYear(),
        pad(date.getMonth() + 1),
        pad(date.getDate())
      ].join("") + "_" + [
        pad(date.getHours()),
        pad(date.getMinutes()),
        pad(date.getSeconds())
      ].join("")
    },

    resetAddForm() {
      this.addForm = {
        username: "",
        name: "",
        password: "",
        permissions: 0,
        engineer: "",
        team: "",
        email: "",
        category: "技师",
        additionalRole: []
      }

      if (this.$refs.addForm) {
        this.$refs.addForm.clearValidate()
      }
    },

    resetPasswordForm() {
      this.resetPasswordForm = {
        password: ""
      }

      if (this.$refs.resetPasswordForm) {
        this.$refs.resetPasswordForm.clearValidate()
      }
    },

    additionalRoleList(value) {
      if (Array.isArray(value)) {
        return value.filter(Boolean)
      }

      return String(value || "")
        .replace(/[，、；;|/\s]+/g, ",")
        .split(",")
        .map(item => item.trim())
        .filter(Boolean)
    },

    roleArrayToString(value) {
      return this.additionalRoleList(value).join(",")
    }

  }

}
</script>

<style scoped>

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
}

.header-actions .el-button {
  margin-left: 0;
}

.permission-tags {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 6px;
}

</style>
