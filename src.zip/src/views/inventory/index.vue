<template>
  <div class="inventory-page">
    <el-card shadow="never">
      <div slot="header" class="inventory-header">
        <span>盘点管理</span>
        <div class="header-actions">
          <template v-if="isAdmin">
            <span class="cycle-label">盘点时间</span>
            <el-input-number
              v-model="cycleValue"
              size="small"
              :min="1"
              :precision="0"
              :step="1"
              class="cycle-input"
            />
            <el-select v-model="cycleUnit" size="small" class="cycle-unit">
              <el-option label="分钟" value="minute" />
              <el-option label="月" value="month" />
            </el-select>
            <el-button size="small" @click="saveCycle">保存时间</el-button>
            <el-button size="small" type="primary" @click="generateInventory">生成盘点表单</el-button>
          </template>
        </div>
      </div>

      <div class="inventory-filter">
        <el-form :inline="true" :model="searchForm" size="small">
          <el-form-item label="项目">
            <el-input v-model.trim="searchForm.projectName" clearable placeholder="项目" @keyup.enter.native="fetchCurrentData" />
          </el-form-item>
          <el-form-item label="名称">
            <el-input v-model.trim="searchForm.itemName" clearable placeholder="物料/样机名称" @keyup.enter.native="fetchCurrentData" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="fetchCurrentData">搜索</el-button>
            <el-button @click="resetSearch">重置</el-button>
          </el-form-item>
        </el-form>
      </div>

      <el-tabs v-model="activeTab" @tab-click="handleTabChanged">
        <el-tab-pane label="物料盘点" name="materialTasks">
          <el-table v-loading="loading" :data="taskRows" border height="560" style="width:100%" :row-class-name="inventoryRowClassName">
            <el-table-column prop="sourceType" label="类型" width="90" />
            <el-table-column label="盘点结果" width="110">
              <template slot-scope="scope">
                <el-tag v-if="scope.row.result" :type="resultTagType(scope.row.result)" size="small">{{ scope.row.result }}</el-tag>
                <span v-else>-</span>
              </template>
            </el-table-column>
            <el-table-column prop="status" label="盘点状态" width="110" />
            <el-table-column prop="projectName" label="项目" min-width="150" show-overflow-tooltip />
            <el-table-column prop="itemSource" label="物品来源" width="120" />
            <el-table-column prop="receiveCode" label="领用编码" width="130" show-overflow-tooltip />
            <el-table-column prop="itemName" label="名称" min-width="180" show-overflow-tooltip />
            <el-table-column prop="catlogCode" label="catlog编码" width="130" show-overflow-tooltip />
            <el-table-column prop="orderNumber" label="领料单号" width="130" show-overflow-tooltip />
            <el-table-column prop="unitPrice" label="单价" width="90" />
            <el-table-column prop="owner" label="所有者" width="120" />
            <el-table-column prop="entryPerson" label="录入人" width="100" />
            <el-table-column prop="team" label="所属团队" width="110" />
            <el-table-column prop="engineer" label="工程师" width="100" />
            <el-table-column prop="reviewOwner" label="负责复盘人" width="120" />
            <el-table-column prop="totalQuantity" label="总数" width="90" :formatter="integerFormatter" />
            <el-table-column prop="actualQuantity" label="实际数量" width="110" :formatter="integerFormatter" />
            <el-table-column prop="checkQuantity" label="盘点数量" width="110" :formatter="integerFormatter" />
            <el-table-column prop="storageLocation" label="存放位置" min-width="140" show-overflow-tooltip />
            <el-table-column prop="materialProvider" label="物料提供人" width="120" show-overflow-tooltip />
            <el-table-column prop="materialRecipient" label="物料领取人" width="120" show-overflow-tooltip />
            <el-table-column prop="usageStatus" label="使用状态" width="100" />
            <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
            <el-table-column prop="entryRemark" label="备注" min-width="160" show-overflow-tooltip />
            <el-table-column prop="createdAt" label="发起时间" width="170" />
            <el-table-column label="操作" fixed="right" width="180">
              <template slot-scope="scope">
                <el-button v-if="canSubmit(scope.row)" size="mini" type="primary" @click="openSubmitDialog(scope.row)">盘点</el-button>
                <el-button v-if="canReviewRow(scope.row)" size="mini" type="success" @click="reviewTask(scope.row)">复盘</el-button>
                <el-button size="mini" @click="openRecordDialog(scope.row)">记录</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="物料盘点记录" name="materialRecords">
          <el-table v-loading="loading" :data="recordRows" border height="560" style="width:100%" :row-class-name="inventoryRowClassName">
            <el-table-column prop="sourceType" label="类型" width="90" />
            <el-table-column label="盘点结果" width="110">
              <template slot-scope="scope">
                <el-tag v-if="scope.row.result" :type="resultTagType(scope.row.result)" size="small">{{ scope.row.result }}</el-tag>
                <span v-else>-</span>
              </template>
            </el-table-column>
            <el-table-column prop="status" label="盘点状态" width="110" />
            <el-table-column prop="projectName" label="项目" min-width="150" show-overflow-tooltip />
            <el-table-column prop="itemSource" label="物品来源" width="120" />
            <el-table-column prop="receiveCode" label="领用编码" width="130" show-overflow-tooltip />
            <el-table-column prop="itemName" label="名称" min-width="180" show-overflow-tooltip />
            <el-table-column prop="catlogCode" label="catlog编码" width="130" show-overflow-tooltip />
            <el-table-column prop="orderNumber" label="领料单号" width="130" show-overflow-tooltip />
            <el-table-column prop="unitPrice" label="单价" width="90" />
            <el-table-column prop="owner" label="所有者" width="120" />
            <el-table-column prop="entryPerson" label="录入人" width="100" />
            <el-table-column prop="team" label="所属团队" width="110" />
            <el-table-column prop="engineer" label="工程师" width="100" />
            <el-table-column prop="reviewOwner" label="负责复盘人" width="120" />
            <el-table-column prop="totalQuantity" label="总数" width="90" :formatter="integerFormatter" />
            <el-table-column prop="actualQuantity" label="实际数量" width="110" :formatter="integerFormatter" />
            <el-table-column prop="checkQuantity" label="盘点数量" width="110" :formatter="integerFormatter" />
            <el-table-column prop="storageLocation" label="存放位置" min-width="140" show-overflow-tooltip />
            <el-table-column prop="materialProvider" label="物料提供人" width="120" show-overflow-tooltip />
            <el-table-column prop="materialRecipient" label="物料领取人" width="120" show-overflow-tooltip />
            <el-table-column prop="usageStatus" label="使用状态" width="100" />
            <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
            <el-table-column prop="entryRemark" label="备注" min-width="160" show-overflow-tooltip />
            <el-table-column prop="checkedAt" label="盘点时间" width="170" />
            <el-table-column prop="reviewer" label="实际复盘人" width="120" />
            <el-table-column prop="reviewedAt" label="复盘时间" width="170" />
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="样机盘点" name="prototypeTasks">
          <el-table v-loading="loading" :data="taskRows" border height="560" style="width:100%" :row-class-name="inventoryRowClassName">
            <el-table-column prop="sourceType" label="类型" width="90" />
            <el-table-column label="盘点结果" width="110">
              <template slot-scope="scope">
                <el-tag v-if="scope.row.result" :type="resultTagType(scope.row.result)" size="small">{{ scope.row.result }}</el-tag>
                <span v-else>-</span>
              </template>
            </el-table-column>
            <el-table-column prop="status" label="盘点状态" width="110" />
            <el-table-column prop="projectName" label="项目" min-width="150" show-overflow-tooltip />
            <el-table-column prop="itemName" label="名称" min-width="180" show-overflow-tooltip />
            <el-table-column prop="owner" label="所有者" width="120" />
            <el-table-column prop="reviewOwner" label="负责复盘人" width="120" />
            <el-table-column prop="totalQuantity" label="总数" width="90" :formatter="integerFormatter" />
            <el-table-column prop="actualQuantity" label="实际数量" width="110" :formatter="integerFormatter" />
            <el-table-column prop="checkQuantity" label="盘点数量" width="110" :formatter="integerFormatter" />
            <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
            <el-table-column prop="createdAt" label="发起时间" width="170" />
            <el-table-column label="操作" fixed="right" width="180">
              <template slot-scope="scope">
                <el-button v-if="canSubmit(scope.row)" size="mini" type="primary" @click="openSubmitDialog(scope.row)">盘点</el-button>
                <el-button v-if="canReviewRow(scope.row)" size="mini" type="success" @click="reviewTask(scope.row)">复盘</el-button>
                <el-button size="mini" @click="openRecordDialog(scope.row)">记录</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="样机盘点记录" name="prototypeRecords">
          <el-table v-loading="loading" :data="recordRows" border height="560" style="width:100%" :row-class-name="inventoryRowClassName">
            <el-table-column prop="sourceType" label="类型" width="90" />
            <el-table-column label="盘点结果" width="110">
              <template slot-scope="scope">
                <el-tag v-if="scope.row.result" :type="resultTagType(scope.row.result)" size="small">{{ scope.row.result }}</el-tag>
                <span v-else>-</span>
              </template>
            </el-table-column>
            <el-table-column prop="status" label="盘点状态" width="110" />
            <el-table-column prop="projectName" label="项目" min-width="150" show-overflow-tooltip />
            <el-table-column prop="itemName" label="名称" min-width="180" show-overflow-tooltip />
            <el-table-column prop="owner" label="所有者" width="120" />
            <el-table-column prop="reviewOwner" label="负责复盘人" width="120" />
            <el-table-column prop="totalQuantity" label="总数" width="90" :formatter="integerFormatter" />
            <el-table-column prop="actualQuantity" label="实际数量" width="110" :formatter="integerFormatter" />
            <el-table-column prop="checkQuantity" label="盘点数量" width="110" :formatter="integerFormatter" />
            <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
            <el-table-column prop="checkedAt" label="盘点时间" width="170" />
            <el-table-column prop="reviewer" label="实际复盘人" width="120" />
            <el-table-column prop="reviewedAt" label="复盘时间" width="170" />
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </el-card>

    <el-dialog title="提交盘点" :visible.sync="submitDialogVisible" width="520px" @close="resetSubmitForm">
      <el-form label-width="90px">
        <el-form-item label="项目">
          <el-input :value="currentTask ? currentTask.projectName : ''" disabled />
        </el-form-item>
        <el-form-item label="名称">
          <el-input :value="currentTask ? currentTask.itemName : ''" disabled />
        </el-form-item>
        <el-form-item label="所有者">
          <el-input :value="currentTask ? currentTask.owner : ''" disabled />
        </el-form-item>
        <el-form-item label="总数">
          <el-input :value="currentTask ? currentTask.totalQuantity : ''" disabled />
        </el-form-item>
        <el-form-item label="实际数量" required>
          <el-input-number v-model="submitForm.actualQuantity" :min="0" :precision="0" :step="1" style="width:100%" />
        </el-form-item>
        <el-form-item label="盘点数量">
          <el-input :value="previewCheckQuantityText" disabled />
        </el-form-item>
        <el-form-item label="盘点结果">
          <el-tag :type="previewResultType">{{ previewResult }}</el-tag>
        </el-form-item>
        <el-form-item :label="reasonLabel" :required="previewResult === '盘亏' || previewResult === '盘盈'">
          <el-input v-model.trim="submitForm.reason" type="textarea" :rows="3" />
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="submitDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitInventory">提交</el-button>
      </span>
    </el-dialog>

    <el-dialog :title="recordDialogTitle" :visible.sync="recordDialogVisible" width="920px">
      <el-table v-loading="recordLoading" :data="recordDialogRows" border height="560" style="width:100%" :row-class-name="inventoryRowClassName">
        <el-table-column prop="sourceType" label="类型" width="90" />
        <el-table-column label="盘点结果" width="110">
          <template slot-scope="scope">
            <el-tag v-if="scope.row.result" :type="resultTagType(scope.row.result)" size="small">{{ scope.row.result }}</el-tag>
            <span v-else>-</span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="盘点状态" width="110" />
        <el-table-column prop="projectName" label="项目" min-width="150" show-overflow-tooltip />
        <el-table-column prop="itemSource" label="物品来源" width="120" />
        <el-table-column prop="receiveCode" label="领用编码" width="130" show-overflow-tooltip />
        <el-table-column prop="itemName" label="名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="catlogCode" label="catlog编码" width="130" show-overflow-tooltip />
        <el-table-column prop="orderNumber" label="领料单号" width="130" show-overflow-tooltip />
        <el-table-column prop="unitPrice" label="单价" width="90" />
        <el-table-column prop="owner" label="所有者" width="120" />
        <el-table-column prop="entryPerson" label="录入人" width="100" />
        <el-table-column prop="team" label="所属团队" width="110" />
        <el-table-column prop="engineer" label="工程师" width="100" />
        <el-table-column prop="reviewOwner" label="负责复盘人" width="120" />
        <el-table-column prop="totalQuantity" label="总数" width="90" :formatter="integerFormatter" />
        <el-table-column prop="actualQuantity" label="实际数量" width="110" :formatter="integerFormatter" />
        <el-table-column prop="checkQuantity" label="盘点数量" width="110" :formatter="integerFormatter" />
        <el-table-column prop="storageLocation" label="存放位置" min-width="140" show-overflow-tooltip />
        <el-table-column prop="materialProvider" label="物料提供人" width="120" show-overflow-tooltip />
        <el-table-column prop="materialRecipient" label="物料领取人" width="120" show-overflow-tooltip />
        <el-table-column prop="usageStatus" label="使用状态" width="100" />
        <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
        <el-table-column prop="entryRemark" label="备注" min-width="160" show-overflow-tooltip />
        <el-table-column prop="checkedAt" label="盘点时间" width="170" />
        <el-table-column prop="reviewer" label="实际复盘人" width="120" />
        <el-table-column prop="reviewedAt" label="复盘时间" width="170" />
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import axios from "axios"
import { API_BASE } from "../../config/appConfig"

const emptySearchForm = () => ({
  projectName: "",
  itemName: ""
})

const InventoryTaskTable = {
  props: {
    rows: { type: Array, default: () => [] },
    loading: { type: Boolean, default: false },
    canReview: { type: Boolean, default: false },
    currentUser: { type: String, default: "" },
    isAdmin: { type: Boolean, default: false }
  },
  methods: {
    integerFormatter(row, column, cellValue) {
      if (cellValue === null || cellValue === undefined || cellValue === "") return ""
      return String(Math.round(Number(cellValue) || 0))
    },
    resultTagType(result) {
      if (result === "盘亏") return "danger"
      if (result === "盘盈") return "warning"
      if (result === "盘平") return "success"
      return "info"
    },
    canSubmit(row) {
      return row.status === "待盘点" && row.owner === this.currentUser
    },
    canReviewRow(row) {
      return row.status === "待复盘" && (this.isAdmin || row.reviewOwner === this.currentUser)
    },
    rowClassName({ row }) {
      if (row.result === "盘亏") return "inventory-loss-row"
      if (row.result === "盘盈") return "inventory-gain-row"
      return ""
    }
  },
  template: `
    <el-table v-loading="loading" :data="rows" border height="560" style="width:100%" :row-class-name="rowClassName">
      <el-table-column prop="sourceType" label="类型" width="90" />
      <el-table-column prop="projectName" label="项目" min-width="150" show-overflow-tooltip />
      <el-table-column prop="itemName" label="名称" min-width="180" show-overflow-tooltip />
      <el-table-column prop="owner" label="所有者" width="120" />
      <el-table-column prop="reviewOwner" label="负责复盘人" width="120" />
      <el-table-column prop="totalQuantity" label="总数" width="90" :formatter="integerFormatter" />
      <el-table-column prop="actualQuantity" label="实际数量" width="110" :formatter="integerFormatter" />
      <el-table-column prop="checkQuantity" label="盘点数量" width="110" :formatter="integerFormatter" />
      <el-table-column label="盘点结果" width="110">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.result" :type="resultTagType(scope.row.result)" size="small">{{ scope.row.result }}</el-tag>
          <span v-else>-</span>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="盘点状态" width="110" />
      <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
      <el-table-column prop="createdAt" label="发起时间" width="170" />
      <el-table-column label="操作" fixed="right" width="180">
        <template slot-scope="scope">
          <el-button v-if="canSubmit(scope.row)" size="mini" type="primary" @click="$emit('submit', scope.row)">盘点</el-button>
          <el-button v-if="canReviewRow(scope.row)" size="mini" type="success" @click="$emit('review', scope.row)">复盘</el-button>
          <el-button size="mini" @click="$emit('record', scope.row)">记录</el-button>
        </template>
      </el-table-column>
    </el-table>
  `
}

const InventoryRecordTable = {
  props: {
    rows: { type: Array, default: () => [] },
    loading: { type: Boolean, default: false }
  },
  methods: {
    integerFormatter(row, column, cellValue) {
      if (cellValue === null || cellValue === undefined || cellValue === "") return ""
      return String(Math.round(Number(cellValue) || 0))
    },
    resultTagType(result) {
      if (result === "盘亏") return "danger"
      if (result === "盘盈") return "warning"
      return "success"
    },
    rowClassName({ row }) {
      if (row.result === "盘亏") return "inventory-loss-row"
      if (row.result === "盘盈") return "inventory-gain-row"
      return ""
    }
  },
  template: `
    <el-table v-loading="loading" :data="rows" border height="560" style="width:100%" :row-class-name="rowClassName">
      <el-table-column prop="sourceType" label="类型" width="90" />
      <el-table-column prop="projectName" label="项目" min-width="150" show-overflow-tooltip />
      <el-table-column prop="itemName" label="名称" min-width="180" show-overflow-tooltip />
      <el-table-column prop="owner" label="所有者" width="120" />
      <el-table-column prop="reviewOwner" label="负责复盘人" width="120" />
      <el-table-column prop="totalQuantity" label="总数" width="90" :formatter="integerFormatter" />
      <el-table-column prop="actualQuantity" label="实际数量" width="110" :formatter="integerFormatter" />
      <el-table-column prop="checkQuantity" label="盘点数量" width="110" :formatter="integerFormatter" />
      <el-table-column label="盘点结果" width="110">
        <template slot-scope="scope">
          <el-tag :type="resultTagType(scope.row.result)" size="small">{{ scope.row.result }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="status" label="盘点状态" width="110" />
      <el-table-column prop="reason" label="原因" min-width="180" show-overflow-tooltip />
      <el-table-column prop="checkedAt" label="盘点时间" width="170" />
      <el-table-column prop="reviewer" label="实际复盘人" width="120" />
      <el-table-column prop="reviewedAt" label="复盘时间" width="170" />
    </el-table>
  `
}

export default {
  components: {
    InventoryTaskTable,
    InventoryRecordTable
  },
  data() {
    return {
      activeTab: "materialTasks",
      cycleMonths: 3,
      cycleValue: 3,
      cycleUnit: "month",
      loading: false,
      user: {},
      taskRows: [],
      recordRows: [],
      searchForm: emptySearchForm(),
      submitDialogVisible: false,
      currentTask: null,
      submitForm: {
        actualQuantity: 0,
        reason: ""
      },
      recordDialogVisible: false,
      recordDialogRows: [],
      recordDialogTitle: "盘点记录",
      recordLoading: false
    }
  },
  computed: {
    isAdmin() {
      return Number(this.user.permissions) === 1
    },
    canReview() {
      return this.isAdmin || this.hasAdditionalRole("复盘人")
    },
    currentSourceType() {
      return this.activeTab.startsWith("prototype") ? "样机" : "物料"
    },
    isRecordTab() {
      return this.activeTab.endsWith("Records")
    },
    previewResult() {
      if (!this.currentTask) return "盘平"
      const actual = Number(this.submitForm.actualQuantity || 0)
      const total = Number(this.currentTask.totalQuantity || 0)
      if (actual < total) return "盘亏"
      if (actual > total) return "盘盈"
      return "盘平"
    },
    previewResultType() {
      if (this.previewResult === "盘亏") return "danger"
      if (this.previewResult === "盘盈") return "warning"
      return "success"
    },
    previewCheckQuantity() {
      if (!this.currentTask) return 0
      return Number(this.submitForm.actualQuantity || 0) - Number(this.currentTask.totalQuantity || 0)
    },
    previewCheckQuantityText() {
      const value = Math.round(this.previewCheckQuantity)
      return value > 0 ? `+${value}` : String(value)
    },
    reasonLabel() {
      return this.previewResult === "盘平" ? "原因" : `${this.previewResult}原因`
    }
  },
  watch: {
    "$route.fullPath"() {
      this.applyRouteTab()
    }
  },
  created() {
    const user = localStorage.getItem("user")
    if (user) {
      this.user = JSON.parse(user)
    }
    this.refreshCurrentUser()
    this.applyRouteTab()
    this.fetchConfig()
  },
  methods: {
    integerFormatter(row, column, cellValue) {
      if (cellValue === null || cellValue === undefined || cellValue === "") return ""
      return String(Math.round(Number(cellValue) || 0))
    },
    resultTagType(result) {
      if (result === "盘亏") return "danger"
      if (result === "盘盈") return "warning"
      if (result === "盘平") return "success"
      return "info"
    },
    inventoryRowClassName({ row }) {
      if (row.result === "盘亏") return "inventory-loss-row"
      if (row.result === "盘盈") return "inventory-gain-row"
      return ""
    },
    canSubmit(row) {
      return row.status === "待盘点" && row.owner === this.user.username
    },
    canReviewRow(row) {
      return row.status === "待复盘" && (this.isAdmin || row.reviewOwner === this.user.username)
    },
    refreshCurrentUser() {
      if (!this.user.username) {
        return
      }

      axios.get(`${API_BASE}/user/profile/${encodeURIComponent(this.user.username)}`).then(res => {
        if (res.data.code !== 200 || !res.data.data) {
          return
        }

        this.user = Object.assign({}, this.user, res.data.data)
        localStorage.setItem("user", JSON.stringify(this.user))
        this.fetchCurrentData()
      }).catch(() => {})
    },
    applyRouteTab() {
      const tab = this.$route.query.tab
      const validTabs = ["materialTasks", "materialRecords", "prototypeTasks", "prototypeRecords"]
      this.activeTab = validTabs.includes(tab) ? tab : "materialTasks"
      this.fetchCurrentData()
    },
    requestParams() {
      return {
        username: this.user.username || "",
        permissions: this.user.permissions,
        additionalRole: this.user.additionalRole || "",
        sourceType: this.currentSourceType,
        projectName: (this.searchForm.projectName || "").trim(),
        itemName: (this.searchForm.itemName || "").trim()
      }
    },
    handleTabChanged() {
      this.fetchCurrentData()
    },
    resetSearch() {
      this.searchForm = emptySearchForm()
      this.fetchCurrentData()
    },
    fetchCurrentData() {
      if (this.isRecordTab) {
        this.fetchRecords()
      } else {
        this.fetchTasks()
      }
    },
    fetchConfig() {
      axios.get(`${API_BASE}/inventory/config`).then(res => {
        if (res.data.code === 200) {
          this.cycleMonths = Number(res.data.data.cycleMonths || 3)
          this.cycleValue = Number(res.data.data.cycleValue || res.data.data.cycleMonths || 3)
          this.cycleUnit = res.data.data.cycleUnit || "month"
        }
      }).catch(() => {})
    },
    saveCycle() {
      axios.post(`${API_BASE}/inventory/config`, {
        username: this.user.username,
        permissions: this.user.permissions,
        additionalRole: this.user.additionalRole,
        cycleMonths: this.cycleUnit === "month" ? this.cycleValue : this.cycleMonths,
        cycleValue: this.cycleValue,
        cycleUnit: this.cycleUnit
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
        } else {
          this.$message.error(res.data.msg || "保存失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },
    generateInventory() {
      axios.post(`${API_BASE}/inventory/generate`, {
        username: this.user.username,
        permissions: this.user.permissions,
        additionalRole: this.user.additionalRole,
        sourceType: "全部",
        force: true
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.fetchCurrentData()
          this.fetchConfig()
        } else {
          this.$message.error(res.data.msg || "发起失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },
    fetchTasks() {
      if (!this.user.username) return
      this.loading = true
      axios.get(`${API_BASE}/inventory/tasks`, {
        params: this.requestParams()
      }).then(res => {
        if (res.data.code === 200) {
          this.taskRows = res.data.data || []
        } else {
          this.$message.error(res.data.msg || "获取盘点任务失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.loading = false
      })
    },
    fetchRecords() {
      if (!this.user.username) return
      this.loading = true
      axios.get(`${API_BASE}/inventory/records`, {
        params: this.requestParams()
      }).then(res => {
        if (res.data.code === 200) {
          this.recordRows = res.data.data || []
        } else {
          this.$message.error(res.data.msg || "获取盘点记录失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.loading = false
      })
    },
    openSubmitDialog(row) {
      this.currentTask = row
      this.submitForm = {
        actualQuantity: Number(row.totalQuantity || 0),
        reason: ""
      }
      this.submitDialogVisible = true
    },
    resetSubmitForm() {
      this.currentTask = null
      this.submitForm = {
        actualQuantity: 0,
        reason: ""
      }
    },
    submitInventory() {
      if (!this.currentTask) return
      if (["盘亏", "盘盈"].includes(this.previewResult) && !this.submitForm.reason) {
        this.$message.warning("盘亏或盘盈必须填写原因")
        return
      }
      axios.post(`${API_BASE}/inventory/submit/${this.currentTask.id}`, {
        username: this.user.username,
        permissions: this.user.permissions,
        additionalRole: this.user.additionalRole,
        actualQuantity: this.submitForm.actualQuantity,
        reason: this.submitForm.reason
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.submitDialogVisible = false
          this.fetchCurrentData()
        } else {
          this.$message.error(res.data.msg || "提交失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },
    reviewTask(row) {
      this.$confirm(`确认复盘 ${row.itemName}？`, "复盘确认", { type: "warning" }).then(() => {
        axios.post(`${API_BASE}/inventory/review/${row.id}`, {
          username: this.user.username,
          permissions: this.user.permissions,
          additionalRole: this.user.additionalRole
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchCurrentData()
          } else {
            this.$message.error(res.data.msg || "复盘失败")
          }
        }).catch(() => {
          this.$message.error("网络请求失败，请检查后端是否启动")
        })
      }).catch(() => {})
    },
    openRecordDialog(row) {
      this.recordDialogVisible = true
      this.recordDialogTitle = `${row.itemName} - 盘点记录`
      this.recordDialogRows = []
      this.recordLoading = true
      axios.get(`${API_BASE}/inventory/records`, {
        params: {
          username: this.user.username || "",
          permissions: this.user.permissions,
          additionalRole: this.user.additionalRole || "",
          sourceType: row.sourceType,
          identityCode: row.identityCode
        }
      }).then(res => {
        if (res.data.code === 200) {
          this.recordDialogRows = res.data.data || []
        } else {
          this.$message.error(res.data.msg || "获取盘点记录失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.recordLoading = false
      })
    },
    hasAdditionalRole(role) {
      return String(this.user.additionalRole || "")
        .replace(/[，、；;|/\s]+/g, ",")
        .split(",")
        .map(item => item.trim())
        .includes(role)
    }
  }
}
</script>

<style scoped>
.inventory-page {
  min-height: 100vh;
  padding: 16px;
  background: #f5f7fa;
}

.inventory-header,
.header-actions,
.inventory-filter {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.inventory-filter {
  margin-bottom: 12px;
}

.inventory-filter ::v-deep .el-form-item {
  margin-bottom: 0;
}

.cycle-input {
  width: 110px;
}

.cycle-unit {
  width: 88px;
}

.cycle-label {
  color: #606266;
  font-size: 13px;
}

.inventory-page ::v-deep .inventory-loss-row td {
  background-color: #fff2f0;
}

.inventory-page ::v-deep .inventory-gain-row td {
  background-color: #fff7e6;
}
</style>
