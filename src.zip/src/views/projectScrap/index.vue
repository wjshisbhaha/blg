<template>
  <div class="resource-page">
    <div class="resource-nav">
      <button
        v-for="item in navItems"
        :key="item.name"
        class="resource-nav-item"
        :class="{ active: activeTab === item.name }"
        type="button"
        @click="activeTab = item.name"
      >
        {{ item.label }}
      </button>
    </div>

    <div class="resource-content">
      <div v-if="showTools" class="resource-tools">
        <el-form :inline="true" :model="searchForm" size="small">
          <el-form-item label="项目">
            <el-select v-model="searchForm.projectName" filterable clearable placeholder="请选择项目">
              <el-option v-for="item in projectOptions" :key="item.project_name" :label="item.project_name" :value="item.project_name" />
            </el-select>
          </el-form-item>
          <el-form-item label="名称">
            <el-input v-model.trim="searchForm.itemName" clearable placeholder="物品名称" @keyup.enter.native="handleSearch" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch">搜索</el-button>
            <el-button @click="handleReset">重置</el-button>
          </el-form-item>
        </el-form>
        <el-button
          v-if="activeTab === 'transferFlow' || activeTab === 'scrapFlow' || activeTab === 'writeOffFlow'"
          size="small"
          icon="el-icon-download"
          @click="exportRows"
        >
          导出
        </el-button>
      </div>

      <el-table v-if="activeTab === 'summary'" :data="projectSummaryRows" border style="width:100%">
        <el-table-column prop="project_name" label="项目名称" min-width="180" />
        <el-table-column prop="status" label="状态" width="120" />
        <el-table-column prop="project_manager" label="项目经理" width="150" />
        <el-table-column prop="remark" label="备注" min-width="220" show-overflow-tooltip />
      </el-table>

      <el-table v-else-if="activeTab === 'transferFlow'" v-loading="loading" :data="transferRows" border style="width:100%">
        <el-table-column prop="display_order_no" label="单号" min-width="190" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-link type="primary" :underline="false" @click="openTransferDetail(scope.row)">
              {{ scope.row.display_order_no }}
            </el-link>
          </template>
        </el-table-column>
        <el-table-column prop="old_project_name" label="原项目" min-width="150" />
        <el-table-column prop="new_project_name" label="转入项目" min-width="150" />
        <el-table-column prop="item_name" label="物品名称" min-width="180" />
        <el-table-column prop="receive_code" label="领用编码" width="140" show-overflow-tooltip />
        <el-table-column prop="quantity" label="数量" width="90" :formatter="integerFormatter" />
        <el-table-column prop="applicant" label="申请人" width="120" />
        <el-table-column prop="old_project_manager" label="原项目责任人" width="140" />
        <el-table-column prop="new_responsible" label="转入责任人" width="140" />
        <el-table-column prop="new_project_manager" label="转入项目经理" width="140" />
        <el-table-column prop="current_step_text" label="当前节点" width="130" />
        <el-table-column prop="current_approver" label="当前审批人" width="130" />
        <el-table-column label="状态" width="110">
          <template slot-scope="scope">
            <el-tag size="mini" :type="statusTagType(scope.row.status)">{{ transferStatusText(scope.row.status) }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="approval_mode" label="审批方式" width="110">
          <template slot-scope="scope">{{ scope.row.approval_mode === "auto" ? "自动审批" : "人工审批" }}</template>
        </el-table-column>
        <el-table-column prop="approved_by" label="审批人" width="120" />
        <el-table-column prop="created_at" label="申请时间" width="180" />
        <el-table-column prop="approved_at" label="审批时间" width="180" />
        <el-table-column label="操作" width="170" fixed="right">
          <template slot-scope="scope">
            <el-button v-if="scope.row.can_approve" size="mini" type="primary" @click="approveTransfer(scope.row)">审批</el-button>
            <el-button v-if="scope.row.can_approve" size="mini" type="danger" @click="rejectTransfer(scope.row)">拒绝</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-table v-else-if="activeTab === 'scrapFlow'" v-loading="loading" :data="rows" border style="width:100%">
        <el-table-column prop="display_order_no" label="单号" min-width="170" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-link type="primary" :underline="false" @click="openScrapDetail(scope.row)">
              {{ scope.row.display_order_no }}
            </el-link>
          </template>
        </el-table-column>
        <el-table-column prop="source_type" label="类型" width="90" />
        <el-table-column prop="project_name" label="项目名称" min-width="180" />
        <el-table-column prop="receive_code" label="领用编码" width="150" show-overflow-tooltip />
        <el-table-column prop="item_name" label="物品名称" min-width="180" />
        <el-table-column prop="quantity" label="数量" width="110" />
        <el-table-column prop="operator" label="操作人" width="140" />
        <el-table-column prop="created_at" label="报废时间" width="190" />
      </el-table>

      <el-table v-else v-loading="loading" :data="writeOffRows" border style="width:100%">
        <el-table-column prop="display_order_no" label="单号" min-width="190" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-link type="primary" :underline="false" @click="openWriteoffDetail(scope.row)">
              {{ scope.row.display_order_no }}
            </el-link>
          </template>
        </el-table-column>
        <el-table-column prop="source_type" label="类型" width="90" />
        <el-table-column prop="project_name" label="项目名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="item_name" label="名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="quantity" label="数量" width="110" />
        <el-table-column prop="applicant" label="申请人" width="120" />
        <el-table-column prop="current_approver" label="当前审批人" width="130" />
        <el-table-column prop="status_text" label="销账状态" width="110" />
        <el-table-column prop="created_at" label="创建时间" width="180" />
        <el-table-column label="操作" width="210" fixed="right">
          <template slot-scope="scope">
            <el-button size="mini" @click="openWriteoffDetail(scope.row)">详情</el-button>
            <el-button v-if="scope.row.can_approve" size="mini" type="primary" @click="approveWriteoff(scope.row)">审批</el-button>
            <el-button v-if="scope.row.can_approve" size="mini" type="danger" @click="rejectWriteoff(scope.row)">驳回</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <el-dialog title="销账审批流程" :visible.sync="writeoffDetailVisible" width="860px">
      <el-descriptions v-if="writeoffDetail" :column="2" border>
        <el-descriptions-item label="单号">{{ writeoffDetail.display_order_no }}</el-descriptions-item>
        <el-descriptions-item label="申请人">{{ writeoffDetail.applicant }}</el-descriptions-item>
        <el-descriptions-item label="状态">{{ writeoffStatusText(writeoffDetail.status) }}</el-descriptions-item>
        <el-descriptions-item label="当前审批人">{{ writeoffDetail.current_approver }}</el-descriptions-item>
      </el-descriptions>
      <div class="writeoff-stepbar">
        <el-steps
          :active="writeoffDetailActiveStep"
          :process-status="writeoffDetailProcessStatus"
          finish-status="success"
          align-center
        >
          <el-step
            v-for="step in writeoffDetailSteps"
            :key="step.key"
            :title="step.label"
            :description="writeoffStepDescription(step)"
            :status="writeoffStepVisualStatus(step)"
          />
        </el-steps>
      </div>
      <el-table :data="writeoffDetailSteps" border style="width:100%; margin-top:12px">
        <el-table-column prop="label" label="步骤" width="120" />
        <el-table-column prop="approver" label="审批人" width="140" />
        <el-table-column prop="approved_by" label="实际操作人" width="140" />
        <el-table-column label="状态" width="110">
          <template slot-scope="scope">{{ writeoffStepStatusText(scope.row.status) }}</template>
        </el-table-column>
        <el-table-column prop="approved_at" label="审批时间" min-width="170" />
      </el-table>
      <el-table :data="writeoffDetailItems" border style="width:100%; margin-top:12px" max-height="260">
        <el-table-column prop="source_type" label="类型" width="80" />
        <el-table-column prop="project_name" label="项目" min-width="140" show-overflow-tooltip />
        <el-table-column prop="receive_code" label="领用编码" width="140" show-overflow-tooltip />
        <el-table-column prop="item_name" label="名称" min-width="150" show-overflow-tooltip />
        <el-table-column prop="total_quantity" label="总数量" width="100" />
        <el-table-column prop="available_quantity" label="可销账数量" width="110" />
      </el-table>
    </el-dialog>

    <el-dialog title="报废电子流详情" :visible.sync="scrapDetailVisible" width="920px">
      <el-descriptions v-if="scrapDetail" :column="2" border>
        <el-descriptions-item label="单号">{{ scrapDetail.display_order_no }}</el-descriptions-item>
        <el-descriptions-item label="类型">{{ scrapDetail.source_type }}</el-descriptions-item>
        <el-descriptions-item label="项目">{{ scrapDetail.project_name }}</el-descriptions-item>
        <el-descriptions-item label="操作人">{{ scrapDetail.operator }}</el-descriptions-item>
        <el-descriptions-item label="报废时间">{{ scrapDetail.created_at }}</el-descriptions-item>
        <el-descriptions-item label="评审证明">{{ scrapDetail.proof_path || "-" }}</el-descriptions-item>
      </el-descriptions>
      <el-table :data="scrapDetailItems" border style="width:100%; margin-top:12px" max-height="360">
        <el-table-column prop="source_type" label="类型" width="80" />
        <el-table-column prop="project_name" label="项目" min-width="130" show-overflow-tooltip />
        <el-table-column prop="receive_code" label="领用编码" width="130" show-overflow-tooltip />
        <el-table-column prop="item_name" label="名称" min-width="150" show-overflow-tooltip />
        <el-table-column prop="quantity" label="数量" width="80" />
        <el-table-column prop="item_source" label="物品来源" width="120" />
        <el-table-column prop="catlog_code" label="catlog编码" width="130" show-overflow-tooltip />
        <el-table-column prop="order_number" label="领料单号" width="130" show-overflow-tooltip />
        <el-table-column prop="unit_price" label="单价" width="90" />
        <el-table-column prop="material_storage_location" label="存放位置" min-width="140" show-overflow-tooltip />
        <el-table-column prop="entry_person" label="录入人" width="100" />
        <el-table-column prop="team" label="所属团队" width="110" />
        <el-table-column prop="engineer" label="工程师" width="100" />
        <el-table-column prop="remark" label="备注" min-width="160" show-overflow-tooltip />
      </el-table>
    </el-dialog>

    <el-dialog title="转移电子流详情" :visible.sync="transferDetailVisible" width="880px">
      <el-descriptions v-if="transferDetail" :column="2" border>
        <el-descriptions-item label="单号">{{ transferDetail.display_order_no }}</el-descriptions-item>
        <el-descriptions-item label="物品名称">{{ transferDetail.item_name }}</el-descriptions-item>
        <el-descriptions-item label="原项目">{{ transferDetail.old_project_name }}</el-descriptions-item>
        <el-descriptions-item label="转入项目">{{ transferDetail.new_project_name }}</el-descriptions-item>
        <el-descriptions-item label="转入责任人">{{ transferDetail.new_responsible }}</el-descriptions-item>
        <el-descriptions-item label="转入项目经理">{{ transferDetail.new_project_manager }}</el-descriptions-item>
        <el-descriptions-item label="当前节点">{{ transferDetail.current_step_text }}</el-descriptions-item>
        <el-descriptions-item label="当前审批人">{{ transferDetail.current_approver }}</el-descriptions-item>
        <el-descriptions-item label="申请人">{{ transferDetail.applicant }}</el-descriptions-item>
        <el-descriptions-item label="状态">{{ transferStatusText(transferDetail.status) }}</el-descriptions-item>
        <el-descriptions-item label="备注" :span="2">{{ transferDetail.remark }}</el-descriptions-item>
      </el-descriptions>
      <el-table :data="transferDetailSteps" border style="width:100%; margin-top:12px">
        <el-table-column prop="label" label="步骤" width="120" />
        <el-table-column prop="approver" label="审批人" width="140" />
        <el-table-column prop="approved_by" label="实际操作人" width="140" />
        <el-table-column label="状态" width="110">
          <template slot-scope="scope">{{ writeoffStepStatusText(scope.row.status) }}</template>
        </el-table-column>
        <el-table-column prop="approved_at" label="审批时间" min-width="170" />
      </el-table>
    </el-dialog>

    <el-dialog title="物料转移" :visible.sync="transferDialogVisible" width="560px">
      <el-form ref="transferForm" :model="transferForm" label-width="110px" size="small">
        <el-form-item label="物品名称">
          <el-input :value="currentTransferMaterial.item_name" disabled />
        </el-form-item>
        <el-form-item label="领用编码">
          <el-input :value="currentTransferMaterial.receive_code" disabled />
        </el-form-item>
        <el-form-item label="当前项目">
          <el-input :value="currentTransferMaterial.project_name" disabled />
        </el-form-item>
        <el-form-item label="当前责任人">
          <el-input :value="currentTransferMaterial.project_manager" disabled />
        </el-form-item>
        <el-form-item label="转入项目" required>
          <el-select v-model="transferForm.newProjectName" filterable placeholder="请选择转入项目" style="width:100%">
            <el-option
              v-for="item in targetProjectOptions"
              :key="item.project_name"
              :label="projectOptionLabel(item)"
              :value="item.project_name"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="转入责任人" required>
          <el-select v-model="transferForm.newResponsible" filterable clearable placeholder="请选择转入责任人" style="width:100%">
            <el-option
              v-for="item in responsibleOptions"
              :key="item.username"
              :label="responsibleOptionLabel(item)"
              :value="item.username"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model.trim="transferForm.remark" type="textarea" :rows="3" placeholder="可选" />
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="transferDialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="transferSubmitting" @click="submitTransfer">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import axios from "axios"
import { API_BASE } from "../../config/appConfig"

const emptySearchForm = () => ({
  projectName: "",
  itemName: ""
})

const emptyTransferForm = () => ({
  newProjectName: "",
  newResponsible: "",
  remark: ""
})

export default {
  data() {
    return {
      user: {},
      activeTab: "summary",
      navItems: [
        { label: "项目物料汇总", name: "summary" },
        { label: "报废电子流", name: "scrapFlow" },
        { label: "销帐电子流", name: "writeOffFlow" },
        { label: "转移电子流", name: "transferFlow" }
      ],
      loading: false,
      rows: [],
      projectOptions: [],
      responsibleOptions: [],
      materialProcessRows: [],
      transferRows: [],
      transferDialogVisible: false,
      transferSubmitting: false,
      currentTransferMaterial: {},
      transferForm: emptyTransferForm(),
      writeOffRows: [],
      writeoffDetailVisible: false,
      writeoffDetail: null,
      scrapDetailVisible: false,
      scrapDetail: null,
      transferDetailVisible: false,
      transferDetail: null,
      searchForm: emptySearchForm()
    }
  },
  computed: {
    showTools() {
      return ["summary", "transferFlow", "scrapFlow", "writeOffFlow"].includes(this.activeTab)
    },

    targetProjectOptions() {
      const currentProject = this.currentTransferMaterial.project_name
      return this.projectOptions.filter(item => {
        return item.project_name !== currentProject && item.status !== "结项"
      })
    },

    projectSummaryRows() {
      const projectName = this.searchForm.projectName
      const keyword = this.searchForm.itemName
      return this.projectOptions.filter(item => {
        if (projectName && item.project_name !== projectName) {
          return false
        }
        if (!keyword) {
          return true
        }
        return [item.project_name, item.project_manager, item.remark]
          .some(value => String(value || "").includes(keyword))
      })
    },

    writeoffDetailSteps() {
      return this.writeoffDetail && Array.isArray(this.writeoffDetail.steps) ? this.writeoffDetail.steps : []
    },

    writeoffDetailItems() {
      return this.writeoffDetail && Array.isArray(this.writeoffDetail.items) ? this.writeoffDetail.items : []
    },

    scrapDetailItems() {
      return this.scrapDetail && Array.isArray(this.scrapDetail.items) ? this.scrapDetail.items : []
    },

    transferDetailSteps() {
      return this.transferDetail && Array.isArray(this.transferDetail.steps) ? this.transferDetail.steps : []
    },

    writeoffDetailActiveStep() {
      const steps = this.writeoffDetailSteps
      if (!steps.length) {
        return 0
      }
      const pendingIndex = steps.findIndex(item => item.status === "pending")
      if (pendingIndex >= 0) {
        return pendingIndex
      }
      const rejectedIndex = steps.findIndex(item => item.status === "rejected")
      if (rejectedIndex >= 0) {
        return rejectedIndex
      }
      return steps.filter(item => item.status === "approved").length
    },

    writeoffDetailProcessStatus() {
      return this.writeoffDetailSteps.some(item => item.status === "rejected") ? "error" : "process"
    }
  },
  created() {
    const user = localStorage.getItem("user")
    if (user) {
      this.user = JSON.parse(user)
    }
    this.fetchProjectOptions()
    this.fetchResponsibleOptions()
    this.fetchRows()
  },
  watch: {
    activeTab() {
      this.fetchRows()
    }
  },
  methods: {
    searchParams() {
      return {
        projectName: (this.searchForm.projectName || "").trim(),
        itemName: (this.searchForm.itemName || "").trim()
      }
    },
    handleSearch() {
      this.searchForm = this.searchParams()
      this.fetchRows()
    },
    handleReset() {
      this.searchForm = emptySearchForm()
      this.fetchRows()
    },
    fetchProjectOptions() {
      axios.get(`${API_BASE}/project/list`).then(res => {
        if (res.data.code === 200) {
          this.projectOptions = res.data.data || []
        }
      }).catch(() => {})
    },
    fetchResponsibleOptions() {
      axios.get(`${API_BASE}/user/responsibles`).then(res => {
        if (res.data.code === 200) {
          this.responsibleOptions = res.data.data || []
        }
      }).catch(() => {})
    },
    fetchRows() {
      if (this.activeTab === "summary") {
        this.loading = false
        return
      }
      this.loading = true
      let url = `${API_BASE}/project/scrap/list`
      if (this.activeTab === "writeOffFlow") {
        url = `${API_BASE}/project/writeoff/list`
      } else if (this.activeTab === "transferFlow") {
        url = `${API_BASE}/project/material_transfer/list`
      }
      const params = Object.assign(this.searchParams(), {
        username: this.user.username || "",
        permissions: this.user.permissions
      })
      axios.get(url, {
        params
      }).then(res => {
        if (res.data.code === 200) {
          const nextRows = (res.data.data || []).map(row => this.normalizeFlowRow(row, this.activeTab))
          if (this.activeTab === "writeOffFlow") {
            this.writeOffRows = nextRows
          } else if (this.activeTab === "transferFlow") {
            this.transferRows = nextRows
          } else {
            this.rows = nextRows
          }
        } else {
          this.$message.error(res.data.msg || "获取记录失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.loading = false
      })
    },
    exportRows() {
      let url = `${API_BASE}/project/scrap/export`
      let fileName = "报废电子流"
      if (this.activeTab === "writeOffFlow") {
        url = `${API_BASE}/project/writeoff/export`
        fileName = "销账电子流"
      } else if (this.activeTab === "transferFlow") {
        url = `${API_BASE}/project/material_transfer/export`
        fileName = "物料转移电子流"
      }
      axios.get(url, {
        params: Object.assign(this.searchParams(), {
          username: this.user.username || "",
          permissions: this.user.permissions
        }),
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `${fileName}_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      }).catch(() => {
        this.$message.error("导出失败，请检查后端是否启动")
      })
    },
    openTransferDialog(row) {
      this.currentTransferMaterial = Object.assign({}, row)
      this.transferForm = emptyTransferForm()
      this.transferDialogVisible = true
    },
    submitTransfer() {
      if (!this.transferForm.newProjectName) {
        this.$message.warning("请选择转入项目")
        return
      }
      if (!this.transferForm.newResponsible) {
        this.$message.warning("请选择转入责任人")
        return
      }
      this.transferSubmitting = true
      axios.post(`${API_BASE}/project/material_transfer/submit`, {
        materialId: this.currentTransferMaterial.id,
        newProjectName: this.transferForm.newProjectName,
        newResponsible: this.transferForm.newResponsible,
        applicant: this.user.username || "",
        permissions: this.user.permissions,
        remark: this.transferForm.remark
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg || "提交成功")
          this.transferDialogVisible = false
          this.fetchRows()
        } else {
          this.$message.error(res.data.msg || "提交失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.transferSubmitting = false
      })
    },
    approveTransfer(row) {
      this.$confirm("确认通过当前物料转移申请？", "审批", { type: "warning" }).then(() => {
        axios.post(`${API_BASE}/project/material_transfer/approve/${row.id}`, {
          username: this.user.username || "",
          permissions: this.user.permissions
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg || "审批成功")
            this.fetchRows()
          } else {
            this.$message.error(res.data.msg || "审批失败")
          }
        }).catch(() => {
          this.$message.error("网络请求失败，请检查后端是否启动")
        })
      }).catch(() => {})
    },
    rejectTransfer(row) {
      this.$confirm("确认拒绝当前物料转移申请？", "拒绝", { type: "warning" }).then(() => {
        axios.post(`${API_BASE}/project/material_transfer/reject/${row.id}`, {
          username: this.user.username || "",
          permissions: this.user.permissions
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg || "已拒绝")
            this.fetchRows()
          } else {
            this.$message.error(res.data.msg || "拒绝失败")
          }
        }).catch(() => {
          this.$message.error("网络请求失败，请检查后端是否启动")
        })
      }).catch(() => {})
    },
    integerFormatter(_row, _column, value) {
      return this.formatInteger(value)
    },
    formatInteger(value) {
      const number = Number(value || 0)
      if (!Number.isFinite(number)) {
        return 0
      }
      return Math.trunc(number)
    },
    statusTagType(status) {
      if (status === "approved") return "success"
      if (status === "rejected") return "danger"
      return "warning"
    },
    transferStatusText(status) {
      if (status === "approved") return "已通过"
      if (status === "rejected") return "已拒绝"
      return "待审批"
    },
    normalizeFlowRow(row, type) {
      const nextRow = Object.assign({}, row)
      let orderNo = String(nextRow.order_no || nextRow.order_number || nextRow.orderNo || "").trim()
      if (!orderNo) {
        if (type === "scrapFlow") {
          orderNo = this.scrapFallbackOrderNo(nextRow)
        } else if (type === "transferFlow") {
          orderNo = this.fallbackOrderNo(nextRow, "ZY")
        } else {
          orderNo = this.fallbackOrderNo(nextRow, "XZ")
        }
      }
      nextRow.order_no = orderNo
      nextRow.order_number = orderNo
      nextRow.display_order_no = orderNo
      return nextRow
    },
    normalizeFlowDetail(row, type) {
      return this.normalizeFlowRow(row || {}, type)
    },
    fallbackOrderNo(row, prefix) {
      const id = row && (row.id || row.application_id || row.record_id || row.material_id)
      return `${prefix}-${id || "未生成"}`
    },
    scrapFallbackOrderNo(row) {
      if (row && row.flow_id) {
        const parts = String(row.flow_id).split("-")
        const id = parts.slice(1).join("-")
        if (id) {
          return `${parts[0] === "project" ? "BF-P" : "BF-M"}-${id}`
        }
      }
      const prefix = row && row.flow_table === "project" ? "BF-P" : "BF-M"
      return this.fallbackOrderNo(row, prefix)
    },
    flowOrderNo(row, prefix) {
      const value = (row && (row.order_no || row.order_number)) || ""
      if (String(value).trim()) {
        return value
      }
      return `${prefix}-${row && row.id ? row.id : "-"}`
    },
    scrapOrderNo(row) {
      const value = (row && row.order_no) || ""
      if (String(value).trim()) {
        return value
      }
      const prefix = row && row.flow_table === "project" ? "BF-P" : "BF-M"
      return `${prefix}-${row && row.id ? row.id : "-"}`
    },
    projectOptionLabel(item) {
      const manager = item.project_manager ? ` / ${item.project_manager}` : ""
      return `${item.project_name}${manager}`
    },
    responsibleOptionLabel(item) {
      const name = item.name ? ` ${item.name}` : ""
      const team = item.team ? ` / ${item.team}` : ""
      return `${item.username}${name}${team}`
    },
    openScrapDetail(row) {
      if (!row.flow_id) {
        this.$message.error("报废记录缺少详情标识")
        return
      }
      axios.get(`${API_BASE}/project/scrap/detail/${encodeURIComponent(row.flow_id)}`).then(res => {
        if (res.data.code === 200) {
          this.scrapDetail = this.normalizeFlowDetail(res.data.data, "scrapFlow")
          this.scrapDetailVisible = true
        } else {
          this.$message.error(res.data.msg || "获取报废详情失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },
    openTransferDetail(row) {
      axios.get(`${API_BASE}/project/material_transfer/detail/${row.id}`).then(res => {
        if (res.data.code === 200) {
          this.transferDetail = this.normalizeFlowDetail(res.data.data, "transferFlow")
          this.transferDetailVisible = true
        } else {
          this.$message.error(res.data.msg || "获取转移详情失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },
    openWriteoffDetail(row) {
      axios.get(`${API_BASE}/project/writeoff/detail/${row.id}`).then(res => {
        if (res.data.code === 200) {
          this.writeoffDetail = this.normalizeFlowDetail(res.data.data, "writeOffFlow")
          this.writeoffDetailVisible = true
        } else {
          this.$message.error(res.data.msg || "获取销账详情失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },
    approveWriteoff(row) {
      this.$confirm("确认通过当前销账审批步骤？", "审批", { type: "warning" }).then(() => {
        axios.post(`${API_BASE}/project/writeoff/approve/${row.id}`, {
          username: this.user.username || "",
          permissions: this.user.permissions
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchRows()
          } else {
            this.$message.error(res.data.msg || "审批失败")
          }
        })
      }).catch(() => {})
    },
    rejectWriteoff(row) {
      this.$confirm("确认驳回当前销账申请？", "驳回", { type: "warning" }).then(() => {
        axios.post(`${API_BASE}/project/writeoff/reject/${row.id}`, {
          username: this.user.username || "",
          permissions: this.user.permissions
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchRows()
          } else {
            this.$message.error(res.data.msg || "驳回失败")
          }
        })
      }).catch(() => {})
    },
    writeoffStatusText(status) {
      if (status === "approved") return "已通过"
      if (status === "rejected") return "已驳回"
      return "待审批"
    },
    writeoffStepStatusText(status) {
      if (status === "approved") return "已审批"
      if (status === "rejected") return "已拒绝"
      if (status === "waiting") return "未开始"
      return "待审批"
    },
    writeoffStepVisualStatus(step) {
      if (!step) return "wait"
      if (step.status === "approved") return "success"
      if (step.status === "rejected") return "error"
      if (step.status === "pending") return "process"
      return "wait"
    },
    writeoffStepDescription(step) {
      if (!step) return ""
      const values = [`审批人：${step.approver || "-"}`, this.writeoffStepStatusText(step.status)]
      if (step.approved_by) {
        values.push(`操作人：${step.approved_by}`)
      }
      if (step.approved_at) {
        values.push(step.approved_at)
      }
      return values.join(" / ")
    },
    formatExportTime() {
      const date = new Date()
      const pad = value => String(value).padStart(2, "0")
      return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}_${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`
    }
  }
}
</script>

<style scoped>
.resource-page {
  min-height: 100vh;
  background: #fff;
}

.resource-nav {
  display: flex;
  align-items: center;
  height: 60px;
  padding: 0 20px;
  border-bottom: 1px solid #dcdfe6;
  background: #fff;
  overflow-x: auto;
}

.resource-nav-item {
  height: 60px;
  padding: 0 20px;
  border: 0;
  background: transparent;
  color: #303133;
  font-size: 15px;
  font-weight: 600;
  white-space: nowrap;
  cursor: pointer;
}

.resource-nav-item.active {
  color: #409eff;
  box-shadow: inset 0 -3px #409eff;
}

.resource-nav-item:hover {
  color: #409eff;
}

.resource-content {
  padding: 18px 20px;
  background: #fff;
}

.resource-tools {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 16px;
}

.resource-tools ::v-deep .el-form-item {
  margin-bottom: 0;
}

.writeoff-stepbar {
  margin: 16px 0 12px;
  padding: 16px 12px 8px;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  background: #fafafa;
}

.writeoff-stepbar ::v-deep .el-step__description {
  line-height: 1.5;
}

@media (max-width: 900px) {
  .resource-nav {
    padding: 0 10px;
  }

  .resource-nav-item {
    padding: 0 12px;
  }

  .resource-tools {
    align-items: flex-start;
    flex-direction: column;
  }
}
</style>
