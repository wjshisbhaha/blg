<template>
  <div class="agent-page" :class="{ embedded }">
    <el-card shadow="never">
      <div slot="header" class="card-header">
        <span>{{ pageTitle }}</span>
        <div class="header-actions">
          <el-input
            v-model="searchKeyword"
            size="small"
            clearable
            placeholder="搜索物品/提交人/工程师"
            class="search-input"
          />
          <el-select
            v-model="searchType"
            size="small"
            clearable
            placeholder="类型"
            class="type-select"
          >
            <el-option label="物料" value="物料" />
            <el-option label="研发入账" value="研发入账" />
            <el-option label="样机" value="样机" />
            <el-option label="销账" value="销账" />
            <el-option label="物料转移" value="物料转移" />
            <el-option label="项目结项" value="项目结项" />
            <el-option label="月度审核" value="月度审核" />
          </el-select>
          <el-button
            v-if="activeTab === 'monthlyAudit'"
            size="small"
            type="primary"
            @click="generateMonthlyAudit"
          >
            生成月度审核
          </el-button>
          <el-button size="small" @click="exportCurrentTab">
            导出
          </el-button>
          <el-button size="small" type="primary" @click="fetchApprovals">
            刷新
          </el-button>
        </div>
      </div>

      <el-tabs v-model="activeTab">
        <el-tab-pane v-if="canApprove" label="待我审批" name="pending">
          <el-table
            ref="pendingTable"
            v-loading="loading"
            :data="pagedPendingApprovals"
            :row-key="approvalRowKey"
            border
            style="width: 100%"
            @selection-change="handlePendingSelectionChange"
          >
            <el-table-column type="selection" :selectable="isPendingSelectable" fixed width="48" />
            <el-table-column prop="source_type" label="类型" width="80" />
            <el-table-column prop="item_name" label="物品名称" min-width="160" show-overflow-tooltip />
            <el-table-column prop="receive_code" label="领用编码" width="140" show-overflow-tooltip />
            <el-table-column label="单号/领料单号" width="150" show-overflow-tooltip>
              <template slot-scope="scope">
                <el-link
                  v-if="isFlowOrderClickable(scope.row)"
                  type="primary"
                  :underline="false"
                  @click="openDetail(scope.row)"
                >
                  {{ flowOrderText(scope.row) }}
                </el-link>
                <span v-else>{{ flowOrderText(scope.row) }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="total_quantity" label="总数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="remain_quantity" label="剩余数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="out_number" label="出账数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="submitter" label="提交人" width="120" />
            <el-table-column prop="created_at" label="提交时间" width="180" />
            <el-table-column label="操作" width="460">
              <template slot-scope="scope">
                <el-button
                  v-if="scope.row.source_type !== '项目结项'"
                  size="mini"
                  @click="openDetail(scope.row)"
                >
                  详情
                </el-button>
                <el-button
                  v-if="scope.row.can_approve && scope.row.source_type !== '项目结项'"
                  size="mini"
                  type="primary"
                  @click="approve(scope.row)"
                >
                  审批
                </el-button>
                <el-button
                  v-if="scope.row.can_approve && scope.row.source_type !== '项目结项'"
                  size="mini"
                  type="danger"
                  @click="reject(scope.row)"
                >
                  拒绝
                </el-button>
                <el-button v-if="scope.row.source_type === '项目结项' && scope.row.can_approve" size="mini" type="danger" @click="handleProjectClose(scope.row, '报废')">报废</el-button>
                <el-button v-if="scope.row.source_type === '项目结项' && scope.row.can_approve" size="mini" @click="handleProjectClose(scope.row, '结项清退')">结项清退</el-button>
                <el-button v-if="scope.row.source_type === '项目结项' && scope.row.can_approve" size="mini" type="primary" @click="handleProjectClose(scope.row, '转项目')">转项目</el-button>
                <el-button
                  v-if="isAdmin"
                  size="mini"
                  type="danger"
                  @click="deleteSelectedApprovals(scope.row)"
                >
                  删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination-bar">
            <el-pagination
              background
              layout="total, sizes, prev, pager, next"
              :current-page="pendingPagination.page"
              :page-size="pendingPagination.pageSize"
              :page-sizes="[10, 20, 50]"
              :total="pendingApprovals.length"
              @size-change="handlePendingPageSizeChange"
              @current-change="handlePendingPageChange"
            />
          </div>
        </el-tab-pane>

        <el-tab-pane v-if="canApprove" label="样机物料审核" name="assetAudit">
          <el-table
            v-loading="loading"
            :data="pagedAssetAuditApprovals"
            border
            style="width: 100%"
          >
            <el-table-column prop="source_type" label="类型" width="80" />
            <el-table-column prop="item_name" label="物品名称" min-width="160" show-overflow-tooltip />
            <el-table-column prop="receive_code" label="领用编码" width="140" show-overflow-tooltip />
            <el-table-column label="单号" width="150" show-overflow-tooltip>
              <template slot-scope="scope">
                <el-link
                  v-if="isFlowOrderClickable(scope.row)"
                  type="primary"
                  :underline="false"
                  @click="openDetail(scope.row)"
                >
                  {{ flowOrderText(scope.row) }}
                </el-link>
                <span v-else>{{ flowOrderText(scope.row) }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="total_quantity" label="总数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="remain_quantity" label="剩余数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="out_number" label="出账数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="submitter" label="提交人" width="120" />
            <el-table-column prop="created_at" label="提交时间" width="180" />
            <el-table-column label="操作" width="230">
              <template slot-scope="scope">
                <el-button size="mini" @click="openDetail(scope.row)">详情</el-button>
                <el-button v-if="scope.row.can_approve" size="mini" type="primary" @click="approve(scope.row)">审核</el-button>
                <el-button v-if="scope.row.can_approve" size="mini" type="danger" @click="reject(scope.row)">拒绝</el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination-bar">
            <el-pagination
              background
              layout="total, sizes, prev, pager, next"
              :current-page="assetAuditPagination.page"
              :page-size="assetAuditPagination.pageSize"
              :page-sizes="[10, 20, 50]"
              :total="assetAuditApprovals.length"
              @size-change="handleAssetAuditPageSizeChange"
              @current-change="handleAssetAuditPageChange"
            />
          </div>
        </el-tab-pane>

        <el-tab-pane v-if="canApprove" label="月度审核" name="monthlyAudit">
          <el-table
            v-loading="loading"
            :data="pagedMonthlyAuditApprovals"
            border
            style="width: 100%"
          >
            <el-table-column prop="order_number" label="单号" min-width="230" show-overflow-tooltip />
            <el-table-column prop="audit_month" label="月份" width="110" />
            <el-table-column prop="project_name" label="项目" min-width="180" show-overflow-tooltip />
            <el-table-column label="当前状态" width="120">
              <template slot-scope="scope">
                <el-tag :type="statusTagType(scope.row.status)">
                  {{ monthlyStatusText(scope.row.status) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="120">
              <template slot-scope="scope">
                <el-button size="mini" @click="openDetail(scope.row)">详情</el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination-bar">
            <el-pagination
              background
              layout="total, sizes, prev, pager, next"
              :current-page="monthlyAuditPagination.page"
              :page-size="monthlyAuditPagination.pageSize"
              :page-sizes="[10, 20, 50]"
              :total="monthlyAuditApprovals.length"
              @size-change="handleMonthlyAuditPageSizeChange"
              @current-change="handleMonthlyAuditPageChange"
            />
          </div>
        </el-tab-pane>

        <el-tab-pane v-if="user.category !== '工程师'" label="我的提交" name="submitted">
          <el-table
            v-loading="loading"
            :data="pagedSubmittedApprovals"
            border
            style="width: 100%"
          >
            <el-table-column prop="source_type" label="类型" width="80" />
            <el-table-column prop="item_name" label="物品名称" min-width="160" show-overflow-tooltip />
            <el-table-column prop="receive_code" label="领用编码" width="140" show-overflow-tooltip />
            <el-table-column label="单号/领料单号" width="150" show-overflow-tooltip>
              <template slot-scope="scope">
                <el-link
                  v-if="isFlowOrderClickable(scope.row)"
                  type="primary"
                  :underline="false"
                  @click="openDetail(scope.row)"
                >
                  {{ flowOrderText(scope.row) }}
                </el-link>
                <span v-else>{{ flowOrderText(scope.row) }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="total_quantity" label="总数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="remain_quantity" label="剩余数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="out_number" label="出账数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="engineer" label="审批工程师" width="140" />
            <el-table-column label="状态" width="100">
              <template slot-scope="scope">
                <el-tag :type="statusTagType(scope.row.status)">
                  {{ statusText(scope.row.status) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="created_at" label="提交时间" width="180" />
            <el-table-column prop="approved_at" label="审批时间" width="180" />
            <el-table-column label="操作" width="150">
              <template slot-scope="scope">
                <el-button
                  size="mini"
                  @click="openDetail(scope.row)"
                >
                  详情
                </el-button>
                <el-button
                  v-if="isAdmin"
                  size="mini"
                  type="danger"
                  @click="deleteApproval(scope.row)"
                >
                  删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination-bar">
            <el-pagination
              background
              layout="total, sizes, prev, pager, next"
              :current-page="submittedPagination.page"
              :page-size="submittedPagination.pageSize"
              :page-sizes="[10, 20, 50]"
              :total="submittedApprovals.length"
              @size-change="handleSubmittedPageSizeChange"
              @current-change="handleSubmittedPageChange"
            />
          </div>
        </el-tab-pane>

        <el-tab-pane label="操作记录" name="operation">
          <el-table
            v-loading="loading"
            :data="pagedOperationRecords"
            border
            style="width: 100%"
          >
            <el-table-column prop="source_type" label="类型" width="80" />
            <el-table-column prop="item_name" label="物品名称" min-width="160" show-overflow-tooltip />
            <el-table-column prop="receive_code" label="领用编码" width="140" show-overflow-tooltip />
            <el-table-column label="单号" width="150" show-overflow-tooltip>
              <template slot-scope="scope">
                <el-link
                  v-if="isFlowOrderClickable(scope.row)"
                  type="primary"
                  :underline="false"
                  @click="openDetail(scope.row)"
                >
                  {{ flowOrderText(scope.row) }}
                </el-link>
                <span v-else>{{ flowOrderText(scope.row) }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="out_number" label="出账数量" width="100" :formatter="integerFormatter" />
            <el-table-column prop="submitter" label="提交人" width="120" />
            <el-table-column label="状态" width="100">
              <template slot-scope="scope">
                <el-tag :type="statusTagType(scope.row.status)">
                  {{ statusText(scope.row.status) }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="created_at" label="提交时间" width="180" />
            <el-table-column prop="approved_at" label="审批时间" width="180" />
            <el-table-column label="操作" width="150">
              <template slot-scope="scope">
                <el-button size="mini" @click="openDetail(scope.row)">
                  详情
                </el-button>
                <el-button
                  v-if="isAdmin"
                  size="mini"
                  type="danger"
                  @click="deleteApproval(scope.row)"
                >
                  删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="pagination-bar">
            <el-pagination
              background
              layout="total, sizes, prev, pager, next"
              :current-page="operationPagination.page"
              :page-size="operationPagination.pageSize"
              :page-sizes="[10, 20, 50]"
              :total="operationRecords.length"
              @size-change="handleOperationPageSizeChange"
              @current-change="handleOperationPageChange"
            />
          </div>
        </el-tab-pane>
      </el-tabs>
    </el-card>

    <el-dialog
      title="代办详情"
      :visible.sync="detailDialogVisible"
      width="760px"
      append-to-body
      destroy-on-close
      :close-on-click-modal="false"
      @closed="handleDetailDialogClosed"
    >
      <el-descriptions
        v-if="detail && detail.source_type === '销账'"
        :column="2"
        border
      >
        <el-descriptions-item label="销账单号">
          {{ detail.display_order_no }}
        </el-descriptions-item>
        <el-descriptions-item label="申请人">
          {{ detail.applicant }}
        </el-descriptions-item>
        <el-descriptions-item label="当前状态">
          {{ statusText(detail.status) }}
        </el-descriptions-item>
        <el-descriptions-item label="当前审批人">
          {{ detail.engineer }}
        </el-descriptions-item>
        <el-descriptions-item label="创建时间">
          {{ detail.created_at }}
        </el-descriptions-item>
        <el-descriptions-item label="完成时间">
          {{ detail.approved_at }}
        </el-descriptions-item>
      </el-descriptions>

      <div v-if="detail && detail.source_type === '销账'" class="writeoff-flow">
        <el-steps
          :active="writeoffActiveStep"
          :process-status="writeoffProcessStatus"
          finish-status="success"
          align-center
        >
          <el-step
            v-for="step in writeoffSteps"
            :key="step.key"
            :title="step.label"
            :description="writeoffStepDescription(step)"
            :status="writeoffStepVisualStatus(step)"
          />
        </el-steps>
        <el-table :data="writeoffSteps" border style="width:100%; margin-top:12px">
          <el-table-column prop="label" label="步骤" width="120" />
          <el-table-column prop="approver" label="审批人" width="140" />
          <el-table-column prop="approved_by" label="实际操作人" width="140" />
          <el-table-column label="状态" width="110">
            <template slot-scope="scope">
              {{ writeoffStepStatusText(scope.row.status) }}
            </template>
          </el-table-column>
          <el-table-column prop="approved_at" label="审批时间" min-width="170" />
        </el-table>
        <el-table :data="detail.items || []" border style="width:100%; margin-top:12px" max-height="220">
          <el-table-column prop="source_type" label="类型" width="80" />
          <el-table-column prop="project_name" label="项目" min-width="140" show-overflow-tooltip />
          <el-table-column prop="identity_code" label="身份编码" width="140" show-overflow-tooltip />
          <el-table-column prop="item_name" label="名称" min-width="150" show-overflow-tooltip />
          <el-table-column prop="total_quantity" label="总数量" width="100" :formatter="integerFormatter" />
          <el-table-column prop="available_quantity" label="可销账数量" width="110" :formatter="integerFormatter" />
        </el-table>
      </div>

      <el-descriptions
        v-if="detail && detail.source_type === '物料转移'"
        :column="2"
        border
      >
        <el-descriptions-item label="单号">
          {{ detail.display_order_no }}
        </el-descriptions-item>
        <el-descriptions-item label="物品名称">
          {{ detail.item_name }}
        </el-descriptions-item>
        <el-descriptions-item label="领用编码">
          {{ detail.receive_code }}
        </el-descriptions-item>
        <el-descriptions-item label="数量">
          {{ formatInteger(detail.quantity) }}
        </el-descriptions-item>
        <el-descriptions-item label="原项目">
          {{ detail.old_project_name }}
        </el-descriptions-item>
        <el-descriptions-item label="转入项目">
          {{ detail.new_project_name }}
        </el-descriptions-item>
        <el-descriptions-item label="原项目责任人">
          {{ detail.old_project_manager }}
        </el-descriptions-item>
        <el-descriptions-item label="转入责任人">
          {{ detail.new_responsible }}
        </el-descriptions-item>
        <el-descriptions-item label="转入项目经理">
          {{ detail.new_project_manager }}
        </el-descriptions-item>
        <el-descriptions-item label="当前审批节点">
          {{ detail.current_step_text }}
        </el-descriptions-item>
        <el-descriptions-item label="当前审批人">
          {{ detail.current_approver }}
        </el-descriptions-item>
        <el-descriptions-item label="申请人">
          {{ detail.applicant }}
        </el-descriptions-item>
        <el-descriptions-item label="审批状态">
          {{ statusText(detail.status) }}
        </el-descriptions-item>
        <el-descriptions-item label="审批人">
          {{ detail.approved_by }}
        </el-descriptions-item>
        <el-descriptions-item label="审批时间">
          {{ detail.approved_at }}
        </el-descriptions-item>
        <el-descriptions-item label="备注" :span="2">
          {{ detail.remark }}
        </el-descriptions-item>
      </el-descriptions>
      <el-table
        v-if="detail && detail.source_type === '物料转移'"
        :data="detail.steps || []"
        border
        style="width:100%; margin-top:12px"
      >
        <el-table-column prop="label" label="步骤" width="120" />
        <el-table-column prop="approver" label="审批人" width="140" />
        <el-table-column prop="approved_by" label="实际操作人" width="140" />
        <el-table-column label="状态" width="110">
          <template slot-scope="scope">{{ writeoffStepStatusText(scope.row.status) }}</template>
        </el-table-column>
        <el-table-column prop="approved_at" label="审批时间" min-width="170" />
      </el-table>

      <el-descriptions
        v-if="detail && detail.source_type !== '样机' && detail.source_type !== '销账' && detail.source_type !== '物料转移'"
        :column="2"
        border
      >
        <el-descriptions-item label="物品名称">
          {{ detail.item_name }}
        </el-descriptions-item>
        <el-descriptions-item label="物品来源">
          {{ detail.item_source }}
        </el-descriptions-item>
        <el-descriptions-item label="领用编码">
          {{ detail.receive_code }}
        </el-descriptions-item>
        <el-descriptions-item label="catlog编码">
          {{ detail.catlog_code }}
        </el-descriptions-item>
        <el-descriptions-item label="领料单号">
          {{ detail.order_number }}
        </el-descriptions-item>
        <el-descriptions-item label="单价">
          {{ detail.unit_price }}
        </el-descriptions-item>
        <el-descriptions-item :label="detail.source_type === '研发入账' ? '入账数量' : '总数量'">
          {{ formatInteger(detail.quantity) }}
        </el-descriptions-item>
        <el-descriptions-item v-if="detail.source_type !== '研发入账'" label="剩余数量">
          {{ formatInteger(detail.remain_quantity) }}
        </el-descriptions-item>
        <el-descriptions-item v-if="detail.source_type !== '研发入账'" label="申请出账数量">
          {{ formatInteger(detail.out_number) }}
        </el-descriptions-item>
        <el-descriptions-item label="存放位置">
          {{ detail.material_storage_location }}
        </el-descriptions-item>
        <el-descriptions-item label="物料提供人">
          {{ detail.material_provider }}
        </el-descriptions-item>
        <el-descriptions-item label="物料领取人">
          {{ detail.material_recipient }}
        </el-descriptions-item>
        <el-descriptions-item label="录入人">
          {{ detail.entry_person }}
        </el-descriptions-item>
        <el-descriptions-item label="提交人">
          {{ detail.submitter }}
        </el-descriptions-item>
        <el-descriptions-item label="审批工程师">
          {{ detail.engineer }}
        </el-descriptions-item>
        <el-descriptions-item label="审批状态">
          {{ statusText(detail.status) }}
        </el-descriptions-item>
        <el-descriptions-item label="审批时间">
          {{ detail.approved_at }}
        </el-descriptions-item>
        <el-descriptions-item label="项目名称">
          {{ detail.project_name }}
        </el-descriptions-item>
        <el-descriptions-item label="绑定样机">
          {{ boundPrototypeText(detail) }}
        </el-descriptions-item>
        <el-descriptions-item v-if="detail.carry_out_number" label="携物出门单号" :span="2">
          {{ detail.carry_out_number }}
        </el-descriptions-item>
        <el-descriptions-item label="用途" :span="2">
          {{ detail.purpose }}
        </el-descriptions-item>
        <el-descriptions-item label="备注" :span="2">
          {{ detail.remark }}
        </el-descriptions-item>
      </el-descriptions>

      <el-descriptions
        v-if="detail && detail.source_type === '样机'"
        :column="2"
        border
      >
        <el-descriptions-item label="物品名称">
          {{ detail.item_name }}
        </el-descriptions-item>
        <el-descriptions-item label="申请出账数量">
          {{ formatInteger(detail.out_number) }}
        </el-descriptions-item>
        <el-descriptions-item label="存放位置">
          {{ detail.material_storage_location }}
        </el-descriptions-item>
        <el-descriptions-item label="领用人">
          {{ detail.material_recipient }}
        </el-descriptions-item>
        <el-descriptions-item label="交付产品线">
          {{ detail.delivery_product_line }}
        </el-descriptions-item>
        <el-descriptions-item label="研发工程师">
          {{ detail.delivery_rd_engineer }}
        </el-descriptions-item>
        <el-descriptions-item label="携物出门单号">
          {{ detail.carry_out_number }}
        </el-descriptions-item>
        <el-descriptions-item label="录入人">
          {{ detail.entry_person }}
        </el-descriptions-item>
        <el-descriptions-item label="提交人">
          {{ detail.submitter }}
        </el-descriptions-item>
        <el-descriptions-item label="审批工程师">
          {{ detail.engineer }}
        </el-descriptions-item>
        <el-descriptions-item label="审批状态">
          {{ statusText(detail.status) }}
        </el-descriptions-item>
        <el-descriptions-item label="审批时间">
          {{ detail.approved_at }}
        </el-descriptions-item>
        <el-descriptions-item label="用途" :span="2">
          {{ detail.purpose }}
        </el-descriptions-item>
        <el-descriptions-item label="备注" :span="2">
          {{ detail.remark }}
        </el-descriptions-item>
      </el-descriptions>

      <div v-if="detailRows.length" class="batch-detail">
        <div class="batch-detail-title">
          批次明细
        </div>
        <el-table
          v-if="detail.source_type === '样机'"
          :data="detailRows"
          border
          max-height="260"
          style="width: 100%"
        >
          <el-table-column prop="item_name" label="样机名称" min-width="150" show-overflow-tooltip />
          <el-table-column prop="identity_code" label="样机编号" width="140" show-overflow-tooltip />
          <el-table-column prop="out_number" label="出账数量" width="90" :formatter="integerFormatter" />
          <el-table-column prop="material_recipient" label="领用人" width="110" show-overflow-tooltip />
          <el-table-column prop="delivery_product_line" label="交付产品线" width="130" show-overflow-tooltip />
          <el-table-column prop="delivery_rd_engineer" label="研发工程师" width="120" show-overflow-tooltip />
          <el-table-column prop="carry_out_number" label="携物出门单号" width="140" show-overflow-tooltip />
          <el-table-column prop="purpose" label="用途" width="110" show-overflow-tooltip />
          <el-table-column label="状态" width="90">
            <template slot-scope="scope">
              {{ statusText(scope.row.status) }}
            </template>
          </el-table-column>
          <el-table-column prop="remark" label="备注" min-width="150" show-overflow-tooltip />
        </el-table>

        <el-table
          v-else
          :data="detailRows"
          border
          max-height="260"
          style="width: 100%"
        >
          <el-table-column prop="project_name" label="项目" width="120" show-overflow-tooltip />
          <el-table-column prop="receive_code" label="领用编码" width="120" show-overflow-tooltip />
          <el-table-column prop="item_name" label="物品名称" min-width="150" show-overflow-tooltip />
          <el-table-column prop="out_number" label="出账数量" width="90" :formatter="integerFormatter" />
          <el-table-column prop="material_storage_location" label="存放位置" width="130" show-overflow-tooltip />
          <el-table-column prop="material_recipient" label="物料领取人" width="120" show-overflow-tooltip />
          <el-table-column prop="prototype_name" label="绑定样机" width="140" show-overflow-tooltip />
          <el-table-column prop="prototype_code" label="样机编号" width="130" show-overflow-tooltip />
          <el-table-column prop="purpose" label="用途" width="110" show-overflow-tooltip />
          <el-table-column label="状态" width="90">
            <template slot-scope="scope">
              {{ statusText(scope.row.status) }}
            </template>
          </el-table-column>
          <el-table-column prop="remark" label="备注" min-width="150" show-overflow-tooltip />
        </el-table>
      </div>

      <div class="detail-image">
        <img
          v-if="detailImageUrl"
          :src="detailImageUrl"
          alt="物品图片"
        >
        <el-empty v-else description="暂无图片" />
      </div>
    </el-dialog>

    <el-dialog
      title="月度审核详情"
      :visible.sync="monthlyDetailDialogVisible"
      width="780px"
      append-to-body
      destroy-on-close
      :close-on-click-modal="false"
      @closed="handleMonthlyDetailClosed"
    >
      <el-descriptions v-if="monthlyDetail" :column="2" border>
        <el-descriptions-item label="单号">
          {{ monthlyDetail.order_number }}
        </el-descriptions-item>
        <el-descriptions-item label="月份">
          {{ monthlyDetail.audit_month }}
        </el-descriptions-item>
        <el-descriptions-item label="项目">
          {{ monthlyDetail.project_name }}
        </el-descriptions-item>
        <el-descriptions-item label="当前状态">
          <el-tag :type="statusTagType(monthlyDetail.status)">
            {{ monthlyStatusText(monthlyDetail.status) }}
          </el-tag>
        </el-descriptions-item>
      </el-descriptions>

      <el-table
        :data="monthlyDetailRows"
        border
        height="360"
        class="monthly-detail-table"
        style="width: 100%"
      >
        <el-table-column prop="sourceType" label="类型" width="80" />
        <el-table-column prop="itemName" label="物品名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="totalQuantity" label="总数量" width="100" :formatter="integerFormatter" />
        <el-table-column prop="usedQuantity" label="使用数量" width="100" :formatter="integerFormatter" />
        <el-table-column prop="lossQuantity" label="损耗数量" width="100" :formatter="integerFormatter" />
        <el-table-column prop="lossRatio" label="损耗比例" width="110" />
      </el-table>

      <span slot="footer">
        <el-button @click="monthlyDetailDialogVisible = false">关闭</el-button>
        <el-button
          v-if="monthlyDetail && monthlyDetail.can_approve && monthlyDetail.status === 'pending'"
          type="danger"
          @click="rejectMonthlyAudit"
        >
          驳回
        </el-button>
        <el-button
          v-if="monthlyDetail && monthlyDetail.can_approve && monthlyDetail.status === 'pending'"
          type="primary"
          @click="approveMonthlyAudit"
        >
          通过
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="转项目"
      :visible.sync="transferDialogVisible"
      width="420px"
      append-to-body
      destroy-on-close
      :close-on-click-modal="false"
    >
      <el-form label-width="90px">
        <el-form-item label="当前项目">
          <el-input :value="transferNotification ? transferNotification.project_name : ''" disabled />
        </el-form-item>
        <el-form-item label="目标项目" required>
          <el-select v-model="transferTargetProject" filterable clearable placeholder="请选择目标项目" style="width:100%">
            <el-option
              v-for="project in availableTransferProjects"
              :key="project.id"
              :label="project.project_name"
              :value="project.project_name"
            />
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="transferDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitTransferProject">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import axios from "axios"
import { API_BASE } from "../../config/appConfig"
import { isSameData } from "../../utils/dataChange"

export default {
  props: {
    initialTab: {
      type: String,
      default: ""
    },
    embedded: {
      type: Boolean,
      default: false
    }
  },

  data() {
    return {
      activeTab: this.initialTab || "pending",
      loading: false,
      user: {},
      approvals: [],
      searchKeyword: "",
      searchType: "",
      detailDialogVisible: false,
      detail: null,
      monthlyDetailDialogVisible: false,
      monthlyDetail: null,
      monthlyDetailRows: [],
      projectOptions: [],
      transferDialogVisible: false,
      transferNotification: null,
      transferTargetProject: "",
      selectedPendingRows: [],
      pendingPagination: {
        page: 1,
        pageSize: 10
      },
      assetAuditPagination: {
        page: 1,
        pageSize: 10
      },
      monthlyAuditPagination: {
        page: 1,
        pageSize: 10
      },
      submittedPagination: {
        page: 1,
        pageSize: 10
      },
      operationPagination: {
        page: 1,
        pageSize: 10
      },
      refreshTimer: null
    }
  },

  computed: {
    isAdmin() {
      return Number(this.user.permissions) === 1
    },

    pendingApprovals() {
      if (this.isAdmin) {
        return this.filteredApprovals.filter(item => item.status === "pending")
      }

      if (!this.canApprove) {
        return []
      }

      return this.filteredApprovals.filter(item => item.can_approve)
    },

    submittedApprovals() {
      return this.filteredApprovals.filter(item => item.submitter === this.user.username)
    },

    assetAuditApprovals() {
      if (!this.canApprove) {
        return []
      }

      return this.filteredApprovals.filter(item => {
        const isAuditType = ["物料", "研发入账", "样机", "销账", "物料转移"].includes(item.source_type)
        const isPending = item.status === "pending"
        return isAuditType && isPending && (this.isAdmin || item.can_approve)
      })
    },

    monthlyAuditApprovals() {
      if (!this.canApprove) {
        return []
      }

      return this.filteredApprovals.filter(item => {
        return item.source_type === "月度审核"
      })
    },

    operationRecords() {
      const rows = this.isAdmin
        ? this.filteredApprovals.filter(item => item.status !== "pending")
        : this.filteredApprovals.filter(item => item.engineer === this.user.username && item.status !== "pending")

      return rows.slice().sort((left, right) => {
        const approvedCompare = String(right.approved_at || "").localeCompare(String(left.approved_at || ""))
        if (approvedCompare !== 0) {
          return approvedCompare
        }

        const createdCompare = String(right.created_at || "").localeCompare(String(left.created_at || ""))
        if (createdCompare !== 0) {
          return createdCompare
        }

        return Number(right.id || 0) - Number(left.id || 0)
      })
    },

    pagedPendingApprovals() {
      return this.paginateRows(this.pendingApprovals, this.pendingPagination)
    },

    pagedSubmittedApprovals() {
      return this.paginateRows(this.submittedApprovals, this.submittedPagination)
    },

    pagedAssetAuditApprovals() {
      return this.paginateRows(this.assetAuditApprovals, this.assetAuditPagination)
    },

    pagedMonthlyAuditApprovals() {
      return this.paginateRows(this.monthlyAuditApprovals, this.monthlyAuditPagination)
    },

    pagedOperationRecords() {
      return this.paginateRows(this.operationRecords, this.operationPagination)
    },

    filteredApprovals() {
      const keyword = this.searchKeyword.trim()

      return this.approvals.filter(item => {
        if (this.searchType && item.source_type !== this.searchType) {
          return false
        }

        if (!keyword) {
          return true
        }

        return [item.item_name, item.project_name, item.audit_month, item.submitter, item.engineer, item.receive_code, item.order_number]
          .some(value => String(value || "").includes(keyword))
      })
    },

    pendingCount() {
      if (!this.canApprove) {
        return 0
      }

      return this.approvals.filter(item => item.status === "pending" && (this.isAdmin || item.can_approve)).length
    },

    canApprove() {
      const additionalRoles = String(this.user.additionalRole || "")
        .replace(/[，、；;|/\s]+/g, ",")
        .split(",")
        .map(item => item.trim())
        .filter(Boolean)

      return this.isAdmin ||
        this.user.category === "工程师" ||
        additionalRoles.some(role => ["项目经理", "复盘人", "实验室主任", "高级专家"].includes(role))
    },

    availableTransferProjects() {
      const currentProject = this.transferNotification ? this.transferNotification.project_name : ""
      return this.projectOptions.filter(item => item.status !== "结项" && item.project_name !== currentProject)
    },

    pageTitle() {
      const titleMap = {
        pending: "待我审批",
        assetAudit: "样机物料审核",
        monthlyAudit: "月度审核",
        submitted: "我的提交",
        operation: "操作记录"
      }
      return titleMap[this.activeTab] || "样机物料审核"
    },

    detailImageUrl() {
      if (!this.detail) {
        return ""
      }

      const imagePath = this.detail.approval_image_path || this.detail.image_path
      return imagePath ? `${API_BASE}${imagePath}` : ""
    },

    detailRows() {
      if (!this.detail || !Array.isArray(this.detail.rows)) {
        return []
      }

      return this.detail.rows
    },

    writeoffSteps() {
      if (!this.detail || !Array.isArray(this.detail.steps)) {
        return []
      }
      return this.detail.steps
    },

    writeoffActiveStep() {
      const steps = this.writeoffSteps
      if (!steps.length) {
        return 0
      }
      const pendingIndex = steps.findIndex(item => item.status === "pending")
      if (pendingIndex >= 0) {
        return pendingIndex
      }
      const rejectedIndex = steps.findIndex(item => item.status === "rejected")
      if (rejectedIndex >= 0) {
        return rejectedIndex
      }
      return steps.filter(item => item.status === "approved").length
    },

    writeoffProcessStatus() {
      return this.writeoffSteps.some(item => item.status === "rejected") ? "error" : "process"
    }
  },

  watch: {
    "$route.fullPath"() {
      if (this.embedded) {
        return
      }
      this.applyRouteTab()
    },
    initialTab() {
      if (this.embedded) {
        this.applyRouteTab()
      }
    },
    searchKeyword() {
      this.resetPagination()
    },
    searchType() {
      this.resetPagination()
    },
    activeTab() {
      this.resetPagination()
    }
  },

  created() {
    const user = localStorage.getItem("user")

    if (user) {
      this.user = JSON.parse(user)
    }

    this.refreshCurrentUser()
    this.fetchApprovals()
    this.fetchProjectOptions()
    this.applyRouteTab()
    this.refreshTimer = setInterval(() => this.fetchApprovals(true), 10000)
  },

  beforeDestroy() {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer)
    }
  },

  methods: {
    refreshCurrentUser() {
      if (!this.user.username) {
        return
      }

      axios.get(`${API_BASE}/user/profile/${encodeURIComponent(this.user.username)}`).then(res => {
        if (res.data.code !== 200 || !res.data.data) {
          return
        }

        this.user = Object.assign({}, this.user, res.data.data)
        localStorage.setItem("user", JSON.stringify(this.user))
        this.applyRouteTab()
        this.fetchApprovals(true)
      }).catch(() => {})
    },
    applyRouteTab() {
      const requestedTab = this.embedded ? this.initialTab : this.$route.query.tab
      const validTabs = ["pending", "assetAudit", "monthlyAudit", "submitted", "operation"]
      const approveTabs = ["pending", "assetAudit", "monthlyAudit"]

      if (validTabs.includes(requestedTab)) {
        if (approveTabs.includes(requestedTab) && !this.canApprove) {
          this.activeTab = "submitted"
          return
        }
        this.activeTab = requestedTab
        return
      }

      if (!this.canApprove) {
        this.activeTab = "submitted"
      }
    },

    paginateRows(rows, pagination) {
      const start = (pagination.page - 1) * pagination.pageSize
      return rows.slice(start, start + pagination.pageSize)
    },

    resetPagination() {
      this.pendingPagination.page = 1
      this.assetAuditPagination.page = 1
      this.monthlyAuditPagination.page = 1
      this.submittedPagination.page = 1
      this.operationPagination.page = 1
      this.selectedPendingRows = []
      this.$nextTick(() => {
        if (this.$refs.pendingTable) {
          this.$refs.pendingTable.clearSelection()
        }
      })
    },

    handlePageSizeChange(type, pageSize) {
      this[`${type}Pagination`].pageSize = pageSize
      this[`${type}Pagination`].page = 1
      if (type === "pending") {
        this.selectedPendingRows = []
      }
    },

    handlePageChange(type, page) {
      this[`${type}Pagination`].page = page
      if (type === "pending") {
        this.selectedPendingRows = []
        this.$nextTick(() => {
          if (this.$refs.pendingTable) {
            this.$refs.pendingTable.clearSelection()
          }
        })
      }
    },

    handlePendingPageSizeChange(pageSize) {
      this.handlePageSizeChange("pending", pageSize)
    },

    handlePendingPageChange(page) {
      this.handlePageChange("pending", page)
    },

    handleAssetAuditPageSizeChange(pageSize) {
      this.handlePageSizeChange("assetAudit", pageSize)
    },

    handleAssetAuditPageChange(page) {
      this.handlePageChange("assetAudit", page)
    },

    handleMonthlyAuditPageSizeChange(pageSize) {
      this.handlePageSizeChange("monthlyAudit", pageSize)
    },

    handleMonthlyAuditPageChange(page) {
      this.handlePageChange("monthlyAudit", page)
    },

    handleSubmittedPageSizeChange(pageSize) {
      this.handlePageSizeChange("submitted", pageSize)
    },

    handleSubmittedPageChange(page) {
      this.handlePageChange("submitted", page)
    },

    handleOperationPageSizeChange(pageSize) {
      this.handlePageSizeChange("operation", pageSize)
    },

    handleOperationPageChange(page) {
      this.handlePageChange("operation", page)
    },

    clampPagination(pagination, total) {
      const maxPage = Math.max(Math.ceil(total / pagination.pageSize), 1)
      pagination.page = Math.min(pagination.page, maxPage)
    },

    clampPaginationPages() {
      this.clampPagination(this.pendingPagination, this.pendingApprovals.length)
      this.clampPagination(this.assetAuditPagination, this.assetAuditApprovals.length)
      this.clampPagination(this.monthlyAuditPagination, this.monthlyAuditApprovals.length)
      this.clampPagination(this.submittedPagination, this.submittedApprovals.length)
      this.clampPagination(this.operationPagination, this.operationRecords.length)
    },

    isPendingSelectable(row) {
      return Boolean(row && row.source_type !== "项目结项" && (row.can_approve || this.isAdmin))
    },

    canBatchApproveRow(row) {
      return Boolean(row && row.can_approve && row.source_type !== "项目结项")
    },

    approvalRowKey(row) {
      return `${row.source_type}-${row.id}`
    },

    handlePendingSelectionChange(rows) {
      this.selectedPendingRows = rows
    },

    getSelectedOrCurrentRows(row, filter) {
      const sourceRows = this.selectedPendingRows.length ? this.selectedPendingRows : [row]
      return sourceRows.filter(filter)
    },

    runApprovalAction(rows, action, actionText) {
      if (!rows.length) {
        this.$message.warning(`没有可以${actionText}的待办记录`)
        return
      }

      this.$confirm(`确认${actionText}${rows.length > 1 ? `选中的 ${rows.length} 条` : "当前"}审批记录？`, actionText, {
        type: "warning"
      }).then(() => {
        this.loading = true
        Promise.all(rows.map(item => axios.post(`${API_BASE}/approval/${action}/${item.id}`, {
          username: this.user.username,
          sourceType: item.source_type,
          permissions: this.user.permissions
        }).then(res => ({
          success: res.data.code === 200,
          msg: res.data.msg
        })).catch(() => ({
          success: false,
          msg: "网络请求失败"
        })))).then(results => {
          const successCount = results.filter(item => item.success).length
          const failCount = results.length - successCount
          if (successCount) {
            this.$message.success(`${actionText}完成，成功 ${successCount} 条${failCount ? `，失败 ${failCount} 条` : ""}`)
          } else {
            this.$message.error(results[0].msg || `${actionText}失败`)
          }
          this.selectedPendingRows = []
          this.fetchApprovals()
        }).finally(() => {
          this.loading = false
        })
      }).catch(() => {})
    },

    approve(row) {
      const rows = this.getSelectedOrCurrentRows(row, this.canBatchApproveRow)
      this.runApprovalAction(rows, "approve", "审批")
    },

    reject(row) {
      const rows = this.getSelectedOrCurrentRows(row, this.canBatchApproveRow)
      this.runApprovalAction(rows, "reject", "拒绝")
    },

    deleteSelectedApprovals(row) {
      const rows = this.getSelectedOrCurrentRows(
        row,
        item => item && item.source_type !== "项目结项"
      )
      if (!rows.length) {
        this.$message.warning("没有可以删除的审批记录")
        return
      }

      this.$confirm(`确认删除${rows.length > 1 ? `选中的 ${rows.length} 条` : "当前"}审批记录？`, "删除", {
        type: "warning"
      }).then(() => {
        this.loading = true
        Promise.all(rows.map(item => axios.delete(`${API_BASE}/approval/delete/${item.id}`, {
          params: {
            permissions: this.user.permissions,
            sourceType: item.source_type
          }
        }).then(res => ({
          success: res.data.code === 200,
          msg: res.data.msg
        })).catch(() => ({
          success: false,
          msg: "网络请求失败"
        })))).then(results => {
          const successCount = results.filter(item => item.success).length
          const failCount = results.length - successCount
          if (successCount) {
            this.$message.success(`删除完成，成功 ${successCount} 条${failCount ? `，失败 ${failCount} 条` : ""}`)
          } else {
            this.$message.error(results[0].msg || "删除失败")
          }
          this.selectedPendingRows = []
          this.fetchApprovals()
        }).finally(() => {
          this.loading = false
        })
      }).catch(() => {})
    },

    handleProjectClose(row, action) {
      if (action === "转项目") {
        this.transferNotification = row
        this.transferTargetProject = ""
        this.fetchProjectOptions()
        this.transferDialogVisible = true
        return
      }
      this.submitProjectCloseAction(row, action, "")
    },

    fetchProjectOptions() {
      axios.get(`${API_BASE}/project/list`).then(res => {
        if (res.data.code === 200) {
          this.projectOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    submitTransferProject() {
      if (!this.transferTargetProject) {
        this.$message.warning("请选择目标项目")
        return
      }
      this.submitProjectCloseAction(this.transferNotification, "转项目", this.transferTargetProject)
      this.transferDialogVisible = false
    },

    submitProjectCloseAction(row, action, targetProject) {
      axios.post(`${API_BASE}/project/notification/action/${row.id}`, {
        username: this.user.username,
        action,
        targetProject
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.fetchApprovals()
        } else {
          this.$message.warning(res.data.msg || "处理失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    fetchApprovals(silent = false) {
      silent = silent === true
      if (!this.user.username) {
        return
      }

      if (!silent) {
        this.loading = true
      }

      axios.get(`${API_BASE}/approval/list`, {
        params: {
          username: this.user.username,
          permissions: this.user.permissions
        }
      }).then(res => {
        if (res.data.code === 200) {
          const nextApprovals = res.data.data || []
          if (!isSameData(this.approvals, nextApprovals)) {
            this.approvals = nextApprovals
            this.$emit("approval-updated", nextApprovals)
            this.selectedPendingRows = []
            this.$nextTick(() => {
              this.clampPaginationPages()
              if (this.$refs.pendingTable) {
                this.$refs.pendingTable.clearSelection()
              }
            })
          }
        } else if (!silent) {
          this.$message.error(res.data.msg || "获取代办失败")
        }
      }).catch(err => {
        console.log(err)
        if (!silent) {
          this.$message.error("网络请求失败，请检查后端是否启动")
        }
      }).finally(() => {
        if (!silent) {
          this.loading = false
        }
      })
    },

    handleDetailDialogClosed() {
      this.detail = null
    },

    handleMonthlyDetailClosed() {
      this.monthlyDetail = null
      this.monthlyDetailRows = []
    },

    flowOrderText(row) {
      const value = row && (row.display_order_no || row.order_no || row.order_number || row.orderNo)
      const text = String(value || "").trim()
      if (text) {
        return text
      }
      if (!row || !row.id) {
        return "-"
      }
      if (row.source_type === "销账") {
        return `XZ-${row.id}`
      }
      if (row.source_type === "物料转移") {
        return `ZY-${row.id}`
      }
      if (String(row.source_type || "").includes("报废")) {
        return `BF-${row.id}`
      }
      return row.order_number || "-"
    },

    isFlowOrderClickable(row) {
      return ["销账", "物料转移"].includes(row && row.source_type) ||
        String(row && row.source_type || "").includes("报废")
    },

    openDetail(row) {
      if (row.source_type === "月度审核") {
        this.openMonthlyDetail(row)
        return
      }

      axios.get(`${API_BASE}/approval/detail/${row.id}`, {
        params: {
          sourceType: row.source_type
        }
      }).then(res => {
        if (res.data.code === 200) {
          const detail = Object.assign({}, res.data.data)
          const displayOrderNo = this.flowOrderText(Object.assign({}, row, detail))
          detail.display_order_no = displayOrderNo
          detail.order_no = detail.order_no || displayOrderNo
          detail.order_number = detail.order_number || displayOrderNo
          this.detail = detail
          this.detailDialogVisible = true
        } else {
          this.$message.error(res.data.msg || "获取详情失败")
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    openMonthlyDetail(row) {
      axios.get(`${API_BASE}/approval/detail/${row.id}`, {
        params: {
          sourceType: row.source_type
        }
      }).then(res => {
        if (res.data.code === 200) {
          this.monthlyDetail = Object.assign({}, res.data.data, {
            can_approve: row.can_approve
          })
          this.monthlyDetailRows = res.data.data.rows || []
          this.monthlyDetailDialogVisible = true
        } else {
          this.$message.error(res.data.msg || "获取月度审核详情失败")
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    approveMonthlyAudit() {
      this.submitMonthlyAuditAction("approve", "通过")
    },

    rejectMonthlyAudit() {
      this.submitMonthlyAuditAction("reject", "驳回")
    },

    submitMonthlyAuditAction(action, actionText) {
      if (!this.monthlyDetail) {
        return
      }

      this.$confirm(`确认${actionText}当前月度审核单？`, actionText, {
        type: action === "reject" ? "warning" : "success"
      }).then(() => {
        axios.post(`${API_BASE}/approval/${action}/${this.monthlyDetail.id}`, {
          username: this.user.username,
          sourceType: "月度审核"
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.monthlyDetailDialogVisible = false
            this.fetchApprovals()
          } else {
            this.$message.error(res.data.msg || `${actionText}失败`)
          }
        }).catch(() => {
          this.$message.error("网络请求失败，请检查后端是否启动")
        })
      }).catch(() => {})
    },

    generateMonthlyAudit() {
      this.loading = true
      axios.post(`${API_BASE}/monthly_audit/generate`, {
        username: this.user.username,
        permissions: this.user.permissions,
        additionalRole: this.user.additionalRole
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.fetchApprovals()
        } else {
          this.$message.error(res.data.msg || "生成月度审核失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.loading = false
      })
    },

    deleteApproval(row) {
      this.$confirm(`确认删除 ${row.item_name} 的审批记录？`, "提示", {
        type: "warning"
      }).then(() => {
        axios.delete(`${API_BASE}/approval/delete/${row.id}`, {
          params: {
            permissions: this.user.permissions,
            sourceType: row.source_type
          }
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchApprovals()
          } else {
            this.$message.error(res.data.msg || "删除失败")
          }
        }).catch(err => {
          console.log(err)
          this.$message.error("网络请求失败，请检查后端是否启动")
        })
      }).catch(() => {})
    },

    exportCurrentTab() {
      if (this.isAdmin && !["assetAudit", "monthlyAudit"].includes(this.activeTab)) {
        this.exportAdminFullApprovals()
        return
      }

      const tabConfig = this.getCurrentExportConfig()

      if (!tabConfig.rows.length) {
        this.$message.warning("当前页面没有可导出的数据")
        return
      }

      const csvRows = [
        tabConfig.headers.map(item => item.label),
        ...tabConfig.rows.map(row => tabConfig.headers.map(item => item.get(row)))
      ]
      const csvText = "\ufeff" + csvRows.map(row => row.map(this.escapeCsvValue).join(",")).join("\n")
      const blob = new Blob([csvText], { type: "text/csv;charset=utf-8" })
      const link = document.createElement("a")
      link.href = URL.createObjectURL(blob)
      link.download = `${tabConfig.fileName}_${this.formatExportTime()}.csv`
      link.click()
      URL.revokeObjectURL(link.href)
    },

    exportAdminFullApprovals() {
      this.loading = true
      axios.post(`${API_BASE}/approval/export_full`, {
        username: this.user.username,
        permissions: this.user.permissions,
        tab: this.activeTab,
        keyword: this.searchKeyword.trim(),
        sourceType: this.searchType
      }, {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `管理员审批完整信息_${this.formatExportTime()}.xlsx`
        link.click()
        URL.revokeObjectURL(link.href)
      }).catch(() => {
        this.$message.error("导出失败，请稍后重试")
      }).finally(() => {
        this.loading = false
      })
    },

    getCurrentExportConfig() {
      if (this.activeTab === "pending") {
        return {
          fileName: "待我审批",
          rows: this.pendingApprovals,
          headers: [
            { label: "类型", get: row => row.source_type },
            { label: "物品名称", get: row => row.item_name },
            { label: "领用编码", get: row => row.receive_code },
            { label: "领料单号", get: row => row.order_number },
            { label: "总数量", get: row => this.formatInteger(row.total_quantity) },
            { label: "剩余数量", get: row => this.formatInteger(row.remain_quantity) },
            { label: "出账数量", get: row => this.formatInteger(row.out_number) },
            { label: "提交人", get: row => row.submitter },
            { label: "提交时间", get: row => row.created_at }
          ]
        }
      }

      if (this.activeTab === "submitted") {
        return {
          fileName: "我的提交",
          rows: this.submittedApprovals,
          headers: [
            { label: "类型", get: row => row.source_type },
            { label: "物品名称", get: row => row.item_name },
            { label: "领用编码", get: row => row.receive_code },
            { label: "领料单号", get: row => row.order_number },
            { label: "总数量", get: row => this.formatInteger(row.total_quantity) },
            { label: "剩余数量", get: row => this.formatInteger(row.remain_quantity) },
            { label: "出账数量", get: row => this.formatInteger(row.out_number) },
            { label: "审批工程师", get: row => row.engineer },
            { label: "状态", get: row => this.statusText(row.status) },
            { label: "提交时间", get: row => row.created_at },
            { label: "审批时间", get: row => row.approved_at }
          ]
        }
      }

      if (this.activeTab === "assetAudit") {
        return {
          fileName: "样机物料审核",
          rows: this.assetAuditApprovals,
          headers: [
            { label: "类型", get: row => row.source_type },
            { label: "物品名称", get: row => row.item_name },
            { label: "领用编码", get: row => row.receive_code },
            { label: "总数量", get: row => this.formatInteger(row.total_quantity) },
            { label: "剩余数量", get: row => this.formatInteger(row.remain_quantity) },
            { label: "出账数量", get: row => this.formatInteger(row.out_number) },
            { label: "提交人", get: row => row.submitter },
            { label: "提交时间", get: row => row.created_at }
          ]
        }
      }

      if (this.activeTab === "monthlyAudit") {
        return {
          fileName: "月度审核",
          rows: this.monthlyAuditApprovals,
          headers: [
            { label: "单号", get: row => row.order_number },
            { label: "月份", get: row => row.audit_month },
            { label: "项目", get: row => row.project_name },
            { label: "当前状态", get: row => this.monthlyStatusText(row.status) }
          ]
        }
      }

      return {
        fileName: "操作记录",
        rows: this.operationRecords,
        headers: [
          { label: "类型", get: row => row.source_type },
          { label: "物品名称", get: row => row.item_name },
          { label: "领用编码", get: row => row.receive_code },
          { label: "出账数量", get: row => this.formatInteger(row.out_number) },
          { label: "提交人", get: row => row.submitter },
          { label: "状态", get: row => this.statusText(row.status) },
          { label: "提交时间", get: row => row.created_at },
          { label: "审批时间", get: row => row.approved_at }
        ]
      }
    },

    escapeCsvValue(value) {
      const text = value === null || value === undefined ? "" : String(value)
      return `"${text.replace(/"/g, "\"\"")}"`
    },

    statusText(status) {
      if (status === "approved") {
        return "已审批"
      }

      if (status === "rejected") {
        return "已拒绝"
      }

      return "待审批"
    },

    writeoffStepStatusText(status) {
      if (status === "approved") {
        return "已审批"
      }

      if (status === "rejected") {
        return "已拒绝"
      }

      if (status === "waiting") {
        return "未开始"
      }

      return "待审批"
    },

    writeoffStepVisualStatus(step) {
      if (!step) {
        return "wait"
      }

      if (step.status === "approved") {
        return "success"
      }

      if (step.status === "rejected") {
        return "error"
      }

      if (step.status === "pending") {
        return "process"
      }

      return "wait"
    },

    writeoffStepDescription(step) {
      if (!step) {
        return ""
      }

      const values = [`审批人：${step.approver || "-"}`, this.writeoffStepStatusText(step.status)]

      if (step.approved_by) {
        values.push(`操作人：${step.approved_by}`)
      }

      if (step.approved_at) {
        values.push(step.approved_at)
      }

      return values.join(" / ")
    },

    monthlyStatusText(status) {
      if (status === "approved") {
        return "已通过"
      }

      if (status === "rejected") {
        return "已驳回"
      }

      return "待审批"
    },

    statusTagType(status) {
      if (status === "approved") {
        return "success"
      }

      if (status === "rejected") {
        return "danger"
      }

      return "warning"
    },

    boundPrototypeText(detail) {
      if (!detail || !detail.prototype_name) {
        return ""
      }

      return detail.prototype_code
        ? `${detail.prototype_name}/${detail.prototype_code}`
        : detail.prototype_name
    },

    formatInteger(value) {
      if (value === null || value === undefined || value === "") {
        return ""
      }

      const numberValue = Number(value)
      if (!Number.isFinite(numberValue)) {
        return value
      }

      return String(Math.round(numberValue))
    },

    integerFormatter(row, column, cellValue) {
      return this.formatInteger(cellValue)
    },

    formatExportTime() {
      const date = new Date()
      const pad = value => String(value).padStart(2, "0")

      return [
        date.getFullYear(),
        pad(date.getMonth() + 1),
        pad(date.getDate())
      ].join("") + "_" + [
        pad(date.getHours()),
        pad(date.getMinutes()),
        pad(date.getSeconds())
      ].join("")
    }
  }
}
</script>

<style scoped>
.agent-page {
  padding: 16px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.agent-page.embedded {
  min-height: 0;
  max-height: 78vh;
  padding: 14px;
  overflow: auto;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
}

.header-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 8px;
}

.header-actions .el-button {
  margin-left: 0;
}

.search-input {
  width: 220px;
}

.type-select {
  width: 110px;
}

.pagination-bar {
  display: flex;
  justify-content: flex-end;
  padding-top: 14px;
}

.detail-image {
  min-height: 180px;
  margin-top: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  border: 1px solid #ebeef5;
}

.batch-detail {
  margin-top: 16px;
}

.batch-detail-title {
  margin-bottom: 8px;
  font-size: 14px;
  font-weight: 600;
  color: #303133;
}

.writeoff-flow {
  margin-top: 16px;
}

.writeoff-flow ::v-deep .el-steps {
  padding: 16px 12px 8px;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  background: #fafafa;
}

.writeoff-flow ::v-deep .el-step__description {
  line-height: 1.5;
}

.monthly-detail-table {
  margin-top: 16px;
}

.detail-image img {
  max-width: 100%;
  max-height: 360px;
  object-fit: contain;
}
</style>
