<template>
  <div class="catalog-page">
    <el-card shadow="never">
      <el-tabs v-model="activeTab" @tab-click="handleTabChange">
        <el-tab-pane label="领用编码名称库" name="item" />
        <el-tab-pane label="产品线名称库" name="productLine" />
        <el-tab-pane label="项目名称库" name="project" />
        <el-tab-pane label="图片名称库" name="projectImage" />
        <el-tab-pane label="地址名称库" name="projectAddress" />
      </el-tabs>
      <div slot="header" class="card-header">
        <span>{{ activeTitle }}</span>
        <div class="header-actions">
          <el-select
            v-if="activeTab === 'item'"
            v-model="itemSearchField"
            size="small"
            class="catalog-search-type"
            @change="handleSearch"
          >
            <el-option label="编码搜索" value="receive_code" />
            <el-option label="物品名称搜索" value="item_name" />
          </el-select>
          <el-input
            v-model="keyword"
            size="small"
            :placeholder="searchPlaceholder"
            clearable
            @keyup.enter.native="handleSearch"
          />
          <el-button size="small" @click="handleSearch">
            搜索
          </el-button>
          <el-button v-if="isAdmin" type="primary" size="small" @click="openDialog()">
            新增
          </el-button>
          <el-button v-if="isAdmin && activeTab !== 'projectImage'" size="small" icon="el-icon-document" @click="downloadTemplate">
            导入模板
          </el-button>
          <el-upload
            v-if="isAdmin && activeTab !== 'projectImage'"
            action="#"
            :auto-upload="false"
            :show-file-list="false"
            accept=".csv"
            :on-change="handleImportChange"
          >
            <el-button size="small" icon="el-icon-upload">
              导入
            </el-button>
          </el-upload>
          <el-button v-if="isAdmin && activeTab !== 'projectImage'" size="small" icon="el-icon-download" @click="exportCatalog">
            导出
          </el-button>
        </div>
      </div>

      <el-table v-if="activeTab === 'item'" v-loading="loading" :data="rows" border style="width:100%">
        <el-table-column prop="receive_code" label="领用编码" width="180" />
        <el-table-column prop="item_name" label="物品名称" min-width="220" show-overflow-tooltip />
        <el-table-column prop="remark" label="备注" min-width="220" show-overflow-tooltip />
        <el-table-column v-if="isAdmin" label="操作" width="170">
          <template slot-scope="scope">
            <el-button size="mini" @click="openDialog(scope.row)">
              编辑
            </el-button>
            <el-button size="mini" type="danger" @click="deleteRow(scope.row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-table v-else-if="activeTab === 'productLine'" v-loading="loading" :data="productLineRows" border style="width:100%">
        <el-table-column prop="line_name" label="产品线名称" min-width="220" show-overflow-tooltip />
        <el-table-column prop="remark" label="备注" min-width="220" show-overflow-tooltip />
        <el-table-column v-if="isAdmin" label="操作" width="170">
          <template slot-scope="scope">
            <el-button size="mini" @click="openDialog(scope.row)">
              编辑
            </el-button>
            <el-button size="mini" type="danger" @click="deleteRow(scope.row)">
              删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-table v-else-if="activeTab === 'project'" v-loading="loading" :data="projectRows" :cell-class-name="projectCellClassName" border style="width:100%">
        <el-table-column prop="parent_project_name" label="项目名称" min-width="170" show-overflow-tooltip />
        <el-table-column prop="sub_project_name" label="子项目名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="status" label="状态" width="110" />
        <el-table-column prop="lab_director" label="实验室主任" width="140" show-overflow-tooltip />
        <el-table-column prop="project_manager" label="项目经理" width="140" show-overflow-tooltip />
        <el-table-column prop="inventory_reviewer" label="复盘人" width="140" show-overflow-tooltip />
        <el-table-column prop="delivery_interface" label="交付接口人" width="140" show-overflow-tooltip />
        <el-table-column prop="remark" label="备注" min-width="220" show-overflow-tooltip />
        <el-table-column v-if="isAdmin" label="操作" width="170">
          <template slot-scope="scope">
            <el-button size="mini" @click="openDialog(scope.row)">编辑</el-button>
            <el-button size="mini" type="danger" @click="deleteRow(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-table v-else-if="activeTab === 'projectAddress'" v-loading="loading" :data="projectAddressRows" border style="width:100%">
        <el-table-column prop="project_name" label="项目名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="address" label="地址" min-width="260" show-overflow-tooltip />
        <el-table-column prop="remark" label="备注" min-width="220" show-overflow-tooltip />
        <el-table-column v-if="isAdmin" label="操作" width="170">
          <template slot-scope="scope">
            <el-button size="mini" @click="openDialog(scope.row)">编辑</el-button>
            <el-button size="mini" type="danger" @click="deleteRow(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div v-else v-loading="loading" class="image-catalog-wrapper">
        <table class="image-catalog-table">
          <thead>
            <tr>
              <th>样机名称</th>
              <th class="image-column">图片</th>
              <th>备注</th>
              <th v-if="isAdmin" class="operation-column">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="row in projectImageRows" :key="row.id">
              <td>{{ row.prototype_name }}</td>
              <td class="image-cell">
                <el-image
                  :src="imageUrl(row.image_path)"
                  :preview-src-list="[imageUrl(row.image_path)]"
                  class="catalog-thumbnail"
                  fit="contain"
                  title="点击查看完整图片"
                />
              </td>
              <td>{{ row.remark }}</td>
              <td v-if="isAdmin" class="operation-cell">
                <el-button size="mini" @click="openDialog(row)">编辑</el-button>
                <el-button size="mini" type="danger" @click="deleteRow(row)">删除</el-button>
              </td>
            </tr>
            <tr v-if="!projectImageRows.length">
              <td :colspan="isAdmin ? 4 : 3" class="empty-cell">暂无数据</td>
            </tr>
          </tbody>
        </table>
      </div>
    </el-card>

    <el-dialog :title="dialogTitle" :visible.sync="dialogVisible" width="420px">
      <el-form label-width="90px">
        <el-form-item v-if="activeTab === 'item'" label="领用编码">
          <el-input v-model="form.receiveCode" />
        </el-form-item>
        <el-form-item v-if="activeTab === 'item'" label="物品名称">
          <el-input v-model="form.itemName" />
        </el-form-item>
        <el-form-item v-else-if="activeTab === 'productLine'" label="产品线名称">
          <el-input v-model="form.lineName" />
        </el-form-item>
        <template v-else-if="activeTab === 'project'">
          <el-form-item label="项目名称">
            <el-input v-model.trim="form.parentProjectName" />
          </el-form-item>
          <el-form-item label="子项目名称">
            <el-input v-model.trim="form.subProjectName" />
          </el-form-item>
          <el-form-item label="状态">
            <el-select v-model="form.status" style="width:100%">
              <el-option label="进行中" value="进行中" />
              <el-option label="结项" value="结项" />
            </el-select>
          </el-form-item>
          <el-form-item label="实验室主任">
            <el-autocomplete
              v-model="form.labDirector"
              value-key="jobNumber"
              :fetch-suggestions="queryLabDirectorSuggestions"
              clearable
              style="width:100%"
              placeholder="请输入实验室主任工号或姓名"
              @select="handleLabDirectorSelect"
            >
              <template slot-scope="{ item }">
                {{ item.label }}
              </template>
            </el-autocomplete>
          </el-form-item>
          <el-form-item label="项目经理">
            <el-autocomplete
              v-model="form.projectManager"
              value-key="jobNumber"
              :fetch-suggestions="queryProjectManagerSuggestions"
              clearable
              style="width:100%"
              placeholder="请输入工程师工号或姓名"
              @select="handleProjectManagerSelect"
            >
              <template slot-scope="{ item }">
                {{ item.label }}
              </template>
            </el-autocomplete>
          </el-form-item>
          <el-form-item label="复盘人">
            <el-autocomplete
              v-model="form.inventoryReviewer"
              value-key="jobNumber"
              :fetch-suggestions="queryProjectReviewerSuggestions"
              clearable
              style="width:100%"
              placeholder="请输入复盘人工号或姓名"
              @select="handleProjectReviewerSelect"
            >
              <template slot-scope="{ item }">
                {{ item.label }}
              </template>
            </el-autocomplete>
          </el-form-item>
          <el-form-item label="交付接口人">
            <el-autocomplete
              v-model="form.deliveryInterface"
              value-key="jobNumber"
              :fetch-suggestions="queryDeliveryInterfaceSuggestions"
              clearable
              style="width:100%"
              placeholder="请输入交付接口人工号或姓名"
              @select="handleDeliveryInterfaceSelect"
            >
              <template slot-scope="{ item }">
                {{ item.label }}
              </template>
            </el-autocomplete>
          </el-form-item>
        </template>
        <template v-else-if="activeTab === 'projectAddress'">
          <el-form-item label="项目名称" required>
            <el-select v-model="form.projectName" filterable clearable placeholder="请选择项目" style="width:100%">
              <el-option
                v-for="item in projectRows"
                :key="item.project_name"
                :label="projectDisplayName(item)"
                :value="item.project_name"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="地址" required>
            <el-input v-model.trim="form.address" placeholder="请输入地址" />
          </el-form-item>
        </template>
        <template v-else>
          <el-form-item label="样机名称">
            <el-input v-model.trim="form.prototypeName" placeholder="请输入样机名称" />
          </el-form-item>
          <el-form-item label="图片" :required="!form.id">
            <el-upload action="#" :auto-upload="false" :file-list="imageFileList" accept=".png,.jpg,.jpeg,.gif,.webp,.bmp" :on-change="handleImageChange" :on-remove="handleImageRemove">
              <el-button size="small">选择图片</el-button>
            </el-upload>
          </el-form-item>
        </template>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="3" />
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveCatalog">保存</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
import axios from "axios"
import { API_BASE } from "../../config/appConfig"
import { isSameData } from "../../utils/dataChange"

export default {
  data() {
    return {
      loading: false,
      user: {},
      keyword: "",
      itemSearchField: "receive_code",
      rows: [],
      productLineRows: [],
      projectRows: [],
      projectImageRows: [],
      projectAddressRows: [],
      projectManagerOptions: [],
      labDirectorOptions: [],
      projectReviewerOptions: [],
      deliveryInterfaceOptions: [],
      activeTab: "item",
      dialogVisible: false,
      form: {
        id: "",
        receiveCode: "",
        itemName: "",
        lineName: "",
        parentProjectName: "",
        projectName: "",
        subProjectName: "",
        labDirector: "",
        prototypeName: "",
        address: "",
        status: "进行中",
        projectManager: "",
        inventoryReviewer: "",
        deliveryInterface: "",
        remark: ""
      },
      imageFileList: [],
      selectedImageFile: null,
      API_BASE,
      refreshTimer: null
    }
  },

  created() {
    const user = localStorage.getItem("user")
    if (user) {
      this.user = JSON.parse(user)
    }

    this.fetchData()
    this.fetchProjectManagers()
    this.fetchLabDirectors()
    this.fetchProjectReviewers()
    this.fetchDeliveryInterfaces()
    this.refreshTimer = setInterval(() => this.fetchData(true), 15000)
  },

  beforeDestroy() {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer)
    }
  },

  computed: {
    isAdmin() {
      return Number(this.user.permissions) === 1
    },
    activeTitle() {
      if (this.activeTab === "item") return "编码名称库"
      if (this.activeTab === "productLine") return "产品线名称库"
      if (this.activeTab === "projectImage") return "图片名称库"
      if (this.activeTab === "projectAddress") return "地址名称库"
      return "项目名称库"
    },
    dialogTitle() {
      if (this.activeTab === "item") return "编码名称"
      if (this.activeTab === "productLine") return "产品线名称"
      if (this.activeTab === "projectImage") return "样机图片"
      if (this.activeTab === "projectAddress") return "项目地址"
      return "项目"
    },
    searchPlaceholder() {
      if (this.activeTab === "item") return this.itemSearchField === "item_name" ? "请输入物品名称" : "请输入领用编码"
      if (this.activeTab === "productLine") return "搜索产品线名称"
      if (this.activeTab === "projectImage") return "搜索样机名称或备注"
      if (this.activeTab === "projectAddress") return "搜索项目名称、地址或备注"
      return "搜索项目名称/子项目名称/状态/实验室主任/项目经理/复盘人/交付接口人"
    }
  },

  methods: {
    handleSearch() {
      this.keyword = this.keyword.trim()
      this.fetchData()
    },

    handleTabChange() {
      this.keyword = ""
      this.dialogVisible = false
      this.imageFileList = []
      this.selectedImageFile = null
      this.fetchData()
    },

    fetchData(silent = false) {
      silent = silent === true
      if (this.activeTab === "item") {
        this.fetchCatalog(silent)
      } else if (this.activeTab === "productLine") {
        this.fetchProductLines(silent)
      } else if (this.activeTab === "project") {
        this.fetchProjects(false, silent)
      } else if (this.activeTab === "projectAddress") {
        this.fetchProjectAddresses(silent)
      } else {
        this.fetchProjectImages(silent)
      }
    },

    fetchCatalog(silent = false) {
      silent = silent === true
      if (!silent) {
        this.loading = true
      }
      axios.get(`${API_BASE}/catalog/list`, {
        params: {
          keyword: this.keyword.trim(),
          searchField: this.itemSearchField
        }
      }).then(res => {
        if (res.data.code === 200) {
          const nextRows = res.data.data || []
          if (!isSameData(this.rows, nextRows)) {
            this.rows = nextRows
          }
        } else if (!silent) {
          this.$message.error(res.data.msg || "获取失败")
        }
      }).catch(() => {
        if (!silent) {
          this.$message.error("网络请求失败，请检查后端是否启动")
        }
      }).finally(() => {
        if (!silent) {
          this.loading = false
        }
      })
    },

    fetchProductLines(silent = false) {
      silent = silent === true
      if (!silent) {
        this.loading = true
      }
      axios.get(`${API_BASE}/product_line/list`, {
        params: {
          keyword: this.keyword.trim()
        }
      }).then(res => {
        if (res.data.code === 200) {
          const nextRows = res.data.data || []
          if (!isSameData(this.productLineRows, nextRows)) {
            this.productLineRows = nextRows
          }
        } else if (!silent) {
          this.$message.error(res.data.msg || "获取失败")
        }
      }).catch(() => {
        if (!silent) {
          this.$message.error("网络请求失败，请检查后端是否启动")
        }
      }).finally(() => {
        if (!silent) {
          this.loading = false
        }
      })
    },

    fetchProjects(ignoreKeyword = false, silent = false) {
      silent = silent === true
      if (!silent) {
        this.loading = true
      }
      axios.get(`${API_BASE}/project/list`, {
        params: { keyword: ignoreKeyword ? "" : this.keyword.trim() }
      }).then(res => {
        if (res.data.code === 200) {
          const nextRows = (res.data.data || []).map(item => ({
            ...item,
            parent_project_name: item.parent_project_name || item.project_name || "",
            sub_project_name: item.sub_project_name || item.project_name || "",
            status: item.status || "进行中"
          }))
          if (!isSameData(this.projectRows, nextRows)) {
            this.projectRows = nextRows
          }
        } else if (!silent) {
          this.$message.error(res.data.msg || "获取失败")
        }
      }).catch(() => {
        if (!silent) {
          this.$message.error("网络请求失败，请检查后端是否启动")
        }
      }).finally(() => {
        if (!silent) {
          this.loading = false
        }
      })
    },

    fetchProjectImages(silent = false) {
      silent = silent === true
      if (!silent) {
        this.loading = true
      }
      axios.get(`${API_BASE}/project_image/list`, {
        params: { keyword: this.keyword.trim() }
      }).then(res => {
        if (res.data.code === 200) {
          const nextRows = res.data.data || []
          if (!isSameData(this.projectImageRows, nextRows)) {
            this.projectImageRows = nextRows
          }
        }
      }).finally(() => {
        if (!silent) {
          this.loading = false
        }
      })
    },

    fetchProjectAddresses(silent = false) {
      silent = silent === true
      if (!silent) {
        this.loading = true
      }
      axios.get(`${API_BASE}/project_address/list`, {
        params: { keyword: this.keyword.trim() }
      }).then(res => {
        if (res.data.code === 200) {
          const nextRows = res.data.data || []
          if (!isSameData(this.projectAddressRows, nextRows)) {
            this.projectAddressRows = nextRows
          }
        } else if (!silent) {
          this.$message.error(res.data.msg || "获取失败")
        }
      }).catch(() => {
        if (!silent) {
          this.$message.error("网络请求失败，请检查后端是否启动")
        }
      }).finally(() => {
        if (!silent) {
          this.loading = false
        }
      })
    },

    fetchProjectManagers() {
      axios.get(`${API_BASE}/user/engineers`).then(res => {
        if (res.data.code === 200) {
          this.projectManagerOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    fetchLabDirectors() {
      axios.get(`${API_BASE}/user/responsibles`).then(res => {
        if (res.data.code === 200) {
          this.labDirectorOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    fetchProjectReviewers() {
      axios.get(`${API_BASE}/user/responsibles`).then(res => {
        if (res.data.code === 200) {
          this.projectReviewerOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    fetchDeliveryInterfaces() {
      axios.get(`${API_BASE}/user/responsibles`).then(res => {
        if (res.data.code === 200) {
          this.deliveryInterfaceOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    queryProjectManagerSuggestions(queryString, callback) {
      const keyword = String(queryString || "").trim().toLowerCase()
      const rows = keyword
        ? this.projectManagerOptions.filter(item =>
          [item.jobNumber, item.name, item.label].some(value =>
            String(value || "").toLowerCase().includes(keyword)
          )
        )
        : this.projectManagerOptions
      callback(rows)
    },

    queryLabDirectorSuggestions(queryString, callback) {
      const keyword = String(queryString || "").trim().toLowerCase()
      const rows = keyword
        ? this.labDirectorOptions.filter(item =>
          [item.jobNumber, item.name, item.label].some(value =>
            String(value || "").toLowerCase().includes(keyword)
          )
        )
        : this.labDirectorOptions
      callback(rows)
    },

    handleLabDirectorSelect(item) {
      this.form.labDirector = item.jobNumber
    },

    handleProjectManagerSelect(item) {
      this.form.projectManager = item.jobNumber
    },

    queryProjectReviewerSuggestions(queryString, callback) {
      const keyword = String(queryString || "").trim().toLowerCase()
      const rows = keyword
        ? this.projectReviewerOptions.filter(item =>
          [item.jobNumber, item.name, item.label].some(value =>
            String(value || "").toLowerCase().includes(keyword)
          )
        )
        : this.projectReviewerOptions
      callback(rows)
    },

    handleProjectReviewerSelect(item) {
      this.form.inventoryReviewer = item.jobNumber
    },

    queryDeliveryInterfaceSuggestions(queryString, callback) {
      const keyword = String(queryString || "").trim().toLowerCase()
      const rows = keyword
        ? this.deliveryInterfaceOptions.filter(item =>
          [item.jobNumber, item.username, item.name, item.label].some(value =>
            String(value || "").toLowerCase().includes(keyword)
          )
        )
        : this.deliveryInterfaceOptions
      callback(rows)
    },

    handleDeliveryInterfaceSelect(item) {
      this.form.deliveryInterface = item.jobNumber
    },

    projectDisplayName(row) {
      if (!row) {
        return ""
      }
      const parentName = row.parent_project_name || ""
      const subName = row.sub_project_name || row.project_name || ""
      return parentName && parentName !== subName ? `${parentName} / ${subName}` : subName
    },

    projectCellClassName({ row, column }) {
      if (column.property !== "status") {
        return ""
      }
      return row.status === "结项" ? "project-status-cell is-closed" : "project-status-cell is-active"
    },

    openDialog(row) {
      if (this.activeTab === "project" || this.activeTab === "projectAddress") {
        this.fetchProjectManagers()
        this.fetchLabDirectors()
        this.fetchProjectReviewers()
        this.fetchProjects(true, true)
      }
      this.imageFileList = []
      this.selectedImageFile = null

      if (this.activeTab === "productLine") {
        this.form = row ? {
          id: row.id,
          receiveCode: "",
          itemName: "",
          lineName: row.line_name,
          remark: row.remark || ""
        } : {
          id: "",
          receiveCode: "",
          itemName: "",
          lineName: "",
          remark: ""
        }
      } else if (this.activeTab === "item") {
        this.form = row ? {
          id: row.id,
          receiveCode: row.receive_code,
          itemName: row.item_name,
          lineName: "",
          remark: row.remark || ""
        } : {
          id: "",
          receiveCode: "",
          itemName: "",
          lineName: "",
          remark: ""
        }
      } else if (this.activeTab === "project") {
        this.form = row ? {
          id: row.id,
          receiveCode: "",
          itemName: "",
          lineName: "",
          parentProjectName: row.parent_project_name || row.project_name || "",
          projectName: row.project_name,
          subProjectName: row.sub_project_name || row.project_name,
          status: row.status || "进行中",
          labDirector: row.lab_director || "",
          projectManager: row.project_manager || "",
          inventoryReviewer: row.inventory_reviewer || "",
          deliveryInterface: row.delivery_interface || "",
          remark: row.remark || ""
        } : {
          id: "",
          receiveCode: "",
          itemName: "",
          lineName: "",
          parentProjectName: "",
          projectName: "",
          subProjectName: "",
          status: "进行中",
          labDirector: "",
          projectManager: "",
          inventoryReviewer: "",
          deliveryInterface: "",
          remark: ""
        }
      } else if (this.activeTab === "projectAddress") {
        this.form = row ? {
          id: row.id,
          projectName: row.project_name,
          address: row.address,
          remark: row.remark || ""
        } : {
          id: "",
          projectName: "",
          address: "",
          remark: ""
        }
      } else {
        this.form = row ? {
          id: row.id,
          prototypeName: row.prototype_name,
          remark: row.remark || ""
        } : {
          id: "",
          prototypeName: "",
          remark: ""
        }
      }
      this.dialogVisible = true
    },

    saveCatalog() {
      if (this.activeTab === "productLine") {
        this.saveProductLine()
        return
      }

      if (this.activeTab === "project") {
        this.saveProject()
        return
      }
      if (this.activeTab === "projectImage") {
        this.saveProjectImage()
        return
      }
      if (this.activeTab === "projectAddress") {
        this.saveProjectAddress()
        return
      }

      if (!this.form.receiveCode || !this.form.itemName) {
        this.$message.error("领用编码和物品名称不能为空")
        return
      }

      const existed = this.rows.find(item =>
        item.receive_code === this.form.receiveCode &&
        String(item.id) !== String(this.form.id || "")
      )

      if (existed) {
        this.$message.error(`领用编码已绑定物品名称：${existed.item_name}，不能重复填入`)
        return
      }

      const nameExisted = this.rows.find(item =>
        item.item_name === this.form.itemName &&
        String(item.id) !== String(this.form.id || "")
      )

      if (nameExisted) {
        this.$message.error(`物品名称已绑定领用编码：${nameExisted.receive_code}，不能重复填入`)
        return
      }

      axios.post(`${API_BASE}/catalog/save`, this.form).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.dialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "保存失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    saveProductLine() {
      if (!this.form.lineName) {
        this.$message.error("产品线名称不能为空")
        return
      }

      const existed = this.productLineRows.find(item =>
        item.line_name === this.form.lineName &&
        String(item.id) !== String(this.form.id || "")
      )

      if (existed) {
        this.$message.error("产品线名称已存在，不能重复")
        return
      }

      axios.post(`${API_BASE}/product_line/save`, {
        id: this.form.id,
        lineName: this.form.lineName,
        remark: this.form.remark
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.dialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "保存失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    saveProject() {
      if (!this.form.parentProjectName) {
        this.$message.error("项目名称不能为空")
        return
      }
      if (!this.form.subProjectName) {
        this.$message.error("子项目名称不能为空")
        return
      }

      axios.post(`${API_BASE}/project/save`, {
        id: this.form.id,
        parentProjectName: this.form.parentProjectName,
        subProjectName: this.form.subProjectName,
        projectName: this.form.subProjectName,
        status: this.form.status,
        labDirector: this.form.labDirector,
        projectManager: this.form.projectManager,
        inventoryReviewer: this.form.inventoryReviewer,
        deliveryInterface: this.form.deliveryInterface,
        remark: this.form.remark
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.dialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "保存失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    saveProjectImage() {
      if (!this.form.prototypeName || (!this.form.id && !this.selectedImageFile)) {
        this.$message.error("样机名称和图片不能为空")
        return
      }
      const formData = new FormData()
      formData.append("id", this.form.id || "")
      formData.append("prototypeName", this.form.prototypeName)
      formData.append("remark", this.form.remark || "")
      if (this.selectedImageFile) formData.append("image", this.selectedImageFile)
      axios.post(`${API_BASE}/project_image/save`, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.dialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "保存失败")
        }
      })
    },

    saveProjectAddress() {
      if (!this.form.projectName || !this.form.address) {
        this.$message.error("项目名称和地址不能为空")
        return
      }
      axios.post(`${API_BASE}/project_address/save`, {
        id: this.form.id,
        projectName: this.form.projectName,
        address: this.form.address,
        remark: this.form.remark
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.dialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "保存失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    deleteRow(row) {
      const label = this.activeTab === "item"
        ? row.receive_code
        : (this.activeTab === "productLine"
          ? row.line_name
          : (this.activeTab === "projectImage"
            ? row.prototype_name
            : (this.activeTab === "projectAddress" ? row.address : this.projectDisplayName(row))))
      this.$confirm(`确认删除 ${label}？`, "提示", {
        type: "warning"
      }).then(() => {
        const url = this.activeTab === "item"
          ? `${API_BASE}/catalog/delete/${row.id}`
          : (this.activeTab === "productLine"
            ? `${API_BASE}/product_line/delete/${row.id}`
            : (this.activeTab === "projectImage"
              ? `${API_BASE}/project_image/delete/${row.id}`
              : (this.activeTab === "projectAddress" ? `${API_BASE}/project_address/delete/${row.id}` : `${API_BASE}/project/delete/${row.id}`)))
        axios.delete(url).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchData()
          } else {
            this.$message.error(res.data.msg || "删除失败")
          }
        }).catch(() => {
          this.$message.error("网络请求失败，请检查后端是否启动")
        })
      }).catch(() => {})
    },

    handleImportChange(file) {
      const formData = new FormData()
      formData.append("file", file.raw)
      const url = this.activeTab === "item"
        ? `${API_BASE}/catalog/import`
        : (this.activeTab === "productLine"
          ? `${API_BASE}/product_line/import`
          : (this.activeTab === "projectAddress" ? `${API_BASE}/project_address/import` : `${API_BASE}/project/import`))

      axios.post(url, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "导入失败")
        }
      }).catch(() => {
        this.$message.error("导入失败，请检查文件格式")
      })
    },

    downloadTemplate() {
      const url = this.activeTab === "item"
        ? `${API_BASE}/catalog/template`
        : (this.activeTab === "productLine"
          ? `${API_BASE}/product_line/template`
          : (this.activeTab === "projectAddress" ? `${API_BASE}/project_address/template` : `${API_BASE}/project/template`))
      const filename = this.activeTab === "item"
        ? "领用编码名称库导入模板"
        : (this.activeTab === "productLine"
          ? "产品线名称库导入模板"
          : (this.activeTab === "projectAddress" ? "地址名称库导入模板" : "项目名称库导入模板"))
      this.downloadFile(url, `${filename}_${this.formatExportTime()}.csv`)
    },

    exportCatalog() {
      const url = this.activeTab === "item"
        ? `${API_BASE}/catalog/export`
        : (this.activeTab === "productLine"
          ? `${API_BASE}/product_line/export`
          : (this.activeTab === "projectAddress" ? `${API_BASE}/project_address/export` : `${API_BASE}/project/export`))
      const filename = this.activeTab === "item"
        ? "领用编码名称库"
        : (this.activeTab === "productLine"
          ? "产品线名称库"
          : (this.activeTab === "projectAddress" ? "地址名称库" : "项目名称库"))
      this.downloadFile(url, `${filename}_${this.formatExportTime()}.csv`)
    },

    downloadFile(url, filename) {
      axios.get(url, {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = filename
        link.click()
        URL.revokeObjectURL(link.href)
      }).catch(() => {
        this.$message.error("下载失败，请检查后端是否启动")
      })
    },

    handleImageChange(file, fileList) {
      if (!this.validateImageFile(file)) {
        this.imageFileList = []
        this.selectedImageFile = null
        return
      }
      this.imageFileList = fileList.slice(-1)
      this.selectedImageFile = file.raw
    },

    handleImageRemove() {
      this.imageFileList = []
      this.selectedImageFile = null
    },

    validateImageFile(file) {
      const name = (file && file.name) || (file && file.raw && file.raw.name) || ""
      const ext = name.includes(".") ? name.split(".").pop().toLowerCase() : ""
      const allowed = ["png", "jpg", "jpeg", "gif", "webp", "bmp"]
      if (!allowed.includes(ext)) {
        this.$message.error("图片格式仅支持 png、jpg、jpeg、gif、webp、bmp")
        return false
      }
      return true
    },

    imageUrl(path) {
      if (!path) return ""
      if (/^https?:\/\//.test(path)) return path
      return `${API_BASE}${path}`
    },

    formatExportTime() {
      const date = new Date()
      const pad = value => String(value).padStart(2, "0")

      return [
        date.getFullYear(),
        pad(date.getMonth() + 1),
        pad(date.getDate())
      ].join("") + "_" + [
        pad(date.getHours()),
        pad(date.getMinutes()),
        pad(date.getSeconds())
      ].join("")
    }
  }
}
</script>

<style scoped>
.catalog-page {
  padding: 16px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.card-header,
.header-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}

.header-actions .el-input {
  width: 220px;
}

.catalog-search-type {
  width: 130px;
}

::v-deep .project-status-cell .cell {
  display: inline-block;
  width: auto;
  padding: 4px 10px;
  line-height: 1.2;
  border: 1px solid;
  border-radius: 4px;
}

::v-deep .project-status-cell.is-active .cell {
  color: #67c23a;
  background-color: #f0f9eb;
  border-color: #c2e7b0;
}

::v-deep .project-status-cell.is-closed .cell {
  color: #909399;
  background-color: #f4f4f5;
  border-color: #d3d4d6;
}

.image-catalog-wrapper {
  width: 100%;
  overflow-x: auto;
}

.image-catalog-table {
  width: 100%;
  min-width: 760px;
  border-spacing: 0;
  border-collapse: collapse;
  table-layout: fixed;
  color: #606266;
  font-size: 14px;
}

.image-catalog-table th,
.image-catalog-table td {
  padding: 10px 12px;
  text-align: left;
  border: 1px solid #ebeef5;
}

.image-catalog-table th {
  color: #909399;
  font-weight: 600;
  background: #fafafa;
}

.image-column {
  width: 180px;
}

.operation-column {
  width: 170px;
}

.image-cell {
  height: 108px;
}

.catalog-thumbnail {
  display: block;
  width: 140px;
  height: 86px;
  border: 1px solid #ebeef5;
  object-fit: contain;
  cursor: zoom-in;
  background: #f5f7fa;
}

.operation-cell {
  white-space: nowrap;
}

.operation-cell .el-button {
  margin-left: 0;
  margin-right: 6px;
}

.empty-cell {
  height: 80px;
  text-align: center !important;
  color: #909399;
}

</style>
