<template>
  <div class="prototype-page">
    <el-card class="search-card" shadow="never">
      <el-form :model="searchForm" class="search-form" size="small" label-width="86px">
        <el-form-item label="录入日期">
          <el-date-picker
            v-model="searchForm.date"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyy-MM-dd"
          />
        </el-form-item>
        <el-form-item label="样机名称">
          <el-input v-model="searchForm.itemName" placeholder="样机名称" clearable />
        </el-form-item>
        <el-form-item label="存放位置">
          <el-input v-model="searchForm.storageLocation" placeholder="存放位置" clearable />
        </el-form-item>
        <el-form-item label="录入人">
          <el-input v-model="searchForm.entryPerson" placeholder="录入人" clearable />
        </el-form-item>
        <el-form-item label="项目">
          <el-select v-model="searchForm.projectName" filterable clearable placeholder="请选择项目">
            <el-option v-for="item in projectOptions" :key="item.project_name" :label="item.project_name" :value="item.project_name" />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="searchForm.status" clearable placeholder="请选择状态">
            <el-option label="生产中" value="生产中" />
            <el-option label="已完成" value="已完成" />
            <el-option label="已交付" value="已交付" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSearch">搜索</el-button>
          <el-button @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card shadow="never">
      <div class="toolbar">
        <div class="toolbar-title">{{ isManageView ? "样机管理" : "样机台账" }}</div>
        <div>
          <el-button v-if="canMaintainPrototype" type="primary" size="small" @click="openDialog()">新增</el-button>
          <el-button v-if="canMaintainPrototype" type="danger" size="small" @click="openScrapDialog">报废</el-button>
          <el-button v-if="canMaintainPrototype" type="warning" size="small" @click="openWriteoffDialog">销账</el-button>
          <el-button v-if="isAdmin" size="small" icon="el-icon-document" @click="downloadImportTemplate">导入模板</el-button>
          <el-upload
            v-if="isAdmin"
            action="#"
            :auto-upload="false"
            :show-file-list="false"
            accept=".csv"
            :on-change="handleImportChange"
            style="display:inline-block;margin-right:10px"
          >
            <el-button size="small" icon="el-icon-upload">导入</el-button>
          </el-upload>
          <el-button v-if="isAdmin" type="danger" size="small" @click="deleteSelected">删除选中</el-button>
          <el-button size="small" @click="exportData">导出</el-button>
          <el-button v-if="isAdmin" size="small" @click="openBatchDialog">批量修改</el-button>
        </div>
      </div>

      <div class="prototype-total-bar">
        <div v-for="item in prototypeTotalItems" :key="item.label" class="prototype-total-item">
          <span>{{ item.label }}</span>
          <strong>{{ item.value }}</strong>
        </div>
      </div>

      <el-table v-loading="loading" :data="rows" border height="560" style="width:100%" @selection-change="handleSelectionChange">
        <el-table-column type="selection" :selectable="isRowSelectable" fixed width="48" />
        <el-table-column prop="entry_date" label="录入时间" width="120" />
        <el-table-column label="样机名称" min-width="160" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-button v-if="scope.row.row_type === 'container'" type="text" @click="openContainerDialog(scope.row)">
              {{ scope.row.item_name }}
            </el-button>
            <span v-else>{{ scope.row.item_name }}</span>
          </template>
        </el-table-column>
        <el-table-column prop="prototype_total_count" label="样机总数" width="105" :formatter="integerFormatter" />
        <el-table-column prop="producing_count" label="待生产数量" width="120" :formatter="integerFormatter" />
        <el-table-column prop="completed_count" label="已完成数量" width="120" :formatter="integerFormatter" />
        <el-table-column prop="delivered_count" label="交付数量" width="105" :formatter="integerFormatter" />
        <el-table-column label="状态" width="100">
          <template slot-scope="scope">
            <el-tag :type="prototypeStatusType(scope.row.status)" size="small">
              {{ scope.row.status || "生产中" }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="storage_location" label="存放位置" min-width="150" show-overflow-tooltip />
        <el-table-column prop="prototype_owner" label="样机归属人" width="180" :formatter="prototypeOwnerFormatter" show-overflow-tooltip />
        <el-table-column prop="project_name" label="项目" min-width="150" show-overflow-tooltip />
        <el-table-column prop="remark" label="备注" min-width="160" show-overflow-tooltip />
        <el-table-column label="操作" fixed="right" width="280">
          <template slot-scope="scope">
            <div class="operation-buttons">
              <el-button size="mini" @click="viewImage(scope.row)">图片</el-button>
              <el-button v-if="scope.row.row_type === 'container'" size="mini" type="primary" @click="openContainerDialog(scope.row)">详情</el-button>
              <el-button v-if="canOutPrototype(scope.row)" size="mini" type="warning" @click="openOutDialog(scope.row)">出账</el-button>
              <el-button v-if="scope.row.row_type === 'container' && isAdmin && scope.row.can_delete" size="mini" type="danger" @click="deleteContainer(scope.row)">删除</el-button>
              <el-button v-if="scope.row.row_type !== 'container' && canEditPrototype" size="mini" @click="openDialog(scope.row)">编辑</el-button>
              <el-button v-if="scope.row.row_type !== 'container' && canUpdatePrototypeStatus(scope.row)" size="mini" type="success" @click="completePrototype(scope.row)">更新状态</el-button>
              <el-button v-if="scope.row.row_type !== 'container'" size="mini" @click="openRecordDialog(scope.row)">记录</el-button>
              <el-button v-if="scope.row.row_type !== 'container'" size="mini" @click="exportSameItem(scope.row)">导出</el-button>
              <el-button v-if="scope.row.row_type !== 'container' && isAdmin" size="mini" type="danger" @click="deleteRow(scope.row)">删除</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-bar">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next"
          :current-page="pagination.page"
          :page-size="pagination.pageSize"
          :page-sizes="[10, 20, 50]"
          :total="pagination.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <el-dialog title="样机信息" :visible.sync="dialogVisible" width="720px" @close="resetForm">
      <el-form ref="prototypeForm" :model="form" :rules="formRules" label-width="120px">
        <el-row :gutter="16">
          <el-col v-if="showPrototypeBaseFields" :span="12">
            <el-form-item label="项目" prop="project_name">
              <el-select v-model="form.project_name" filterable clearable placeholder="请选择项目" style="width:100%" @change="handleProjectChange">
                <el-option v-for="item in activeProjectOptions" :key="item.project_name" :label="item.project_name" :value="item.project_name" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col v-if="showPrototypeBaseFields" :span="12">
            <el-form-item label="样机名称" prop="item_name">
              <el-autocomplete
                v-model.trim="form.item_name"
                :fetch-suggestions="queryPrototypeNameSuggestions"
                :disabled="isTechnicianEdit || !form.project_name"
                placeholder="请先选择项目"
                style="width:100%"
                @select="handlePrototypeNameSelect"
                @blur="handlePrototypeNameBlur"
              />
            </el-form-item>
          </el-col>
          <el-col v-if="showPrototypeBaseFields" :span="12"><el-form-item label="数量" prop="quantity"><el-input-number v-model="form.quantity" :min="1" :precision="0" :step="1" :disabled="isTechnicianEdit || Boolean(form.container_code)" style="width:100%" /></el-form-item></el-col>
          <el-col v-if="showPrototypeBaseFields" :span="12">
            <el-form-item label="样机归属人" prop="prototype_owner">
              <el-select v-model="form.prototype_owner" multiple filterable clearable placeholder="请选择用户" style="width:100%">
                <el-option v-for="item in userOptions" :key="item.username" :label="item.label" :value="item.label" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col v-if="form.id" :span="12">
            <el-form-item label="存放位置">
              <el-select
                v-model="form.storage_location"
                filterable
                allow-create
                clearable
                default-first-option
                placeholder="请选择或输入存放位置"
                style="width:100%"
              >
                <el-option
                  v-for="item in projectAddressOptions"
                  :key="item.id || item.address"
                  :label="item.address"
                  :value="item.address"
                />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="24"><el-form-item label="备注"><el-input v-model="form.remark" type="textarea" :rows="3" /></el-form-item></el-col>
        </el-row>
      </el-form>
      <span slot="footer">
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveData">{{ form.id ? "保存" : "提交" }}</el-button>
      </span>
    </el-dialog>

    <el-dialog title="完成样机" :visible.sync="completionDialogVisible" width="480px" @close="resetCompletionForm">
      <el-form label-width="90px">
        <el-form-item label="存放位置" required>
          <el-select
            v-model="completionStorageLocation"
            filterable
            allow-create
            clearable
            default-first-option
            placeholder="请选择或输入存放位置"
            style="width:100%"
          >
            <el-option
              v-for="item in completionAddressOptions"
              :key="item.id || item.address"
              :label="item.address"
              :value="item.address"
            />
          </el-select>
        </el-form-item>
        <el-form-item v-if="!completionHasExistingImage" label="样机图片" required>
          <el-upload
            action="#"
            :auto-upload="false"
            :file-list="completionFileList"
            accept=".png,.jpg,.jpeg,.gif,.webp,.bmp"
            :on-change="handleCompletionImageChange"
            :on-remove="resetCompletionImage"
          >
            <el-button size="small">选择图片</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="completionDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitCompletionWithImage">确认完成</el-button>
      </span>
    </el-dialog>

    <el-dialog title="样机出账" :visible.sync="outDialogVisible" width="860px" custom-class="prototype-out-dialog" @close="resetOutForm">
      <el-form class="prototype-out-form" label-width="100px">
        <el-row :gutter="18">
          <el-col :span="12">
            <el-form-item label="样机名称">
              <el-input v-model="outForm.item_name" disabled />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="当前数量">
              <el-input-number v-model="outForm.quantity" :precision="0" :step="1" disabled style="width:100%" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="出账数量" required>
              <el-input-number v-model="outForm.out_number" :min="0" :precision="0" :step="1" disabled style="width:100%" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="用途" required>
              <el-select v-model="outForm.use" clearable placeholder="请选择用途" style="width:100%">
                <el-option v-for="item in useOptions" :key="item" :label="item" :value="item" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="领用人" required>
              <el-input v-model.trim="outForm.recipient" />
            </el-form-item>
          </el-col>
          <el-col v-if="outForm.use !== '样机报废'" :span="12">
            <el-form-item label="交付产品线" required>
              <el-select v-model="outForm.delivery_product_line" clearable placeholder="请选择交付产品线" style="width:100%">
                <el-option v-for="item in productLineOptions" :key="item" :label="item" :value="item" />
              </el-select>
            </el-form-item>
          </el-col>
          <el-col v-if="outForm.use !== '样机报废'" :span="12">
            <el-form-item label="研发工程师" required>
              <el-input v-model.trim="outForm.delivery_rd_engineer" />
            </el-form-item>
          </el-col>
          <el-col v-if="outForm.use !== '样机报废'" :span="12">
            <el-form-item label="携物出门单号" required>
              <el-input v-model.trim="outForm.carry_out_number" />
            </el-form-item>
          </el-col>
          <el-col v-if="outForm.row_type === 'container'" :span="24">
            <el-form-item label="选择样机" required>
              <div class="out-selection-summary">
                <span>请选择本次出账的具体样机</span>
                <strong>已选择 {{ selectedOutPrototypes.length }} 台</strong>
              </div>
              <el-table
                :data="outAvailablePrototypes"
                border
                height="180"
                row-key="id"
                style="width:100%"
                @selection-change="handleOutPrototypeSelection"
              >
                <el-table-column type="selection" width="48" />
                <el-table-column prop="item_name" label="样机名称" min-width="220" />
              </el-table>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="图片">
              <el-upload action="#" :auto-upload="false" :file-list="outFileList" accept=".png,.jpg,.jpeg,.gif,.webp,.bmp" :on-change="handleOutImageChange" :on-remove="handleOutImageRemove">
                <el-button size="small">选择图片</el-button>
              </el-upload>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="备注">
              <el-input v-model="outForm.remark" type="textarea" :rows="2" />
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <span slot="footer">
        <el-button @click="outDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitOut">提交</el-button>
      </span>
    </el-dialog>

    <el-dialog title="样机图片" :visible.sync="imageDialogVisible" width="620px">
      <div class="image-box">
        <img v-if="currentImageUrl" :src="currentImageUrl" class="prototype-image" alt="样机图片">
        <el-empty v-else description="当前样机暂无图片" />
      </div>
    </el-dialog>

    <el-dialog title="样机报废" :visible.sync="scrapDialogVisible" width="900px" @close="resetDisposalDialog">
      <el-upload
        drag
        action="#"
        :auto-upload="false"
        :limit="1"
        accept="image/*"
        :file-list="scrapProofFileList"
        :on-change="handleScrapProofChange"
        :on-exceed="handleScrapProofExceed"
        :on-remove="handleScrapProofRemove"
        class="proof-upload"
      >
        <i class="el-icon-upload" />
        <div class="el-upload__text">将评审证明拖到此处，或<em>点击上传</em></div>
      </el-upload>
      <el-table
        ref="prototypeScrapTable"
        v-loading="disposalLoading"
        :data="disposalRows"
        border
        height="320"
        style="width:100%; margin-top:16px"
        @selection-change="handleDisposalSelectionChange"
      >
        <el-table-column type="selection" width="48" />
        <el-table-column prop="projectName" label="当前项目" min-width="140" show-overflow-tooltip />
        <el-table-column prop="identityCode" label="样机编码" width="140" show-overflow-tooltip />
        <el-table-column prop="itemName" label="样机名称" min-width="160" show-overflow-tooltip />
        <el-table-column prop="totalQuantity" label="总数量" width="110" :formatter="integerFormatter" />
        <el-table-column prop="availableQuantity" label="可报废数量" width="120" :formatter="integerFormatter" />
      </el-table>
      <span slot="footer">
        <el-button @click="scrapDialogVisible = false">关闭</el-button>
        <el-button type="primary" :loading="disposalLoading" @click="submitScrap">提交</el-button>
      </span>
    </el-dialog>

    <el-dialog title="样机销账" :visible.sync="writeoffDialogVisible" width="900px" @close="resetDisposalDialog">
      <el-steps :active="0" simple class="writeoff-steps">
        <el-step title="工程师" />
        <el-step title="子项目经理" />
        <el-step title="实验室主任" />
      </el-steps>
      <el-table
        ref="prototypeWriteoffTable"
        v-loading="disposalLoading"
        :data="disposalRows"
        border
        height="320"
        style="width:100%; margin-top:16px"
        @selection-change="handleDisposalSelectionChange"
      >
        <el-table-column type="selection" width="48" />
        <el-table-column prop="projectName" label="当前项目" min-width="140" show-overflow-tooltip />
        <el-table-column prop="identityCode" label="样机编码" width="140" show-overflow-tooltip />
        <el-table-column prop="itemName" label="样机名称" min-width="160" show-overflow-tooltip />
        <el-table-column prop="totalQuantity" label="总数量" width="110" :formatter="integerFormatter" />
        <el-table-column prop="availableQuantity" label="可销账数量" width="120" :formatter="integerFormatter" />
      </el-table>
      <span slot="footer">
        <el-button @click="writeoffDialogVisible = false">关闭</el-button>
        <el-button type="primary" :loading="disposalLoading" @click="submitWriteoff">提交</el-button>
      </span>
    </el-dialog>

    <el-dialog :title="`${containerTitle} - 容器内样机`" :visible.sync="containerDialogVisible" width="980px">
      <div class="container-toolbar">
        <div class="container-search">
          <el-select
            v-model="containerSearchStatus"
            size="small"
            clearable
            placeholder="按状态搜索"
            @change="handleContainerStatusChange"
          >
            <el-option label="生产中" value="生产中" />
            <el-option label="已完成" value="已完成" />
            <el-option label="已交付" value="已交付" />
          </el-select>
          <span>已选择 {{ selectedContainerChildren.length }} 台</span>
        </div>
        <div>
          <el-button
            v-if="canMaintainPrototype"
            size="small"
            type="success"
            :disabled="!selectedContainerChildren.length"
            @click="batchCompleteContainerChildren"
          >批量更新状态</el-button>
          <el-button size="small" :disabled="!selectedContainerChildren.length" @click="exportContainerChildren">批量导出</el-button>
        </div>
      </div>
      <el-table
        v-loading="containerLoading"
        :data="containerChildren"
        border
        height="420"
        style="width:100%"
        @selection-change="handleContainerSelectionChange"
      >
        <el-table-column type="selection" width="48" />
        <el-table-column prop="item_name" label="样机名称" min-width="180" />
        <el-table-column prop="quantity" label="数量" width="80" :formatter="integerFormatter" />
        <el-table-column label="状态" width="100">
          <template slot-scope="scope">
            <el-tag :type="prototypeStatusType(scope.row.status)" size="small">{{ scope.row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="storage_location" label="存放位置" min-width="150" />
        <el-table-column prop="prototype_owner" label="样机归属人" width="180" :formatter="prototypeOwnerFormatter" show-overflow-tooltip />
        <el-table-column prop="project_name" label="项目" min-width="150" />
        <el-table-column prop="recipient" label="领用人" width="110" />
        <el-table-column prop="delivery_product_line" label="交付产品线" min-width="150" show-overflow-tooltip />
        <el-table-column prop="delivery_rd_engineer" label="交付研发工程师" min-width="150" show-overflow-tooltip />
        <el-table-column prop="carry_out_number" label="携物出门单号" min-width="150" show-overflow-tooltip />
        <el-table-column prop="entry_person" label="录入人" width="120" />
        <el-table-column prop="remark" label="备注" min-width="160" show-overflow-tooltip />
        <el-table-column label="操作" fixed="right" width="176">
          <template slot-scope="scope">
            <div class="operation-buttons container-operation-buttons">
              <el-button v-if="canUpdatePrototypeStatus(scope.row)" size="mini" type="success" @click="completePrototype(scope.row)">更新状态</el-button>
              <el-button size="mini" @click="openRecordDialog(scope.row)">记录</el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination-bar">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next"
          :current-page="containerPagination.page"
          :page-size="containerPagination.pageSize"
          :page-sizes="[10, 20, 50]"
          :total="containerPagination.total"
          @size-change="handleContainerSizeChange"
          @current-change="handleContainerPageChange"
        />
      </div>
    </el-dialog>

    <el-dialog title="入账/出账记录" :visible.sync="recordDialogVisible" width="920px">
      <div class="record-title">{{ recordItemName }}</div>
      <div class="record-chart">
        <div v-for="item in recordChartItems" :key="item.label" class="chart-row">
          <div class="chart-label">{{ item.label }}</div>
          <div class="chart-track">
            <div class="chart-bar" :class="item.className" :style="{ width: item.width }" />
          </div>
          <div class="chart-value">{{ item.value }}</div>
        </div>
      </div>
      <el-table v-loading="recordLoading" :data="recordRows" border height="320" style="width:100%">
        <el-table-column prop="date" label="日期" width="180" />
        <el-table-column prop="type" label="类型" width="90">
          <template slot-scope="scope">
            <el-tag :type="scope.row.type === '出账' ? 'warning' : 'success'">{{ scope.row.type }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="quantity" label="数量" width="100" :formatter="integerFormatter" />
        <el-table-column prop="boundMaterial" label="绑定物料" min-width="150" show-overflow-tooltip />
        <el-table-column prop="approvalStatus" label="审批状态" width="110" />
        <el-table-column prop="approvedAt" label="审批时间" width="170" />
        <el-table-column prop="approver" label="审批人" width="120" />
        <el-table-column prop="operator" label="操作人" width="120" />
      </el-table>
    </el-dialog>

    <el-dialog title="批量修改录入人" :visible.sync="batchDialogVisible" width="380px" @close="batchEntryPerson = ''">
      <el-form label-width="80px">
        <el-form-item label="录入人">
          <el-input v-model="batchEntryPerson" />
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="batchDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="submitBatchEdit">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog title="数据汇总" :visible.sync="summaryDialogVisible" width="960px">
      <div class="summary-chart">
        <div v-for="item in summaryChartItems" :key="item.label" class="chart-row">
          <div class="chart-label">{{ item.label }}</div>
          <div class="chart-track">
            <div class="chart-bar" :class="item.className" :style="{ width: item.width }" />
          </div>
          <div class="chart-value">{{ item.value }}</div>
        </div>
      </div>

      <el-table v-loading="summaryLoading" :data="summaryRows" border height="360" style="width:100%">
        <el-table-column prop="entryPerson" label="录入人" width="120" show-overflow-tooltip />
        <el-table-column prop="team" label="所属团队" width="140" />
        <el-table-column prop="engineer" label="工程师" width="120" />
        <el-table-column prop="itemName" label="样机名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="receive" label="入账数" width="120" :formatter="integerFormatter" />
        <el-table-column prop="out" label="出账数" width="120" :formatter="integerFormatter" />
        <el-table-column prop="remain" label="剩余数" width="120" :formatter="integerFormatter" />
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import axios from "axios"
import { API_BASE } from "../../config/appConfig"
import { isSameData } from "../../utils/dataChange"

const emptyForm = () => ({
  id: "",
  item_name: "",
  quantity: 1,
  out_number: 0,
  storage_location: "",
  provider: "",
  recipient: "",
  delivery_product_line: "",
  delivery_rd_engineer: "",
  carry_out_number: "",
  entry_person: "",
  team: "",
  engineer: "",
  project_name: "",
  prototype_owner: [],
  use: "",
  remark: ""
})

const emptySearchForm = () => ({
  date: [],
  itemName: "",
  storageLocation: "",
  entryPerson: "",
  projectName: "",
  status: ""
})

export default {
  data() {
    return {
      loading: false,
      rows: [],
      selectedRows: [],
      user: {},
      useOptions: [
        "样机交付",
        "样机报废"
      ],
      productLineOptions: [],
      projectOptions: [],
      projectAddressOptions: [],
      completionAddressOptions: [],
      projectPrototypeNames: [],
      userOptions: [],
      searchForm: emptySearchForm(),
      dialogVisible: false,
      completionDialogVisible: false,
      outDialogVisible: false,
      imageDialogVisible: false,
      scrapDialogVisible: false,
      writeoffDialogVisible: false,
      recordDialogVisible: false,
      batchDialogVisible: false,
      summaryDialogVisible: false,
      containerDialogVisible: false,
      containerLoading: false,
      containerTitle: "",
      containerCurrentId: "",
      containerChildren: [],
      selectedContainerChildren: [],
      containerSearchStatus: "",
      containerPagination: {
        page: 1,
        pageSize: 10,
        total: 0
      },
      form: emptyForm(),
      outForm: emptyForm(),
      currentImageUrl: "",
      recordItemName: "",
      recordRows: [],
      recordSummary: {
        receive: 0,
        out: 0,
        pending: 0,
        remain: 0
      },
      recordLoading: false,
      batchEntryPerson: "",
      summaryRows: [],
      summaryTotals: {
        receive: 0,
        out: 0,
        remain: 0
      },
      prototypeTotals: {
        total: 0,
        producing: 0,
        completed: 0,
        delivered: 0
      },
      summaryLoading: false,
      completingRows: [],
      completionFileList: [],
      completionSelectedImageFile: null,
      completionStorageLocation: "",
      completionHasExistingImage: false,
      outFileList: [],
      outSelectedImageFile: null,
      outAvailablePrototypes: [],
      selectedOutPrototypes: [],
      disposalLoading: false,
      disposalRows: [],
      selectedDisposalRows: [],
      scrapProofFileList: [],
      scrapProofFile: null,
      refreshTimer: null,
      fetchSerial: 0,
      formRules: {
        item_name: [
          { required: true, message: "请输入样机名称", trigger: "blur" }
        ],
        quantity: [
          { required: true, message: "请输入数量", trigger: "change" }
        ],
        project_name: [
          { required: true, message: "请选择项目", trigger: "change" }
        ],
        prototype_owner: [
          { type: "array", required: true, min: 1, message: "请选择样机归属人", trigger: "change" }
        ]
      },
      pagination: {
        page: 1,
        pageSize: 20,
        total: 0
      }
    }
  },

  watch: {
    "$route.path"() {
      this.handleRouteChanged()
    }
  },

  computed: {
    isAdmin() {
      return Number(this.user.permissions) === 1
    },

    isTechnician() {
      return Number(this.user.permissions) === 0 && this.user.category === "技师"
    },

    isEngineer() {
      return Number(this.user.permissions) === 0 && this.user.category === "工程师"
    },

    canMaintainPrototype() {
      return String(this.user.additionalRole || "")
        .replace(/[，、；;|/\s]+/g, ",")
        .split(",")
        .map(item => item.trim())
        .includes("交付接口人")
    },

    canEditPrototype() {
      return !this.isEngineer && this.canMaintainPrototype
    },

    isTechnicianEdit() {
      return this.isTechnician && Boolean(this.form.id)
    },

    showPrototypeBaseFields() {
      return !this.isTechnicianEdit
    },

    activeProjectOptions() {
      return this.projectOptions.filter(item => item.status !== "结项")
    },

    isManageView() {
      return this.$route.path === "/prototype/manage"
    },

    recordChartItems() {
      const maxValue = Math.max(
        Number(this.recordSummary.receive) || 0,
        Number(this.recordSummary.out) || 0,
        Number(this.recordSummary.pending) || 0,
        Number(this.recordSummary.remain) || 0,
        1
      )

      return [
        {
          label: "入账数",
          value: this.formatInteger(this.recordSummary.receive),
          width: this.recordSummary.receive > 0 ? `${Math.max((this.recordSummary.receive / maxValue) * 100, 4)}%` : "0%",
          className: "receive"
        },
        {
          label: "出账数",
          value: this.formatInteger(this.recordSummary.out),
          width: this.recordSummary.out > 0 ? `${Math.max((this.recordSummary.out / maxValue) * 100, 4)}%` : "0%",
          className: "out"
        },
        {
          label: "待出账数",
          value: this.formatInteger(this.recordSummary.pending),
          width: this.recordSummary.pending > 0 ? `${Math.max((this.recordSummary.pending / maxValue) * 100, 4)}%` : "0%",
          className: "pending"
        },
        {
          label: "剩余数",
          value: this.formatInteger(this.recordSummary.remain),
          width: this.recordSummary.remain > 0 ? `${Math.max((this.recordSummary.remain / maxValue) * 100, 4)}%` : "0%",
          className: "remain"
        }
      ]
    },

    summaryChartItems() {
      const maxValue = Math.max(
        Number(this.summaryTotals.receive) || 0,
        Number(this.summaryTotals.out) || 0,
        Number(this.summaryTotals.remain) || 0,
        1
      )

      return [
        {
          label: "入账总数",
          value: this.formatInteger(this.summaryTotals.receive),
          width: `${Math.max((this.summaryTotals.receive / maxValue) * 100, 4)}%`,
          className: "receive"
        },
        {
          label: "出账总数",
          value: this.formatInteger(this.summaryTotals.out),
          width: `${Math.max((this.summaryTotals.out / maxValue) * 100, 4)}%`,
          className: "out"
        },
        {
          label: "剩余总数",
          value: this.formatInteger(this.summaryTotals.remain),
          width: `${Math.max((this.summaryTotals.remain / maxValue) * 100, 4)}%`,
          className: "remain"
        }
      ]
    },

    prototypeTotalItems() {
      return [
        { label: "样机总数", value: Number(this.prototypeTotals.total || 0) },
        { label: "待生产数量", value: Number(this.prototypeTotals.producing || 0) },
        { label: "已完成数量", value: Number(this.prototypeTotals.completed || 0) },
        { label: "交付数量", value: Number(this.prototypeTotals.delivered || 0) }
      ]
    }
  },

  created() {
    const user = localStorage.getItem("user")
    if (user) {
      this.user = JSON.parse(user)
    }
    this.searchForm = this.defaultSearchForm()
    this.refreshCurrentUser()
    this.fetchData()
    this.fetchProductLines()
    this.fetchProjectOptions()
    this.fetchUserOptions()
    this.refreshTimer = setInterval(() => this.fetchData(true), 15000)
  },

  beforeDestroy() {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer)
    }
  },

  methods: {
    defaultSearchForm() {
      const form = emptySearchForm()
      if (!this.isAdmin && this.user.username) {
        form.entryPerson = this.user.username
      }
      return form
    },

    formatInteger(value) {
      if (value === null || value === undefined || value === "") {
        return ""
      }

      const numberValue = Number(value)
      if (!Number.isFinite(numberValue)) {
        return value
      }

      return String(Math.round(numberValue))
    },

    integerFormatter(row, column, cellValue) {
      return this.formatInteger(cellValue)
    },

    isRowSelectable() {
      return true
    },

    prototypeStatusType(status) {
      if (status === "已交付") return "warning"
      if (status === "已完成") return "success"
      return "info"
    },

    completePrototype(row) {
      if (!this.canUpdatePrototypeStatus(row)) {
        this.$message.warning("只能更新自己创建的样机状态")
        return
      }
      this.preparePrototypeCompletion([row])
    },

    preparePrototypeCompletion(rows) {
      const completionRows = (rows || []).filter(item => item && this.canUpdatePrototypeStatus(item))
      if (!completionRows.length) {
        this.$message.warning("请选择生产中的样机")
        return
      }

      this.completingRows = completionRows
      this.openCompletionImageDialog()
    },

    openCompletionImageDialog() {
      this.resetCompletionForm()
      const firstRow = this.completingRows[0] || {}
      this.completionHasExistingImage = this.completingRows.every(item => item.image_path)
      const rowWithStorage = this.completingRows.find(item => item.storage_location)
      this.completionStorageLocation = rowWithStorage ? rowWithStorage.storage_location : ""
      this.completionDialogVisible = true
      this.fetchProjectAddressOptions(firstRow.project_name, "completionAddressOptions")
      if (firstRow.project_name) {
        axios.get(`${API_BASE}/project_address/latest`, {
          params: { projectName: firstRow.project_name }
        }).then(res => {
          if (!this.completionStorageLocation && res.data.code === 200 && res.data.data && res.data.data.address) {
            this.completionStorageLocation = res.data.data.address
          }
        }).catch(() => {})
      }
    },

    handleCompletionImageChange(file, fileList) {
      if (!this.validateImageFile(file)) {
        this.completionFileList = []
        this.completionSelectedImageFile = null
        return
      }
      this.completionFileList = fileList.slice(-1)
      this.completionSelectedImageFile = file.raw
    },

    resetCompletionImage() {
      this.completionFileList = []
      this.completionSelectedImageFile = null
    },

    resetCompletionForm() {
      this.resetCompletionImage()
      this.completionStorageLocation = ""
      this.completionHasExistingImage = false
      this.completionAddressOptions = []
    },

    submitCompletionWithImage() {
      if (!this.completionStorageLocation) {
        this.$message.warning("请输入存放位置")
        return
      }
      if (!this.completionSelectedImageFile && !this.completionHasExistingImage) {
        this.$message.warning("请选择样机图片")
        return
      }
      this.submitPrototypeCompletion(this.completionSelectedImageFile)
    },

    submitPrototypeCompletion(imageFile = null) {
      const rows = this.completingRows
      if (!rows.length) {
        return
      }

      const formData = new FormData()
      formData.append("status", "已完成")
      formData.append("storageLocation", this.completionStorageLocation)
      formData.append("operator", this.user.username || "")
      if (imageFile) {
        formData.append("image", imageFile)
      }
      const url = rows.length === 1
        ? `${API_BASE}/prototype/status/${rows[0].id}`
        : `${API_BASE}/prototype/status_batch`
      if (rows.length > 1) {
        formData.append("ids", JSON.stringify(rows.map(item => item.id)))
      }

      axios.post(url, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.completionDialogVisible = false
          this.completingRows = []
          this.fetchData()
          if (this.containerDialogVisible && this.containerCurrentId) {
            this.fetchContainerChildren()
          }
        } else {
          this.$message.error(res.data.msg || "状态更新失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    openContainerDialog(row) {
      this.containerTitle = row.item_name
      this.containerCurrentId = row.id
      this.containerChildren = []
      this.selectedContainerChildren = []
      this.containerSearchStatus = ""
      this.containerPagination.page = 1
      this.containerPagination.total = 0
      this.containerDialogVisible = true
      this.fetchContainerChildren()
    },

    fetchContainerChildren() {
      this.containerLoading = true
      axios.get(`${API_BASE}/prototype/container/${this.containerCurrentId}/children`, {
        params: {
          page: this.containerPagination.page,
          pageSize: this.containerPagination.pageSize,
          status: this.containerSearchStatus
        }
      }).then(res => {
        if (res.data.code === 200) {
          this.containerChildren = res.data.data || []
          this.containerPagination.total = Number(res.data.total || 0)
        } else {
          this.$message.error(res.data.msg || "获取容器内样机失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.containerLoading = false
      })
    },

    handleContainerStatusChange() {
      this.containerPagination.page = 1
      this.selectedContainerChildren = []
      this.fetchContainerChildren()
    },

    handleContainerSizeChange(size) {
      this.containerPagination.pageSize = size
      this.containerPagination.page = 1
      this.selectedContainerChildren = []
      this.fetchContainerChildren()
    },

    handleContainerPageChange(page) {
      this.containerPagination.page = page
      this.selectedContainerChildren = []
      this.fetchContainerChildren()
    },

    handleContainerSelectionChange(rows) {
      this.selectedContainerChildren = rows
    },

    batchCompleteContainerChildren() {
      const rows = this.selectedContainerChildren.filter(item => this.canUpdatePrototypeStatus(item))
      if (!rows.length) {
        this.$message.warning("选中的样机中没有自己创建的生产中数据")
        return
      }
      this.preparePrototypeCompletion(rows)
    },

    exportContainerChildren() {
      const identityCodes = this.selectedContainerChildren.map(item => item.identity_code).filter(Boolean)
      if (!identityCodes.length) return
      axios.post(`${API_BASE}/prototype/export`, {
        identityCodes,
        scopeUser: this.isManageView ? "" : this.user.username
      }, {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `样机记录导出_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      })
    },

    handleRouteChanged() {
      this.pagination.page = 1
      this.selectedRows = []
      this.rows = []
      this.pagination.total = 0
      this.searchForm = this.defaultSearchForm()
      this.refreshCurrentUser()
      this.fetchData()
    },

    refreshCurrentUser() {
      if (!this.user.username) {
        return
      }

      axios.get(`${API_BASE}/user/profile/${encodeURIComponent(this.user.username)}`).then(res => {
        if (res.data.code !== 200 || !res.data.data) {
          return
        }

        this.user = Object.assign({}, this.user, res.data.data)
        localStorage.setItem("user", JSON.stringify(this.user))
      }).catch(() => {})
    },

    cleanSearchForm() {
      return {
        date: this.searchForm.date || [],
        itemName: (this.searchForm.itemName || "").trim(),
        storageLocation: (this.searchForm.storageLocation || "").trim(),
        entryPerson: (this.searchForm.entryPerson || "").trim(),
        projectName: (this.searchForm.projectName || "").trim(),
        status: (this.searchForm.status || "").trim()
      }
    },

    fetchData(silent = false) {
      silent = silent === true
      const currentSerial = ++this.fetchSerial
      if (!silent) {
        this.loading = true
      }
      axios.post(`${API_BASE}/prototype/list`, {
        ...this.cleanSearchForm(),
        page: this.pagination.page,
        pageSize: this.pagination.pageSize,
        scopeUser: this.isManageView ? "" : this.user.username
      }).then(res => {
        if (currentSerial !== this.fetchSerial) {
          return
        }

        if (res.data.code === 200) {
          const nextRows = res.data.data || []
          const nextTotal = Number(res.data.total || 0)
          const nextSummary = this.normalizePrototypeTotals(res.data.summary)
          if (!isSameData(this.rows, nextRows) || this.pagination.total !== nextTotal || !isSameData([this.prototypeTotals], [nextSummary])) {
            this.rows = nextRows
            this.pagination.total = nextTotal
            this.prototypeTotals = nextSummary
          }
        } else if (!silent) {
          this.$message.error(res.data.msg || "获取失败")
        }
      }).catch(() => {
        if (currentSerial !== this.fetchSerial) {
          return
        }

        if (!silent) {
          this.$message.error("网络请求失败，请检查后端是否启动")
        }
      }).finally(() => {
        if (!silent && currentSerial === this.fetchSerial) {
          this.loading = false
        }
      })
    },

    handleSearch() {
      this.searchForm = this.cleanSearchForm()
      this.pagination.page = 1
      this.fetchData()
    },

    handleReset() {
      this.searchForm = this.defaultSearchForm()
      this.pagination.page = 1
      this.fetchData()
    },

    normalizePrototypeTotals(summary = {}) {
      return {
        total: Number(summary.total || 0),
        producing: Number(summary.producing || 0),
        completed: Number(summary.completed || 0),
        delivered: Number(summary.delivered || 0)
      }
    },

    handleSelectionChange(rows) {
      this.selectedRows = rows
    },

    canOutPrototype(row) {
      return this.isTechnician &&
        row &&
        String(row.entry_person || "") === String(this.user.username || "") &&
        Number(row.quantity || 0) > 0 &&
        (row.row_type === "container" || row.status === "已完成")
    },

    canUpdatePrototypeStatus(row) {
      return this.canMaintainPrototype &&
        row &&
        row.status === "生产中" &&
        String(row.entry_person || "") === String(this.user.username || "")
    },

    openScrapDialog() {
      this.scrapDialogVisible = true
      this.scrapProofFileList = []
      this.scrapProofFile = null
      this.loadDisposalCandidates("scrap", "prototypeScrapTable")
    },

    openWriteoffDialog() {
      this.writeoffDialogVisible = true
      this.loadDisposalCandidates("writeoff", "prototypeWriteoffTable")
    },

    resetDisposalDialog() {
      this.disposalRows = []
      this.selectedDisposalRows = []
      this.disposalLoading = false
      this.scrapProofFileList = []
      this.scrapProofFile = null
    },

    loadDisposalCandidates(action, tableRef) {
      this.disposalRows = []
      this.selectedDisposalRows = []
      this.disposalLoading = true
      axios.get(`${API_BASE}/prototype/disposal_candidates`, {
        params: {
          username: this.user.username,
          action
        }
      }).then(res => {
        if (res.data.code === 200) {
          this.disposalRows = res.data.data || []
          this.$nextTick(() => {
            if (tableRef && this.$refs[tableRef]) {
              this.$refs[tableRef].clearSelection()
            }
          })
        } else {
          this.$message.error(res.data.msg || "获取样机失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.disposalLoading = false
      })
    },

    handleDisposalSelectionChange(rows) {
      this.selectedDisposalRows = rows || []
    },

    handleScrapProofChange(file) {
      if (!this.validateImageFile(file)) {
        this.scrapProofFileList = []
        this.scrapProofFile = null
        return
      }
      this.scrapProofFileList = [file]
      this.scrapProofFile = file.raw
    },

    handleScrapProofExceed(files) {
      const rawFile = files && files[0]
      if (!rawFile) {
        return
      }
      this.handleScrapProofChange({
        name: rawFile.name,
        raw: rawFile,
        uid: Date.now()
      })
    },

    handleScrapProofRemove() {
      this.scrapProofFileList = []
      this.scrapProofFile = null
    },

    submitScrap() {
      if (!this.selectedDisposalRows.length) {
        this.$message.error("请选择要报废的样机")
        return
      }
      if (!this.scrapProofFile) {
        this.$message.error("请上传评审证明")
        return
      }
      const formData = new FormData()
      formData.append("operator", this.user.username || "")
      formData.append("ids", JSON.stringify(this.selectedDisposalRows.map(item => item.id)))
      formData.append("proof", this.scrapProofFile)
      this.disposalLoading = true
      axios.post(`${API_BASE}/prototype/scrap`, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.scrapDialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "报废提交失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.disposalLoading = false
      })
    },

    submitWriteoff() {
      if (!this.selectedDisposalRows.length) {
        this.$message.error("请选择要销账的样机")
        return
      }
      this.disposalLoading = true
      axios.post(`${API_BASE}/prototype/writeoff`, {
        operator: this.user.username || "",
        ids: this.selectedDisposalRows.map(item => item.id)
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.writeoffDialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "销账提交失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.disposalLoading = false
      })
    },

    fetchProductLines() {
      axios.get(`${API_BASE}/product_line/list`).then(res => {
        if (res.data.code === 200) {
          this.productLineOptions = res.data.data.map(item => item.line_name)
        }
      })
    },

    fetchProjectOptions() {
      axios.get(`${API_BASE}/project/list`).then(res => {
        if (res.data.code === 200) {
          this.projectOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    fetchProjectAddressOptions(projectName, target = "projectAddressOptions") {
      this[target] = []
      if (!projectName) {
        return
      }
      axios.get(`${API_BASE}/project_address/list`, {
        params: { projectName }
      }).then(res => {
        if (res.data.code === 200) {
          this[target] = res.data.data || []
        }
      }).catch(() => {})
    },

    ensureProjectAddress(projectName, address) {
      const nextProject = String(projectName || "").trim()
      const nextAddress = String(address || "").trim()
      if (!nextProject || !nextAddress) {
        return Promise.resolve()
      }

      const existed = this.projectAddressOptions.some(item => item.address === nextAddress) ||
        this.completionAddressOptions.some(item => item.address === nextAddress)
      if (existed) {
        return Promise.resolve()
      }

      return axios.post(`${API_BASE}/project_address/save`, {
        projectName: nextProject,
        address: nextAddress
      }).then(res => {
        if (res.data.code !== 200 && !String(res.data.msg || "").includes("已存在")) {
          return Promise.reject(new Error(res.data.msg || "地址保存失败"))
        }
        this.fetchProjectAddressOptions(nextProject)
        this.fetchProjectAddressOptions(nextProject, "completionAddressOptions")
      })
    },

    fetchUserOptions() {
      axios.get(`${API_BASE}/user/options`).then(res => {
        if (res.data.code === 200) {
          this.userOptions = res.data.data || []
          if (this.form.prototype_owner && this.form.prototype_owner.length) {
            this.$set(this.form, "prototype_owner", this.parsePrototypeOwners(this.form.prototype_owner))
          }
        }
      }).catch(() => {})
    },

    fetchProjectPrototypeNames(projectName) {
      this.projectPrototypeNames = []
      if (!projectName) {
        return
      }
      axios.get(`${API_BASE}/prototype/name_options`, {
        params: { projectName }
      }).then(res => {
        if (res.data.code === 200) {
          this.projectPrototypeNames = res.data.data || []
        }
      }).catch(() => {})
    },

    handleProjectChange(projectName) {
      if (!this.form.id) {
        this.form.item_name = ""
      }
      this.fetchProjectPrototypeNames(projectName)
      this.fetchProjectAddressOptions(projectName)
    },

    queryPrototypeNameSuggestions(queryString, callback) {
      const keyword = String(queryString || "").trim().toLowerCase()
      const suggestions = this.projectPrototypeNames
        .filter(item => !keyword || String(item).toLowerCase().includes(keyword))
        .map(item => ({ value: item }))
      callback(suggestions)
    },

    handlePrototypeNameSelect() {
      this.$nextTick(() => this.handlePrototypeNameBlur())
    },

    parsePrototypeOwners(value) {
      const values = (Array.isArray(value) ? value : String(value || "")
        .replace(/，|,/g, "、")
        .split("、"))
        .map(item => item.trim())
        .filter(Boolean)
      return values.map(value => {
        const jobNumber = value.split(/\s+/)[0]
        const user = this.userOptions.find(item => item.username === jobNumber)
        return user ? user.label : value
      })
    },

    prototypeOwnerFormatter(row) {
      return this.parsePrototypeOwners(row.prototype_owner).join("、")
    },

    handlePrototypeNameBlur() {
      const itemName = (this.form.item_name || "").trim()
      if (!itemName || !this.form.project_name || this.form.id) {
        return
      }
      axios.get(`${API_BASE}/prototype/container/defaults`, {
        params: {
          itemName,
          projectName: this.form.project_name,
          entryPerson: this.user.username || ""
        }
      }).then(res => {
        if (res.data.code !== 200 || !res.data.data || !res.data.data.container_code) {
          return
        }
        const defaults = res.data.data
        const fillKeys = ["project_name", "storage_location", "remark"]
        fillKeys.forEach(key => {
          if (!this.form[key] && defaults[key]) {
            this.$set(this.form, key, defaults[key])
          }
        })
        if (!this.form.prototype_owner.length && defaults.prototype_owner) {
          this.$set(this.form, "prototype_owner", this.parsePrototypeOwners(defaults.prototype_owner))
        }
        this.$message.success("已补全同名容器信息")
      }).catch(() => {})
    },

    openDialog(row) {
      this.form = row ? Object.assign(emptyForm(), row, {
        prototype_owner: this.parsePrototypeOwners(row.prototype_owner)
      }) : Object.assign(emptyForm(), {
        recipient: "",
        entry_person: this.user.username || "",
        team: this.user.team || "",
        engineer: this.user.engineer || ""
      })
      this.fetchProjectPrototypeNames(this.form.project_name)
      this.fetchProjectAddressOptions(this.form.project_name)
      this.dialogVisible = true
    },

    viewImage(row) {
      this.currentImageUrl = row.image_path ? `${API_BASE}${row.image_path}` : ""
      this.imageDialogVisible = true
    },

    openOutDialog(row) {
      if (!this.canOutPrototype(row)) {
        this.$message.warning("只有录入人本人可以出账，且样机必须为已完成状态")
        return
      }

      const capacityUrl = row.row_type === "container"
        ? `${API_BASE}/prototype/container/out_capacity/${row.id}`
        : `${API_BASE}/prototype/out_capacity/${row.id}`

      axios.get(capacityUrl, {
        params: {
          submitter: this.user.username
        }
      }).then(res => {
        if (res.data.code !== 200) {
          this.$message.warning(res.data.msg || "当前数量为0，不能出账")
          return
        }

        const capacity = res.data.data || {}
        if (Number(capacity.available_quantity || 0) <= 0) {
          this.$message.warning("当前样机数量为0，不能出账")
          return
        }

        this.outForm = Object.assign(emptyForm(), row, {
          quantity: Number(capacity.available_quantity || 0),
          out_number: row.row_type === "container" ? 0 : 1,
          use: "",
          recipient: this.user.username || "",
          delivery_product_line: "",
          delivery_rd_engineer: "",
          carry_out_number: "",
          remark: ""
        })
        this.outAvailablePrototypes = row.row_type === "container" ? (capacity.prototypes || []) : [row]
        this.selectedOutPrototypes = row.row_type === "container" ? [] : [row]
        this.outDialogVisible = true
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    resetOutForm() {
      this.outForm = emptyForm()
      this.outFileList = []
      this.outSelectedImageFile = null
      this.outAvailablePrototypes = []
      this.selectedOutPrototypes = []
    },

    handleOutPrototypeSelection(rows) {
      this.selectedOutPrototypes = rows || []
      this.outForm.out_number = this.selectedOutPrototypes.length
    },

    submitOut() {
      if (this.outForm.row_type === "container" && !this.selectedOutPrototypes.length) {
        this.$message.error("请选择需要出账的样机")
        return
      }
      if (!this.outForm.out_number || Number(this.outForm.out_number) <= 0) {
        this.$message.error("出账数量必须大于0")
        return
      }

      if (Number(this.outForm.out_number) > Number(this.outForm.quantity || 0)) {
        this.$message.error("出账数量不能大于当前数量")
        return
      }

      const needsDeliveryFields = this.outForm.use !== "样机报废"
      if (!this.outForm.use || !this.outForm.recipient || (needsDeliveryFields && (!this.outForm.delivery_product_line || !this.outForm.delivery_rd_engineer || !this.outForm.carry_out_number))) {
        this.$message.error("请填写完整的样机出账必填项")
        return
      }
      if (!needsDeliveryFields) {
        this.outForm.delivery_product_line = ""
        this.outForm.delivery_rd_engineer = ""
        this.outForm.carry_out_number = ""
      }

      const formData = new FormData()
      formData.append("id", this.outForm.id)
      formData.append("outNumber", this.outForm.out_number)
      formData.append("use", this.outForm.use)
      formData.append("recipient", this.outForm.recipient)
      formData.append("deliveryProductLine", this.outForm.delivery_product_line)
      formData.append("deliveryRdEngineer", this.outForm.delivery_rd_engineer)
      formData.append("approvalEngineer", this.user.engineer || "")
      formData.append("carryOutNumber", this.outForm.carry_out_number)
      formData.append("remark", this.outForm.remark || "")
      formData.append("operator", this.user.username || "")
      formData.append("permissions", this.user.permissions)
      formData.append("category", this.user.category || "")
      if (this.outForm.row_type === "container") {
        formData.append("prototypeIds", JSON.stringify(this.selectedOutPrototypes.map(item => item.id)))
      }
      if (this.outSelectedImageFile) {
        formData.append("image", this.outSelectedImageFile)
      }

      const outUrl = this.outForm.row_type === "container"
        ? `${API_BASE}/prototype/container/out`
        : `${API_BASE}/prototype/out`

      axios.post(outUrl, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.outDialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "出账失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    openRecordDialog(row) {
      this.recordItemName = row.item_name
      this.recordDialogVisible = true
      this.recordLoading = true
      axios.get(`${API_BASE}/prototype/records`, {
        params: { prototypeId: row.id, identityCode: row.identity_code, itemName: row.item_name }
      }).then(res => {
        if (res.data.code === 200) {
          this.recordRows = res.data.data
          this.recordSummary = res.data.summary
        } else {
          this.$message.error(res.data.msg || "获取记录失败")
        }
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.recordLoading = false
      })
    },

    exportSameItem(row) {
      axios.post(`${API_BASE}/prototype/export`, {
        identityCodes: [row.identity_code].filter(Boolean),
        ids: row.identity_code ? [] : [row.id],
        scopeUser: this.isManageView ? "" : this.user.username
      }, {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `样机记录导出_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      })
    },

    downloadImportTemplate() {
      axios.get(`${API_BASE}/prototype/template`, {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `样机导入模板_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      }).catch(() => {
        this.$message.error("模板下载失败，请检查后端是否启动")
      })
    },

    handleImportChange(file) {
      const formData = new FormData()
      formData.append("file", file.raw)
      formData.append("entryPerson", this.user.username || "")
      formData.append("team", this.user.team || "")
      formData.append("engineer", this.user.engineer || "")

      axios.post(`${API_BASE}/prototype/import`, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "导入失败")
        }
      }).catch(() => {
        this.$message.error("导入失败，请检查文件格式")
      })
    },

    saveData() {
      this.$refs.prototypeForm.validate(valid => {
        if (!valid) {
          return
        }

        this.ensureProjectAddress(this.form.project_name, this.form.storage_location).then(() => {
          const formData = new FormData()
          Object.keys(this.form).forEach(key => {
            if (this.form[key] !== undefined && this.form[key] !== null) {
              formData.append(key, this.form[key])
            }
          })
          axios.post(`${API_BASE}/prototype/save`, formData).then(res => {
            if (res.data.code === 200) {
              this.$message.success(res.data.msg)
              this.dialogVisible = false
              this.fetchData()
            } else {
              this.$message.error(res.data.msg || "提交失败")
            }
          }).catch(() => {
            this.$message.error("网络请求失败，请检查后端是否启动")
          })
        }).catch(err => {
          this.$message.error(err.message || "地址保存失败")
        })
      })
    },

    validateImageFile(file) {
      const name = (file && file.name) || (file && file.raw && file.raw.name) || ""
      const ext = name.includes(".") ? name.split(".").pop().toLowerCase() : ""
      const allowed = ["png", "jpg", "jpeg", "gif", "webp", "bmp"]
      if (!allowed.includes(ext)) {
        this.$message.error("图片格式仅支持 png、jpg、jpeg、gif、webp、bmp")
        return false
      }
      return true
    },

    deleteRow(row) {
      this.$confirm(`确认删除 ${row.item_name}？`, "提示", { type: "warning" }).then(() => {
        axios.delete(`${API_BASE}/prototype/delete/${row.id}`).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchData()
          } else {
            this.$message.error(res.data.msg || "删除失败")
          }
        })
      }).catch(() => {})
    },

    deleteContainer(row) {
      this.$confirm(`确认删除容器 ${row.item_name} 及容器内全部样机？删除后不可恢复。`, "删除容器", {
        type: "warning",
        confirmButtonText: "确认删除"
      }).then(() => {
        axios.delete(`${API_BASE}/prototype/container/delete/${row.id}`, {
          params: { permissions: this.user.permissions }
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchData()
          } else {
            this.$message.error(res.data.msg || "删除容器失败")
          }
        })
      }).catch(() => {})
    },

    deleteSelected() {
      if (!this.selectedRows.length) {
        this.$message.warning("请选择要删除的数据")
        return
      }

      this.$confirm(`确认删除选中的 ${this.selectedRows.length} 条数据？`, "提示", { type: "warning" }).then(() => {
        axios.post(`${API_BASE}/prototype/delete_batch`, {
          ids: this.selectedRows.filter(item => item.row_type !== "container").map(item => item.id),
          containerIds: this.selectedRows.filter(item => item.row_type === "container").map(item => item.id),
          permissions: this.user.permissions
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchData()
          } else {
            this.$message.error(res.data.msg || "批量删除失败")
          }
        })
      }).catch(() => {})
    },

    openBatchDialog() {
      if (!this.selectedRows.length) {
        this.$message.warning("请选择要修改的数据")
        return
      }

      if (this.selectedRows.some(item => item.row_type === "container")) {
        this.$message.warning("容器不支持批量修改，请只选择单台样机")
        return
      }

      this.batchDialogVisible = true
    },

    submitBatchEdit() {
      if (!this.batchEntryPerson) {
        this.$message.error("请输入录入人")
        return
      }

      axios.post(`${API_BASE}/prototype/batch_update_entry_person`, {
        ids: this.selectedRows.filter(item => item.row_type !== "container").map(item => item.id),
        entryPerson: this.batchEntryPerson,
        permissions: this.user.permissions
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.batchDialogVisible = false
          this.fetchData()
        } else {
          this.$message.error(res.data.msg || "批量修改失败")
        }
      })
    },

    openSummaryDialog() {
      if (this.selectedRows.some(item => item.row_type === "container")) {
        this.$message.warning("容器不支持直接汇总，请进入容器后查看内部样机")
        return
      }

      this.summaryDialogVisible = true
      this.summaryLoading = true
      const ids = this.selectedRows.map(item => item.id)
      axios.post(`${API_BASE}/prototype/summary`, Object.assign({
        scopeUser: this.isManageView ? "" : this.user.username
      }, ids.length ? { ids } : this.cleanSearchForm())).then(res => {
        if (res.data.code === 200) {
          this.summaryRows = res.data.data.byItem
          this.summaryTotals = res.data.data.totals
        } else {
          this.$message.error(res.data.msg || "获取汇总失败")
        }
      }).finally(() => {
        this.summaryLoading = false
      })
    },

    exportData() {
      const selectedContainers = this.selectedRows.filter(item => item.row_type === "container")
      const selectedPrototypes = this.selectedRows.filter(item => item.row_type !== "container")
      if (selectedContainers.length && selectedPrototypes.length) {
        this.$message.warning("容器和单台样机请分开选择后导出")
        return
      }

      if (selectedContainers.length) {
        axios.post(`${API_BASE}/prototype/container/export`, {
          containerIds: selectedContainers.map(item => item.id),
          scopeUser: this.isManageView ? "" : this.user.username
        }, {
          responseType: "blob"
        }).then(res => {
          const blob = new Blob([res.data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" })
          const link = document.createElement("a")
          link.href = URL.createObjectURL(blob)
          link.download = `样机容器导出_${this.formatExportTime()}.xlsx`
          link.click()
          URL.revokeObjectURL(link.href)
        }).catch(() => {
          this.$message.error("容器导出失败，请检查后端是否启动")
        })
        return
      }

      const identityCodes = this.selectedRows.map(item => item.identity_code).filter(Boolean)
      axios.post(`${API_BASE}/prototype/export`, {
        ...(identityCodes.length ? { identityCodes } : this.cleanSearchForm()),
        scopeUser: this.isManageView ? "" : this.user.username
      }, {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `样机台账_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      })
    },

    handleSizeChange(size) {
      this.pagination.pageSize = size
      this.pagination.page = 1
      this.fetchData()
    },

    handleCurrentChange(page) {
      this.pagination.page = page
      this.fetchData()
    },

    handleOutImageChange(file, fileList) {
      if (!this.validateImageFile(file)) {
        this.outFileList = []
        this.outSelectedImageFile = null
        return
      }
      this.outFileList = fileList.slice(-1)
      this.outSelectedImageFile = file.raw
    },

    handleOutImageRemove() {
      this.outFileList = []
      this.outSelectedImageFile = null
    },

    resetForm() {
      this.form = emptyForm()
      if (this.$refs.prototypeForm) {
        this.$refs.prototypeForm.clearValidate()
      }
    },

    formatExportTime() {
      const date = new Date()
      const pad = value => String(value).padStart(2, "0")

      return [
        date.getFullYear(),
        pad(date.getMonth() + 1),
        pad(date.getDate())
      ].join("") + "_" + [
        pad(date.getHours()),
        pad(date.getMinutes()),
        pad(date.getSeconds())
      ].join("")
    }
  }
}
</script>

<style scoped>
.prototype-page {
  padding: 16px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}

.toolbar-title {
  font-size: 16px;
  font-weight: 600;
}

.search-card {
  margin-bottom: 16px;
}

.search-form {
  display: grid;
  grid-template-columns: repeat(4, minmax(240px, 1fr));
  gap: 12px 24px;
  align-items: start;
}

.search-form ::v-deep .el-form-item {
  margin-bottom: 0;
}

.search-form ::v-deep .el-date-editor,
.search-form ::v-deep .el-input {
  width: 100%;
}

.pagination-bar {
  display: flex;
  justify-content: flex-end;
  padding-top: 14px;
}

.operation-buttons {
  display: grid;
  grid-template-columns: repeat(2, 72px);
  gap: 6px;
}

.operation-buttons .el-button {
  width: 72px;
  margin-left: 0;
}

.prototype-total-bar {
  display: grid;
  grid-template-columns: repeat(4, minmax(140px, 1fr));
  gap: 12px;
  margin: 12px 0;
}

.prototype-total-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 42px;
  padding: 0 14px;
  border: 1px solid #ebeef5;
  border-radius: 4px;
  background: #fafafa;
  color: #606266;
}

.prototype-total-item strong {
  color: #303133;
  font-size: 18px;
  font-weight: 600;
}

@media (max-width: 900px) {
  .prototype-total-bar {
    grid-template-columns: repeat(2, minmax(140px, 1fr));
  }
}

.container-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 32px;
  margin-bottom: 12px;
  color: #606266;
}

.container-toolbar .el-button {
  margin-left: 8px;
}

.container-search {
  display: flex;
  gap: 12px;
  align-items: center;
}

.container-search .el-select {
  width: 150px;
}

.container-operation-buttons {
  grid-template-columns: repeat(2, 72px);
  align-items: start;
}

.out-selection-summary {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 8px;
  color: #606266;
  line-height: 1.4;
}

.out-selection-summary strong {
  color: #409eff;
  font-weight: 600;
}

.proof-upload {
  width: 100%;
}

.proof-upload ::v-deep .el-upload,
.proof-upload ::v-deep .el-upload-dragger {
  width: 100%;
}

.writeoff-steps {
  margin-bottom: 12px;
}

::v-deep .prototype-out-dialog {
  max-width: calc(100vw - 32px);
}

::v-deep .prototype-out-dialog .el-dialog__body {
  padding-top: 14px;
  padding-bottom: 6px;
}

.prototype-out-form ::v-deep .el-form-item {
  margin-bottom: 14px;
}

.completion-tip {
  margin-top: 6px;
  color: #909399;
  font-size: 12px;
  line-height: 1.4;
}

.project-image-tip {
  margin-bottom: 6px;
  color: #67c23a;
  line-height: 1.4;
}

.image-box {
  min-height: 260px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
}

.prototype-image {
  max-width: 100%;
  max-height: 520px;
  object-fit: contain;
}

.record-title {
  margin-bottom: 12px;
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.record-chart,
.summary-chart {
  padding: 12px;
  margin-bottom: 14px;
  border: 1px solid #ebeef5;
  border-radius: 6px;
  background: #fafafa;
}

.chart-row {
  display: grid;
  grid-template-columns: 70px 1fr 80px;
  gap: 12px;
  align-items: center;
  margin-bottom: 10px;
}

.chart-row:last-child {
  margin-bottom: 0;
}

.chart-label,
.chart-value {
  color: #606266;
}

.chart-value {
  text-align: right;
}

.chart-track {
  height: 16px;
  overflow: hidden;
  border-radius: 3px;
  background: #ebeef5;
}

.chart-bar {
  height: 100%;
  transition: width 0.2s ease;
}

.chart-bar.receive {
  background: #67c23a;
}

.chart-bar.out {
  background: #e6a23c;
}

.chart-bar.pending {
  background: #f56c6c;
}

.chart-bar.remain {
  background: #409eff;
}
</style>
