<template>
  <div class="page-container">
    <el-card class="search-card" shadow="never">
      <el-form :model="searchForm" class="search-form" size="small" label-width="86px">
        <el-form-item label="录入日期">
          <el-date-picker
            v-model="searchForm.date"
            type="daterange"
            align="right"
            unlink-panels
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="yyyy-MM-dd"
            :picker-options="pickerOptions"
          />
        </el-form-item>

        <el-form-item label="物品来源">
          <el-select
            v-model="searchForm.itemSource"
            placeholder="请选择"
            clearable
            style="width: 150px"
          >
            <el-option
              v-for="item in itemSourceOptions"
              :key="item"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="领用编码">
          <el-input v-model="searchForm.receiveCode" placeholder="领用编码" clearable />
        </el-form-item>

        <el-form-item label="catlog编码">
          <el-input v-model="searchForm.catlogCode" placeholder="catlog编码" clearable />
        </el-form-item>

        <el-form-item label="单号">
          <el-input v-model="searchForm.orderNumber" placeholder="领料单号" clearable />
        </el-form-item>

        <el-form-item label="物品名称">
          <el-input v-model="searchForm.itemName" placeholder="物品名称" clearable />
        </el-form-item>

        <el-form-item label="存放位置">
          <el-input v-model="searchForm.storageLocation" placeholder="存放位置" clearable />
        </el-form-item>

        <el-form-item label="物料提供人">
          <el-input v-model="searchForm.materialProvider" placeholder="物料提供人" clearable />
        </el-form-item>

        <el-form-item label="物料领取人">
          <el-input v-model="searchForm.materialRecipient" placeholder="物料领取人" clearable />
        </el-form-item>

        <el-form-item label="录入人">
          <el-input v-model="searchForm.entryPerson" placeholder="录入人" clearable />
        </el-form-item>

        <el-form-item label="单价区间">
          <el-input-number
            v-model="searchForm.minPrice"
            :min="0"
            :precision="2"
            controls-position="right"
            placeholder="最低单价"
            style="width: 130px"
          />
          <span class="price-separator">-</span>
          <el-input-number
            v-model="searchForm.maxPrice"
            :min="0"
            :precision="2"
            controls-position="right"
            placeholder="最高单价"
            style="width: 130px"
          />
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="handleSearch">
            搜索
          </el-button>
          <el-button @click="handleReset">
            重置
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-card class="table-card" shadow="never">
      <div class="toolbar">
        <div class="toolbar-title">
          物料台账
        </div>

        <div>
          <el-button v-if="canUseMaterial" type="primary" size="small" @click="openAddDialog">
            入账
          </el-button>
          <el-button v-if="canUseMaterial" type="warning" size="small" @click="openBatchOutDialog">
            批量出账
          </el-button>
          <el-button v-if="canUseMaterial" type="danger" size="small" @click="openScrapDialog">
            报废
          </el-button>
          <el-button v-if="canUseMaterial" type="warning" size="small" @click="openWriteoffDialog">
            销账
          </el-button>
          <el-button v-if="canUseMaterial" type="success" size="small" @click="openMaterialTransferDialog">
            转移
          </el-button>
          <el-button v-if="isAdmin" size="small" icon="el-icon-document" @click="downloadImportTemplate">
            导入模板
          </el-button>
          <el-upload
            v-if="isAdmin"
            action="#"
            :auto-upload="false"
            :show-file-list="false"
            accept=".csv"
            :on-change="handleImportChange"
            style="display:inline-block;margin-right:10px"
          >
            <el-button size="small" icon="el-icon-upload">
              导入
            </el-button>
          </el-upload>
          <el-button
            v-if="isAdmin"
            type="danger"
            size="small"
            @click="handleBatchDelete"
          >
            删除选中
          </el-button>
          <el-button size="small" @click="handleExport">
            导出
          </el-button>
          <el-button v-if="isAdmin" size="small" @click="handleBatchEdit">
            批量修改
          </el-button>
        </div>
      </div>

      <el-table
        v-loading="loading"
        :data="tableData"
        border
        row-key="id"
        height="560"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" fixed width="48" />
        <el-table-column fixed prop="id" label="序号" width="80" />
        <el-table-column fixed prop="entry_date" label="录入时间" width="170" />
        <el-table-column prop="project_name" label="项目" width="140" show-overflow-tooltip />
        <el-table-column prop="item_source" label="物品来源" width="140" show-overflow-tooltip />
        <el-table-column prop="receive_code" label="领用编码" width="140" show-overflow-tooltip />
        <el-table-column prop="item_name" label="物品名称" min-width="160" show-overflow-tooltip />
        <el-table-column prop="catlog_code" label="catlog编码" width="140" show-overflow-tooltip />
        <el-table-column prop="order_number" label="领料单号" width="140" show-overflow-tooltip />
        <el-table-column prop="unit_price" label="单价" width="100" />
        <el-table-column prop="quantity" label="数量" width="90" />
        <el-table-column label="使用状态" width="100">
          <template slot-scope="scope">
            <el-tag :type="usageStatusTagType(scope.row.usage_status)" size="small">
              {{ scope.row.usage_status || "未使用" }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="material_provider" label="物料提供人" width="120" show-overflow-tooltip />
        <el-table-column prop="material_storage_location" label="物料存放位置" width="160" show-overflow-tooltip />
        <el-table-column prop="material_recipient" label="物料领取人" width="120" show-overflow-tooltip />
        <el-table-column prop="remark" label="备注" width="160" show-overflow-tooltip />
        <el-table-column prop="entry_person" label="录入人" width="110" show-overflow-tooltip />
        <el-table-column prop="team" label="所属团队" width="120" show-overflow-tooltip />
        <el-table-column prop="engineer" label="工程师" width="110" show-overflow-tooltip />

        <el-table-column fixed="right" label="操作" width="220">
          <template slot-scope="scope">
            <div class="operation-buttons">
              <el-button size="mini" @click="handleView(scope.row)">
                查看
              </el-button>
              <el-button v-if="canEditMaterial(scope.row)" size="mini" @click="openEditDialog(scope.row)">
                编辑
              </el-button>
              <el-button v-if="canOutMaterial(scope.row)" size="mini" type="warning" @click="openOutDialog(scope.row)">
                出账
              </el-button>
              <el-button size="mini" @click="openRecordDialog(scope.row)">
                记录
              </el-button>
              <el-button size="mini" @click="exportSameItem(scope.row)">
                导出
              </el-button>
              <el-button
                v-if="isAdmin"
                size="mini"
                type="danger"
                @click="handleDelete(scope.row)"
              >
                删除
              </el-button>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class="pagination-bar">
        <el-pagination
          background
          layout="total, sizes, prev, pager, next, jumper"
          :current-page="pagination.page"
          :page-size="pagination.pageSize"
          :page-sizes="[10, 20, 50, 100]"
          :total="pagination.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </el-card>

    <el-dialog
      :title="dialogTitle"
      :visible.sync="formDialogVisible"
      width="760px"
      @close="resetMaterialForm"
    >
      <el-form
        ref="materialForm"
        :model="materialForm"
        :rules="materialRules"
        label-width="100px"
      >
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="物品来源" :prop="dialogMode === 'out' ? '' : 'item_source'">
              <el-select
                v-model="materialForm.item_source"
                :disabled="isReadOnlyField('item_source')"
                placeholder="请选择"
                style="width: 100%"
                @change="handleItemSourceChange"
              >
                <el-option
                  v-for="item in itemSourceOptions"
                  :key="item"
                  :label="item"
                  :value="item"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="项目" prop="project_name">
              <el-select
                v-model="materialForm.project_name"
                :disabled="isReadOnlyField('project_name')"
                filterable
                clearable
                placeholder="请选择项目"
                style="width: 100%"
                @change="handleMaterialProjectChange"
              >
                <el-option
                  v-for="item in activeProjectOptions"
                  :key="item.project_name"
                  :label="item.project_name"
                  :value="item.project_name"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <el-col v-if="showReceiveCode" :span="12">
            <el-form-item
              label="领用编码"
              :prop="dialogMode === 'out' ? '' : 'receive_code'"
              :class="{ 'is-required': isReceiveCodeRequired }"
            >
              <el-autocomplete
                v-model="materialForm.receive_code"
                :disabled="isReadOnlyField('receive_code')"
                :fetch-suggestions="queryReceiveCodeSuggestions"
                value-key="receive_code"
                placeholder="请输入领用编码"
                style="width: 100%"
                @input="handleReceiveCodeInput"
                @select="handleReceiveCodeSelect"
                @blur="fillItemNameByReceiveCode"
              />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="物品名称" :prop="dialogMode === 'out' ? '' : 'item_name'">
              <el-input
                v-model="materialForm.item_name"
                :disabled="isReadOnlyField('item_name') || isItemNameLocked"
              />
            </el-form-item>
          </el-col>

          <el-col v-if="showEbuyFields" :span="12">
            <el-form-item
              label="catlog编码"
              prop=""
            >
              <el-input
                v-model="materialForm.catlog_code"
                :disabled="isReadOnlyField('catlog_code')"
              />
            </el-form-item>
          </el-col>

          <el-col v-if="showEbuyFields" :span="12">
            <el-form-item
              label="领料单号"
              :prop="dialogMode === 'out' ? '' : 'order_number'"
              :class="{ 'is-required': isOrderNumberRequired }"
            >
              <el-input
                v-model="materialForm.order_number"
                :disabled="isReadOnlyField('order_number')"
              />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="单价" prop="unit_price" :class="{ 'is-required': isUnitPriceRequired }">
              <el-input-number
                v-model="materialForm.unit_price"
                :disabled="isReadOnlyField('unit_price')"
                :min="0"
                :precision="2"
                controls-position="right"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="数量" :prop="dialogMode === 'out' ? '' : 'quantity'">
              <el-input-number
                v-model="materialForm.quantity"
                :disabled="isReadOnlyField('quantity')"
                :min="0"
                controls-position="right"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode !== 'add'" :span="12">
            <el-form-item label="出账数量" :prop="dialogMode === 'out' ? 'out_number' : ''">
              <el-input-number
                v-model="materialForm.out_number"
                :disabled="dialogMode !== 'out'"
                :min="0"
                controls-position="right"
                style="width: 100%"
              />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="存放位置" :prop="dialogMode === 'out' ? '' : 'material_storage_location'">
              <el-select
                v-model="materialForm.material_storage_location"
                :disabled="isReadOnlyField('material_storage_location')"
                filterable
                allow-create
                clearable
                default-first-option
                placeholder="请选择或输入存放位置"
                style="width: 100%"
              >
                <el-option
                  v-for="item in projectAddressOptions"
                  :key="item.id || item.address"
                  :label="item.address"
                  :value="item.address"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <el-col v-if="showMaterialProvider" :span="12">
            <el-form-item label="物料提供人" :prop="dialogMode === 'out' ? '' : 'material_provider'">
              <el-input
                v-model="materialForm.material_provider"
                :disabled="isReadOnlyField('material_provider')"
              />
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode !== 'add'" :span="12">
            <el-form-item label="物料领取人" :prop="dialogMode === 'out' ? 'material_recipient' : 'material_recipient'">
              <el-input
                v-model="materialForm.material_recipient"
                :disabled="isReadOnlyField('material_recipient')"
              />
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode === 'out'" :span="12">
            <el-form-item label="样机名称" prop="prototype_name">
              <el-select
                v-model="materialForm.prototype_group_key"
                filterable
                placeholder="请选择当前项目样机"
                style="width:100%"
                @change="handlePrototypeGroupSelect"
              >
                <el-option
                  v-for="item in prototypeOptions"
                  :key="item.key"
                  :label="item.name"
                  :value="item.key"
                >
                  <span>{{ item.name }}</span>
                  <span class="prototype-option-code">{{ item.option_type === "container" ? "容器" : "单台样机" }}</span>
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode === 'out'" :span="12">
            <el-form-item label="样机编号" prop="prototype_code">
              <el-select
                v-if="materialForm.prototype_option_type === 'container'"
                v-model="materialForm.prototype_identity_code"
                filterable
                placeholder="请选择样机编号"
                style="width:100%"
                :disabled="!materialForm.prototype_group_key"
                @change="handlePrototypeChildSelect"
              >
                <el-option
                  v-for="item in prototypeChildOptions"
                  :key="item.identity_code"
                  :label="item.item_name"
                  :value="item.identity_code"
                />
              </el-select>
              <el-input
                v-else
                v-model="materialForm.prototype_code"
                disabled
                placeholder="选择单台样机后自动带入"
              />
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode !== 'add'" :span="12">
            <el-form-item label="录入人">
              <el-input
                v-model="materialForm.entry_person"
                :disabled="isReadOnlyField('entry_person')"
              />
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode !== 'add'" :span="12">
            <el-form-item label="所属团队">
              <el-select
                v-model="materialForm.team"
                :disabled="isReadOnlyField('team')"
                filterable
                allow-create
                clearable
                default-first-option
                style="width: 100%"
                @change="fillEngineerByTeam"
              >
                <el-option
                  v-for="team in teamOptions"
                  :key="team"
                  :label="team"
                  :value="team"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode !== 'add'" :span="12">
            <el-form-item label="工程师">
              <el-autocomplete
                v-model="materialForm.engineer"
                :disabled="isReadOnlyField('engineer')"
                :fetch-suggestions="queryEngineerSuggestions"
                placeholder="请输入工程师工号或姓名"
                style="width: 100%"
                @input="handleEngineerInput"
                @select="handleEngineerSelect"
              />
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode !== 'add'" :span="24">
            <el-form-item label="用途" :prop="dialogMode === 'out' ? 'use' : ''">
              <el-select
                v-model="materialForm.use"
                :disabled="dialogMode !== 'out'"
                clearable
                placeholder="请选择用途"
                style="width: 100%"
              >
                <el-option
                  v-for="item in useOptions"
                  :key="item"
                  :label="item"
                  :value="item"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <el-col v-if="dialogMode === 'out' && materialForm.use === '退回研发'" :span="24">
            <el-form-item label="携物出门单号" prop="carry_out_number">
              <el-input
                v-model="materialForm.carry_out_number"
                placeholder="请输入携物出门单号"
              />
            </el-form-item>
          </el-col>

          <el-col :span="24">
            <el-form-item label="备注" :prop="dialogMode === 'out' ? 'remark' : ''">
              <el-input
                v-model="materialForm.remark"
                :disabled="isReadOnlyField('remark')"
                type="textarea"
                :rows="3"
              />
            </el-form-item>
          </el-col>

          <el-col :span="24">
            <el-form-item label="图片" :required="isImageRequired">
              <el-upload
                action="#"
                :auto-upload="false"
                :file-list="fileList"
                accept=".png,.jpg,.jpeg,.gif,.webp,.bmp"
                :disabled="dialogMode !== 'out' && dialogMode === 'edit' && !isAdmin"
                :on-change="handleImageChange"
                :on-remove="handleImageRemove"
              >
                <el-button
                  size="small"
                  :disabled="dialogMode !== 'out' && dialogMode === 'edit' && !isAdmin"
                >
                  选择图片
                </el-button>
              </el-upload>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <span slot="footer">
        <el-button @click="formDialogVisible = false">
          取消
        </el-button>
        <el-button type="primary" @click="submitMaterialForm">
          {{ dialogMode === "edit" ? "保存" : "提交" }}
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="批量出账申请"
      :visible.sync="batchOutDialogVisible"
      width="980px"
      @close="resetBatchOutDialog"
    >
      <el-form label-width="110px" size="small">
        <el-row :gutter="16">
          <el-col :span="12">
            <el-form-item label="项目" required>
              <el-select
                v-model="batchOutForm.project_name"
                filterable
                placeholder="请选择项目"
                style="width:100%"
                @change="handleBatchOutProjectChange"
              >
                <el-option
                  v-for="item in activeProjectOptions"
                  :key="item.id || item.project_name"
                  :label="item.project_name"
                  :value="item.project_name"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="审批工程师" required>
              <el-autocomplete
                v-model="batchOutForm.engineer"
                :fetch-suggestions="queryEngineerSuggestions"
                placeholder="请输入工程师工号或姓名"
                style="width:100%"
                @select="handleBatchOutEngineerSelect"
              />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="样机名称" required>
              <el-select
                v-model="batchOutForm.prototype_group_key"
                filterable
                placeholder="请选择当前项目样机"
                style="width:100%"
                @change="handleBatchPrototypeGroupSelect"
              >
                <el-option
                  v-for="item in prototypeOptions"
                  :key="item.key"
                  :label="item.name"
                  :value="item.key"
                >
                  <span>{{ item.name }}</span>
                  <span class="prototype-option-code">{{ item.option_type === "container" ? "容器" : "单台样机" }}</span>
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="样机编号" required>
              <el-select
                v-if="batchOutForm.prototype_option_type === 'container'"
                v-model="batchOutForm.prototype_identity_code"
                filterable
                placeholder="请选择样机编号"
                style="width:100%"
                :disabled="!batchOutForm.prototype_group_key"
                @change="handleBatchPrototypeChildSelect"
              >
                <el-option
                  v-for="item in prototypeChildOptions"
                  :key="item.identity_code"
                  :label="item.item_name"
                  :value="item.identity_code"
                />
              </el-select>
              <el-input
                v-else
                v-model="batchOutForm.prototype_code"
                disabled
                placeholder="选择单台样机后自动带入"
              />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="物料领取人" required>
              <el-input v-model.trim="batchOutForm.material_recipient" />
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="用途" required>
              <el-select
                v-model="batchOutForm.use"
                clearable
                placeholder="请选择用途"
                style="width:100%"
              >
                <el-option
                  v-for="item in useOptions"
                  :key="item"
                  :label="item"
                  :value="item"
                />
              </el-select>
            </el-form-item>
          </el-col>

          <el-col v-if="batchOutForm.use === '退回研发'" :span="24">
            <el-form-item label="携物出门单号" required>
              <el-input v-model.trim="batchOutForm.carry_out_number" />
            </el-form-item>
          </el-col>

          <el-col :span="24">
            <el-form-item label="备注">
              <el-input v-model.trim="batchOutForm.remark" type="textarea" :rows="2" />
            </el-form-item>
          </el-col>

          <el-col :span="24">
            <el-form-item label="图片">
              <el-upload
                action="#"
                :auto-upload="false"
                :file-list="batchOutFileList"
                accept=".png,.jpg,.jpeg,.gif,.webp,.bmp"
                :on-change="handleBatchOutImageChange"
                :on-remove="handleBatchOutImageRemove"
              >
                <el-button size="small">
                  选择图片
                </el-button>
              </el-upload>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <el-table
        ref="batchOutTable"
        v-loading="batchOutLoading"
        :data="batchOutRows"
        border
        height="260"
        :row-key="getBatchOutRowKey"
        style="width:100%"
        @selection-change="handleBatchOutSelectionChange"
      >
        <el-table-column type="selection" width="48" :selectable="isBatchOutRowSelectable" />
        <el-table-column label="物品名称" min-width="210" show-overflow-tooltip>
          <template slot-scope="scope">
            <el-select
              v-model="scope.row.selected_material_id"
              filterable
              size="mini"
              style="width:100%"
              @change="handleBatchOutMaterialSelect(scope.$index, $event)"
            >
              <el-option
                v-for="item in batchOutMaterialOptions(scope.row)"
                :key="item.id"
                :label="batchOutMaterialOptionLabel(item)"
                :value="item.id"
                :disabled="!isBatchOutRowSelectable(item)"
              />
            </el-select>
          </template>
        </el-table-column>
        <el-table-column prop="receive_code" label="领用编码" width="130" show-overflow-tooltip />
        <el-table-column prop="quantity" label="当前数量" width="100" />
        <el-table-column prop="pending_out" label="待出账数" width="100" />
        <el-table-column prop="available_quantity" label="可出账数" width="100" />
        <el-table-column label="出账数量" width="150">
          <template slot-scope="scope">
            <el-input-number
              v-model="scope.row.out_number"
              :min="0"
              :max="Number(scope.row.available_quantity || 0)"
              controls-position="right"
              style="width:120px"
            />
          </template>
        </el-table-column>
      </el-table>

      <span slot="footer">
        <el-button @click="batchOutDialogVisible = false">
          取消
        </el-button>
        <el-button type="primary" :loading="batchOutLoading" @click="submitBatchOutRequest">
          提交
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="物品图片"
      :visible.sync="imageDialogVisible"
      width="620px"
    >
      <div class="image-box">
        <img
          v-if="currentImageUrl"
          :src="currentImageUrl"
          class="material-image"
          alt="物品图片"
        >
        <el-empty v-else description="当前物品暂无图片" />
      </div>
    </el-dialog>

    <el-dialog
      title="入账/出账记录"
      :visible.sync="recordDialogVisible"
      width="62%"
      top="6vh"
    >
      <div class="record-title">
        {{ recordItemName }}
      </div>

      <div class="record-chart">
        <div
          v-for="item in chartItems"
          :key="item.label"
          class="chart-row"
        >
          <div class="chart-label">
            {{ item.label }}
          </div>
          <div class="chart-track">
            <div
              class="chart-bar"
              :class="item.className"
              :style="{ width: item.width }"
            />
          </div>
          <div class="chart-value">
            {{ item.value }}
          </div>
        </div>
      </div>

      <el-table
        v-loading="recordLoading"
        :data="recordRows"
        border
        max-height="260"
        style="width: 100%"
      >
        <el-table-column prop="date" label="日期" width="170" />
        <el-table-column prop="type" label="类型" width="90">
          <template slot-scope="scope">
            <el-tag :type="scope.row.type === '出账' ? 'warning' : 'success'">
              {{ scope.row.type }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="projectName" label="项目" width="110" show-overflow-tooltip />
        <el-table-column prop="prototypeName" label="绑定样机名称" width="140" show-overflow-tooltip />
        <el-table-column prop="quantity" label="数量" width="90" />
        <el-table-column prop="approvalStatus" label="审批状态" width="110" />
        <el-table-column prop="approvedAt" label="审批时间" width="170" />
        <el-table-column prop="approver" label="审批人" width="120" />
        <el-table-column prop="operator" label="操作人" width="120" />
        <el-table-column prop="materialRecipient" label="物料领取人" min-width="140" show-overflow-tooltip />
      </el-table>
    </el-dialog>

    <el-dialog
      title="批量修改录入人"
      :visible.sync="batchDialogVisible"
      width="380px"
      @close="batchEntryPerson = ''"
    >
      <el-form label-width="80px">
        <el-form-item label="录入人">
          <el-input v-model="batchEntryPerson" />
        </el-form-item>
      </el-form>
      <span slot="footer">
        <el-button @click="batchDialogVisible = false">
          取消
        </el-button>
        <el-button type="primary" @click="submitBatchEdit">
          保存
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="物料报废"
      :visible.sync="scrapDialogVisible"
      width="900px"
      @close="resetScrapDialog"
    >
      <el-upload
        drag
        action="#"
        :auto-upload="false"
        :limit="1"
        accept="image/*"
        :file-list="scrapProofFileList"
        :on-change="handleScrapProofChange"
        :on-exceed="handleScrapProofExceed"
        :on-remove="handleScrapProofRemove"
        class="proof-upload"
      >
        <i class="el-icon-upload" />
        <div class="el-upload__text">
          将评审证明拖到此处，或<em>点击上传</em>
        </div>
      </el-upload>

      <el-table
        ref="scrapTable"
        v-loading="disposalLoading"
        :data="disposalRows"
        border
        height="320"
        style="width: 100%; margin-top: 16px"
        @selection-change="handleDisposalSelectionChange"
      >
        <el-table-column type="selection" width="48" />
        <el-table-column prop="projectName" label="当前项目" min-width="140" show-overflow-tooltip />
        <el-table-column label="物品编码" width="140" show-overflow-tooltip>
          <template slot-scope="scope">
            {{ materialCodeText(scope.row) }}
          </template>
        </el-table-column>
        <el-table-column prop="itemName" label="物品名称" min-width="160" show-overflow-tooltip />
        <el-table-column prop="totalQuantity" label="总数量" width="110" />
        <el-table-column prop="availableQuantity" label="可报废数量" width="120" />
      </el-table>

      <span slot="footer">
        <el-button @click="scrapDialogVisible = false">
          关闭
        </el-button>
        <el-button type="primary" :loading="disposalLoading" @click="submitScrap">
          提交
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="物料销账"
      :visible.sync="writeoffDialogVisible"
      width="900px"
      @close="resetDisposalDialog"
    >
      <el-steps :active="0" simple class="writeoff-steps">
        <el-step title="工程师" />
        <el-step title="子项目经理" />
        <el-step title="实验室主任" />
      </el-steps>

      <el-table
        ref="writeoffTable"
        v-loading="disposalLoading"
        :data="disposalRows"
        border
        height="320"
        style="width: 100%; margin-top: 16px"
        @selection-change="handleDisposalSelectionChange"
      >
        <el-table-column type="selection" width="48" />
        <el-table-column prop="projectName" label="当前项目" min-width="140" show-overflow-tooltip />
        <el-table-column label="物品编码" width="140" show-overflow-tooltip>
          <template slot-scope="scope">
            {{ materialCodeText(scope.row) }}
          </template>
        </el-table-column>
        <el-table-column prop="itemName" label="物品名称" min-width="160" show-overflow-tooltip />
        <el-table-column prop="totalQuantity" label="总数量" width="110" />
        <el-table-column prop="availableQuantity" label="可报废数量" width="120" />
      </el-table>

      <span slot="footer">
        <el-button @click="writeoffDialogVisible = false">
          关闭
        </el-button>
        <el-button type="primary" :loading="disposalLoading" @click="submitWriteoff">
          提交
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="物料转移"
      :visible.sync="materialTransferDialogVisible"
      width="920px"
      @close="resetMaterialTransferDialog"
    >
      <el-form :inline="true" :model="materialTransferForm" size="small">
        <el-form-item label="转入项目" required>
          <el-select
            v-model="materialTransferForm.newProjectName"
            filterable
            clearable
            placeholder="请选择转入项目"
            style="width: 260px"
          >
            <el-option
              v-for="project in activeProjectOptions"
              :key="project.project_name"
              :label="projectOptionLabel(project)"
              :value="project.project_name"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="转入责任人" required>
          <el-select
            v-model="materialTransferForm.newResponsible"
            filterable
            clearable
            placeholder="请选择转入责任人"
            style="width: 220px"
          >
            <el-option
              v-for="item in responsibleOptions"
              :key="item.username"
              :label="responsibleOptionLabel(item)"
              :value="item.username"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model.trim="materialTransferForm.remark" clearable placeholder="可选" style="width: 260px" />
        </el-form-item>
      </el-form>

      <el-table
        ref="materialTransferTable"
        v-loading="materialTransferLoading"
        :data="materialTransferRows"
        border
        height="320"
        style="width: 100%; margin-top: 12px"
        @selection-change="handleMaterialTransferSelectionChange"
      >
        <el-table-column type="selection" width="48" />
        <el-table-column prop="project_name" label="当前项目" min-width="140" show-overflow-tooltip />
        <el-table-column prop="receive_code" label="领用编码" width="140" show-overflow-tooltip />
        <el-table-column prop="item_name" label="物品名称" min-width="160" show-overflow-tooltip />
        <el-table-column prop="quantity" label="可转移数量" width="110" />
        <el-table-column prop="material_storage_location" label="存放位置" min-width="150" show-overflow-tooltip />
        <el-table-column prop="entry_person" label="录入人" width="110" />
      </el-table>

      <span slot="footer">
        <el-button @click="materialTransferDialogVisible = false">
          关闭
        </el-button>
        <el-button type="primary" :loading="materialTransferLoading" @click="submitMaterialTransfer">
          提交
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="数据汇总"
      :visible.sync="summaryDialogVisible"
      width="960px"
    >
      <div class="summary-chart">
        <div
          v-for="item in summaryChartItems"
          :key="item.label"
          class="chart-row"
        >
          <div class="chart-label">
            {{ item.label }}
          </div>
          <div class="chart-track">
            <div
              class="chart-bar"
              :class="item.className"
              :style="{ width: item.width }"
            />
          </div>
          <div class="chart-value">
            {{ item.value }}
          </div>
        </div>
      </div>

      <el-table
        v-loading="summaryLoading"
        :data="summaryRows"
        border
        height="360"
        style="width: 100%"
      >
        <el-table-column prop="entryPerson" label="录入人" width="120" show-overflow-tooltip />
        <el-table-column prop="team" label="所属团队" width="140" show-overflow-tooltip />
        <el-table-column prop="engineer" label="工程师" width="120" show-overflow-tooltip />
        <el-table-column prop="itemName" label="物品名称" min-width="180" show-overflow-tooltip />
        <el-table-column prop="receive" label="入账数" width="120" />
        <el-table-column prop="out" label="出账数" width="120" />
        <el-table-column prop="remain" label="剩余数" width="120" />
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
import axios from "axios"
import { API_BASE } from "../../config/appConfig"
import { isSameData } from "../../utils/dataChange"

const emptySearchForm = () => ({
  date: [],
  itemSource: "",
  receiveCode: "",
  catlogCode: "",
  orderNumber: "",
  itemName: "",
  storageLocation: "",
  materialProvider: "",
  materialRecipient: "",
  entryPerson: "",
  minPrice: undefined,
  maxPrice: undefined
})

const emptyMaterialForm = () => ({
  id: "",
  item_source: "ebuy途径购买",
  project_name: "",
  receive_code: "",
  item_name: "",
  catlog_code: "",
  order_number: "",
  unit_price: undefined,
  quantity: 1,
  out_number: 0,
  pending_out: 0,
  available_quantity: 0,
  material_storage_location: "",
  material_provider: "",
  material_recipient: "",
  entry_person: "",
  remark: "",
  credit: "",
  gz_xz: "",
  use: "",
  prototype_name: "",
  prototype_code: "",
  prototype_identity_code: "",
  prototype_group_key: "",
  prototype_option_type: "",
  carry_out_number: "",
  team: "",
  engineer: ""
})

const emptyBatchOutForm = () => ({
  project_name: "",
  prototype_name: "",
  prototype_code: "",
  prototype_identity_code: "",
  prototype_group_key: "",
  prototype_option_type: "",
  material_recipient: "",
  engineer: "",
  use: "",
  carry_out_number: "",
  remark: ""
})

const emptyMaterialTransferForm = () => ({
  newProjectName: "",
  newResponsible: "",
  remark: ""
})

export default {
  name: "MaterialManage",

  data() {
    return {
      loading: false,
      tableData: [],
      selectedRows: [],
      user: {},
      searchForm: emptySearchForm(),
      pagination: {
        page: 1,
        pageSize: 20,
        total: 0
      },
      itemSourceOptions: [
        "ebuy途径购买",
        "自行采购",
        "研发免费样品"
      ],
      useOptions: [
        "样机制作",
        "样机损耗",
        "退回研发"
      ],
      teamOptions: [
        "星际光",
        "成像光",
        "空间光",
        "光电封装"
      ],
      teamEngineerMap: {},
      engineerOptions: [],
      responsibleOptions: [],
      projectOptions: [],
      projectAddressOptions: [],
      prototypeOptions: [],
      prototypeChildOptions: [],
      receiveCodeMatched: false,
      engineerAutoFillTimer: null,
      lastEngineerInputValue: "",
      formDialogVisible: false,
      imageDialogVisible: false,
      recordDialogVisible: false,
      batchDialogVisible: false,
      batchOutDialogVisible: false,
      summaryDialogVisible: false,
      scrapDialogVisible: false,
      writeoffDialogVisible: false,
      materialTransferDialogVisible: false,
      dialogMode: "add",
      materialForm: emptyMaterialForm(),
      batchOutForm: emptyBatchOutForm(),
      materialTransferForm: emptyMaterialTransferForm(),
      materialTransferRows: [],
      selectedMaterialTransferRows: [],
      materialTransferLoading: false,
      batchOutRows: [],
      selectedBatchOutRows: [],
      batchOutOptionsByReceiveCode: {},
      batchOutLoading: false,
      batchOutFileList: [],
      batchOutImageFile: null,
      fileList: [],
      selectedImageFile: null,
      scrapProofFileList: [],
      scrapProofFile: null,
      disposalLoading: false,
      disposalRows: [],
      selectedDisposalRows: [],
      currentImageUrl: "",
      recordLoading: false,
      recordItemName: "",
      recordRows: [],
      recordSummary: {
        receive: 0,
        out: 0,
        pending: 0,
        remain: 0
      },
      summaryLoading: false,
      summaryRows: [],
      summaryTotals: {
        receive: 0,
        out: 0,
        remain: 0
      },
      batchEntryPerson: "",
      refreshTimer: null,
      materialRules: {
        item_source: [
          { required: true, message: "请选择物品来源", trigger: "change" }
        ],
        project_name: [
          { required: true, message: "请选择项目", trigger: "change" }
        ],
        receive_code: [
          { validator: this.validateReceiveCode, trigger: "blur" }
        ],
        item_name: [
          { required: true, message: "请输入物品名称", trigger: "blur" }
        ],
        order_number: [
          { validator: this.validateEbuyField, trigger: "blur" }
        ],
        unit_price: [
          { validator: this.validateUnitPrice, trigger: "change" },
          { validator: this.validateUnitPrice, trigger: "blur" }
        ],
        quantity: [
          { required: true, message: "请输入数量", trigger: "change" },
          { validator: this.validateNonNegativeNumber, trigger: "change" }
        ],
        out_number: [
          { required: true, message: "请输入出账数量", trigger: "change" }
        ],
        prototype_name: [
          { required: true, message: "请输入样机名称", trigger: "blur" }
        ],
        prototype_code: [
          { required: true, message: "请输入样机编号", trigger: "blur" }
        ],
        material_storage_location: [
          { required: true, message: "请输入存放位置", trigger: "blur" }
        ],
        material_provider: [
          { required: true, message: "请输入物料提供人", trigger: "blur" }
        ],
        material_recipient: [
          { required: true, message: "请输入物料领取人", trigger: "blur" }
        ],
        carry_out_number: [
          { required: true, message: "请输入携物出门单号", trigger: "blur" }
        ],
        use: [
          { required: true, message: "请选择用途", trigger: "change" }
        ],
        remark: []
      },
      pickerOptions: {
        shortcuts: [
          {
            text: "最近一周",
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit("pick", [start, end])
            }
          },
          {
            text: "最近一个月",
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit("pick", [start, end])
            }
          },
          {
            text: "最近三个月",
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit("pick", [start, end])
            }
          }
        ]
      }
    }
  },

  computed: {
    activeProjectOptions() {
      return this.projectOptions.filter(item => item.status !== "结项")
    },
    isAdmin() {
      return Number(this.user.permissions) === 1
    },

    isSuperAdmin() {
      return Number(this.user.permissions) === 1
    },

    canUseMaterial() {
      return Number(this.user.permissions) === 0 && this.user.category === "技师"
    },

    isEngineerUser() {
      return Number(this.user.permissions) === 0 && this.user.category === "工程师"
    },

    showReceiveCode() {
      return this.dialogMode !== "add" || ["ebuy途径购买", "自行采购"].includes(this.materialForm.item_source)
    },

    showEbuyFields() {
      return this.dialogMode !== "add" || ["ebuy途径购买", "自行采购"].includes(this.materialForm.item_source)
    },

    showMaterialProvider() {
      return this.dialogMode !== "add" || !["ebuy途径购买", "自行采购"].includes(this.materialForm.item_source)
    },

    isImageRequired() {
      return false
    },

    isUnitPriceRequired() {
      return this.dialogMode !== "out" && ["ebuy途径购买", "自行采购"].includes(this.materialForm.item_source)
    },

    isOrderNumberRequired() {
      return this.dialogMode === "add" && ["ebuy途径购买", "自行采购"].includes(this.materialForm.item_source)
    },

    isReceiveCodeRequired() {
      return this.dialogMode === "add" && ["ebuy途径购买", "自行采购"].includes(this.materialForm.item_source)
    },

    isItemNameLocked() {
      return this.dialogMode === "add" && this.showReceiveCode
    },

    isDashboardView() {
      return this.$route.path === "/dashboard"
    },

    dialogTitle() {
      if (this.dialogMode === "add") {
        return "入账"
      }

      if (this.dialogMode === "out") {
        return "出账申请"
      }

      return "编辑物料"
    },

    chartItems() {
      const maxValue = Math.max(
        Number(this.recordSummary.receive) || 0,
        Number(this.recordSummary.out) || 0,
        Number(this.recordSummary.pending) || 0,
        Number(this.recordSummary.remain) || 0,
        1
      )

      return [
        {
          label: "入账数",
          value: this.recordSummary.receive,
          width: this.recordSummary.receive > 0 ? `${Math.max((this.recordSummary.receive / maxValue) * 100, 4)}%` : "0%",
          className: "receive"
        },
        {
          label: "出账数",
          value: this.recordSummary.out,
          width: this.recordSummary.out > 0 ? `${Math.max((this.recordSummary.out / maxValue) * 100, 4)}%` : "0%",
          className: "out"
        },
        {
          label: "待出账数",
          value: this.recordSummary.pending,
          width: this.recordSummary.pending > 0 ? `${Math.max((this.recordSummary.pending / maxValue) * 100, 4)}%` : "0%",
          className: "pending"
        },
        {
          label: "剩余数",
          value: this.recordSummary.remain,
          width: this.recordSummary.remain > 0 ? `${Math.max((this.recordSummary.remain / maxValue) * 100, 4)}%` : "0%",
          className: "remain"
        }
      ]
    },

    summaryChartItems() {
      const maxValue = Math.max(
        Number(this.summaryTotals.receive) || 0,
        Number(this.summaryTotals.out) || 0,
        Number(this.summaryTotals.remain) || 0,
        1
      )

      return [
        {
          label: "入账总数",
          value: this.summaryTotals.receive,
          width: `${Math.max((this.summaryTotals.receive / maxValue) * 100, 4)}%`,
          className: "receive"
        },
        {
          label: "出账总数",
          value: this.summaryTotals.out,
          width: `${Math.max((this.summaryTotals.out / maxValue) * 100, 4)}%`,
          className: "out"
        },
        {
          label: "剩余总数",
          value: this.summaryTotals.remain,
          width: `${Math.max((this.summaryTotals.remain / maxValue) * 100, 4)}%`,
          className: "remain"
        }
      ]
    }
  },

  watch: {
    "$route.path"() {
      this.pagination.page = 1
      this.fetchMaterialData()
    }
  },

  created() {
    const user = localStorage.getItem("user")

    if (user) {
      this.user = JSON.parse(user)
    }

    this.searchForm = this.defaultSearchForm()
  },

  mounted() {
    this.fetchTeamOptions()
    this.fetchEngineerOptions()
    this.fetchResponsibleOptions()
    this.fetchProjectOptions()
    this.fetchMaterialData()
    this.refreshTimer = setInterval(() => this.fetchMaterialData(true), 15000)
  },

  beforeDestroy() {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer)
    }
    if (this.engineerAutoFillTimer) {
      clearTimeout(this.engineerAutoFillTimer)
    }
  },

  methods: {
    defaultSearchForm() {
      const form = emptySearchForm()
      if (!this.isAdmin && this.user.username) {
        form.entryPerson = this.user.username
      }
      return form
    },

    cleanSearchForm() {
      const cleaned = {}

      Object.keys(this.searchForm).forEach(key => {
        const value = this.searchForm[key]

        if (typeof value === "string") {
          cleaned[key] = value.trim()
          return
        }

        if (Array.isArray(value)) {
          cleaned[key] = value.map(item => typeof item === "string" ? item.trim() : item)
          return
        }

        cleaned[key] = value
      })

      return cleaned
    },

    fetchTeamOptions() {
      axios.get(`${API_BASE}/user/team_engineers`).then(res => {
        if (res.data.code === 200) {
          this.teamOptions = ["星际光", "成像光", "空间光", "光电封装"]
          this.teamEngineerMap = res.data.data.teamEngineers || {}
        }
      }).catch(() => {})
    },

    fetchEngineerOptions() {
      axios.get(`${API_BASE}/user/engineers`).then(res => {
        if (res.data.code === 200) {
          this.engineerOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    fetchResponsibleOptions() {
      axios.get(`${API_BASE}/user/responsibles`).then(res => {
        if (res.data.code === 200) {
          this.responsibleOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    fetchProjectOptions() {
      axios.get(`${API_BASE}/project/list`).then(res => {
        if (res.data.code === 200) {
          this.projectOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    fetchProjectAddressOptions(projectName) {
      this.projectAddressOptions = []
      if (!projectName) {
        return
      }
      axios.get(`${API_BASE}/project_address/list`, {
        params: { projectName }
      }).then(res => {
        if (res.data.code === 200) {
          this.projectAddressOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    ensureProjectAddress(projectName, address) {
      const nextProject = String(projectName || "").trim()
      const nextAddress = String(address || "").trim()
      if (!nextProject || !nextAddress) {
        return Promise.resolve()
      }

      const existed = this.projectAddressOptions.some(item => item.address === nextAddress)
      if (existed) {
        return Promise.resolve()
      }

      return axios.post(`${API_BASE}/project_address/save`, {
        projectName: nextProject,
        address: nextAddress
      }).then(res => {
        if (res.data.code !== 200 && !String(res.data.msg || "").includes("已存在")) {
          return Promise.reject(new Error(res.data.msg || "地址保存失败"))
        }
        this.fetchProjectAddressOptions(nextProject)
      })
    },

    fetchPrototypeOptions(projectName) {
      if (!projectName) {
        this.prototypeOptions = []
        return
      }
      axios.get(`${API_BASE}/prototype/project_options`, {
        params: { projectName }
      }).then(res => {
        if (res.data.code === 200) {
          this.prototypeOptions = res.data.data || []
        }
      }).catch(() => {})
    },

    handleOutProjectChange(projectName) {
      if (this.dialogMode !== "out") return
      this.materialForm.prototype_group_key = ""
      this.materialForm.prototype_name = ""
      this.materialForm.prototype_code = ""
      this.materialForm.prototype_identity_code = ""
      this.materialForm.prototype_option_type = ""
      this.prototypeChildOptions = []
      this.fetchPrototypeOptions(projectName)
    },

    handleMaterialProjectChange(projectName) {
      this.fetchProjectAddressOptions(projectName)
      if (this.dialogMode === "out") {
        this.handleOutProjectChange(projectName)
      }
    },

    handlePrototypeGroupSelect(optionKey) {
      const option = this.prototypeOptions.find(item => item.key === optionKey)
      this.materialForm.prototype_name = option ? option.name : ""
      this.materialForm.prototype_code = ""
      this.materialForm.prototype_identity_code = ""
      this.materialForm.prototype_option_type = option ? option.option_type : ""
      this.prototypeChildOptions = []
      if (!option) return
      if (option.option_type === "prototype") {
        this.materialForm.prototype_code = option.key
        this.materialForm.prototype_identity_code = option.key
        return
      }
      axios.get(`${API_BASE}/prototype/project_option_children`, {
        params: {
          projectName: this.materialForm.project_name,
          optionType: option.option_type,
          optionKey: option.key
        }
      }).then(res => {
        if (res.data.code !== 200) return
        this.prototypeChildOptions = res.data.data || []
      }).catch(() => {})
    },

    handlePrototypeChildSelect(identityCode) {
      const prototype = this.prototypeChildOptions.find(item => item.identity_code === identityCode)
      this.materialForm.prototype_code = prototype ? prototype.item_name : ""
    },

    fetchMaterialData(silent = false) {
      silent = silent === true
      if (!silent) {
        this.loading = true
      }
      const searchPayload = this.cleanSearchForm()

      axios.post(`${API_BASE}/material/list`, {
        ...searchPayload,
        teamScope: this.isDashboardView ? "all" : "mine",
        scopeTeam: this.user.team,
        userScope: this.isDashboardView ? "all" : "mine",
        scopeUser: this.user.username,
        page: this.pagination.page,
        pageSize: this.pagination.pageSize
      }).then(res => {
        if (res.data.code === 200) {
          const nextData = res.data.data || []
          const nextTotal = Number(res.data.total || 0)
          if (!isSameData(this.tableData, nextData) || this.pagination.total !== nextTotal) {
            this.tableData = nextData
            this.pagination.total = nextTotal
          }
        } else if (!silent) {
          this.$message.error(res.data.msg || "获取数据失败")
        }
      }).catch(err => {
        console.log(err)
        if (!silent) {
          this.$message.error("网络请求失败，请检查后端是否启动")
        }
      }).finally(() => {
        if (!silent) {
          this.loading = false
        }
      })
    },

    handleSearch() {
      this.searchForm = Object.assign({}, this.searchForm, this.cleanSearchForm())
      this.pagination.page = 1
      this.fetchMaterialData()
    },

    handleReset() {
      this.searchForm = this.defaultSearchForm()
      this.pagination.page = 1
      this.fetchMaterialData()
    },

    handleSizeChange(size) {
      this.pagination.pageSize = size
      this.pagination.page = 1
      this.fetchMaterialData()
    },

    handleCurrentChange(page) {
      this.pagination.page = page
      this.fetchMaterialData()
    },

    handleSelectionChange(rows) {
      this.selectedRows = rows
    },

    openAddDialog() {
      this.dialogMode = "add"
      this.receiveCodeMatched = false
      this.materialForm = Object.assign(emptyMaterialForm(), {
        team: this.user.team || "",
        engineer: this.user.engineer || "",
        entry_person: this.user.username || "",
        material_provider: this.user.username || "",
        material_recipient: this.user.username || ""
      })
      this.projectAddressOptions = []
      this.formDialogVisible = true
    },

    openEditDialog(row) {
      if (!this.canEditMaterial(row)) {
        this.$message.warning("只有录入人本人可以编辑该物料")
        return
      }

      this.dialogMode = "edit"
      this.receiveCodeMatched = false
      this.materialForm = Object.assign(emptyMaterialForm(), row, {
        unit_price: row.unit_price === null ? undefined : Number(row.unit_price),
        quantity: row.quantity === null ? 1 : Number(row.quantity),
        out_number: 0
      })
      this.fetchProjectAddressOptions(this.materialForm.project_name)
      this.formDialogVisible = true
    },

    openOutDialog(row) {
      if (!this.canOutMaterial(row)) {
        this.$message.warning("只能出自己的账")
        return
      }

      axios.get(`${API_BASE}/material/out_capacity/${row.id}`, {
        params: {
          submitter: this.user.username
        }
      }).then(res => {
        if (res.data.code !== 200) {
          this.$message.error(res.data.msg || "获取物品总量失败")
          return
        }

        const capacity = res.data.data
        const totalQuantity = Number(capacity.total_quantity || 0)
        const availableQuantity = Number(capacity.available_quantity || 0)

        if (availableQuantity <= 0) {
          this.$message.warning("当前可出账数量为0，不能出账")
          return
        }

        this.dialogMode = "out"
        this.receiveCodeMatched = false
        this.materialForm = Object.assign(emptyMaterialForm(), row, {
          unit_price: row.unit_price === null ? undefined : Number(row.unit_price),
          quantity: totalQuantity,
          pending_out: Number(capacity.pending_out || 0),
          available_quantity: availableQuantity,
          out_number: 0,
          engineer: this.formatEngineerValue(row.engineer)
        })
        this.prototypeOptions = []
        this.prototypeChildOptions = []
        this.fetchProjectAddressOptions(this.materialForm.project_name)
        this.fetchPrototypeOptions(this.materialForm.project_name)
        this.formDialogVisible = true
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    openBatchOutDialog() {
      const usingSelection = this.selectedRows.length > 0
      const sourcePromise = usingSelection
        ? Promise.resolve(this.selectedRows)
        : this.fetchAllMaterialRowsForCurrentSearch()

      this.batchOutLoading = true
      sourcePromise.then(sourceRows => {
        const availableRows = sourceRows.filter(row => this.canOutMaterial(row))
        if (usingSelection && availableRows.length !== sourceRows.length) {
          this.$message.warning("已自动跳过不能出账或数量为0的物料")
        }
        if (!availableRows.length) {
          this.$message.warning(usingSelection ? "所选物料不能出账" : "当前搜索结果没有可出账物料")
          return Promise.reject(new Error("__handled__"))
        }

        const firstRow = availableRows[0] || {}
        this.batchOutDialogVisible = true
        this.batchOutForm = Object.assign(emptyBatchOutForm(), {
          project_name: firstRow.project_name || "",
          material_recipient: this.user.username || "",
          engineer: this.formatEngineerValue(firstRow.engineer)
        })
        this.batchOutRows = []
        this.selectedBatchOutRows = []
        this.batchOutOptionsByReceiveCode = {}
        this.batchOutFileList = []
        this.batchOutImageFile = null
        this.prototypeOptions = []
        this.prototypeChildOptions = []

        if (this.batchOutForm.project_name) {
          this.fetchPrototypeOptions(this.batchOutForm.project_name)
        }

        return Promise.all([
          this.buildBatchOutRowsWithCapacity(availableRows),
          this.fetchBatchOutOptionRows(availableRows).then(rows => this.buildBatchOutRowsWithCapacity(rows))
        ])
      }).then(([rows, optionRows]) => {
        if (!rows.some(row => this.isBatchOutRowSelectable(row))) {
          this.$message.warning("当前没有可出账数量大于0的物料")
          return Promise.reject(new Error("__handled__"))
        }
        this.batchOutOptionsByReceiveCode = this.groupBatchOutOptionsByReceiveCode(optionRows)
        this.batchOutRows = usingSelection ? rows : this.pickDefaultBatchOutRowsByReceiveCode(rows)
        this.$nextTick(() => {
          this.selectDefaultBatchOutRows()
        })
      }).catch(err => {
        if (err.message !== "__handled__") {
          this.$message.error(err.message || "获取物料可出账数量失败")
        }
        this.batchOutDialogVisible = false
      }).finally(() => {
        this.batchOutLoading = false
      })
    },

    buildBatchOutRowsWithCapacity(rows) {
      const uniqueRows = []
      const seenIds = new Set()
      rows.forEach(row => {
        const id = String(row.id || "")
        if (!id || seenIds.has(id)) {
          return
        }
        seenIds.add(id)
        uniqueRows.push(row)
      })

      return Promise.all(uniqueRows.map(row =>
        axios.get(`${API_BASE}/material/out_capacity/${row.id}`, {
          params: {
            submitter: this.user.username
          }
        }).then(res => {
          if (res.data.code !== 200) {
            throw new Error(res.data.msg || "获取物料可出账数量失败")
          }

          const capacity = res.data.data || {}
          const availableQuantity = Number(capacity.available_quantity || 0)
          return Object.assign({}, row, {
            quantity: Number(capacity.total_quantity || 0),
            pending_out: Number(capacity.pending_out || 0),
            available_quantity: availableQuantity,
            out_number: availableQuantity > 0 ? availableQuantity : 0,
            selected_material_id: row.id
          })
        })
      ))
    },

    fetchBatchOutOptionRows(rows) {
      const receiveCodes = Array.from(new Set(rows.map(row => row.receive_code).filter(Boolean)))
      if (!receiveCodes.length) {
        return Promise.resolve(rows)
      }

      const basePayload = {
        teamScope: this.isDashboardView ? "all" : "mine",
        scopeTeam: this.user.team,
        userScope: this.isDashboardView ? "all" : "mine",
        scopeUser: this.user.username,
        page: 1,
        pageSize: 100
      }

      return Promise.all(receiveCodes.map(receiveCode =>
        axios.post(`${API_BASE}/material/list`, Object.assign({}, basePayload, {
          receiveCode
        })).then(res => {
          if (res.data.code !== 200) {
            return []
          }
          return (res.data.data || []).filter(row => row.receive_code === receiveCode && this.canOutMaterial(row))
        }).catch(() => [])
      )).then(results => {
        const optionRows = []
        const seenIds = new Set()
        rows.concat(...results).forEach(row => {
          const id = String(row.id || "")
          if (!id || seenIds.has(id) || !this.canOutMaterial(row)) {
            return
          }
          seenIds.add(id)
          optionRows.push(row)
        })
        return optionRows
      })
    },

    groupBatchOutOptionsByReceiveCode(rows) {
      return rows.reduce((groups, row) => {
        const key = this.batchOutReceiveCodeKey(row)
        if (!groups[key]) {
          groups[key] = []
        }
        groups[key].push(row)
        return groups
      }, {})
    },

    pickDefaultBatchOutRowsByReceiveCode(rows) {
      const groups = {}
      rows.forEach(row => {
        const key = this.batchOutReceiveCodeKey(row)
        const current = groups[key]
        if (!current || (!this.isBatchOutRowSelectable(current) && this.isBatchOutRowSelectable(row))) {
          groups[key] = row
        }
      })
      return Object.values(groups)
    },

    batchOutReceiveCodeKey(row) {
      return row.receive_code ? `code:${row.receive_code}` : `id:${row.id}`
    },

    getBatchOutRowKey(row) {
      return row.id
    },

    isBatchOutRowSelectable(row) {
      return Number(row && row.available_quantity || 0) > 0
    },

    handleBatchOutSelectionChange(rows) {
      this.selectedBatchOutRows = rows
    },

    selectDefaultBatchOutRows() {
      if (!this.$refs.batchOutTable) {
        return
      }
      this.$refs.batchOutTable.clearSelection()
      this.batchOutRows.forEach(row => {
        if (this.isBatchOutRowSelectable(row)) {
          this.$refs.batchOutTable.toggleRowSelection(row, true)
        }
      })
    },

    syncBatchOutSelectionByIds(selectedIds) {
      if (!this.$refs.batchOutTable) {
        return
      }
      const idSet = new Set(Array.from(selectedIds).map(id => String(id)))
      this.$refs.batchOutTable.clearSelection()
      this.batchOutRows.forEach(row => {
        if (idSet.has(String(row.id)) && this.isBatchOutRowSelectable(row)) {
          this.$refs.batchOutTable.toggleRowSelection(row, true)
        }
      })
    },

    batchOutMaterialOptions(row) {
      const options = this.batchOutOptionsByReceiveCode[this.batchOutReceiveCodeKey(row)] || []
      if (options.length) {
        return options
      }
      return row ? [row] : []
    },

    batchOutMaterialOptionLabel(row) {
      const entryDate = row.entry_date ? ` / ${row.entry_date}` : ""
      const location = row.material_storage_location ? ` / ${row.material_storage_location}` : ""
      return `${row.item_name || "-"} / 可出账${Number(row.available_quantity || 0)}${entryDate}${location}`
    },

    handleBatchOutMaterialSelect(index, materialId) {
      const currentRow = this.batchOutRows[index]
      if (!currentRow) {
        return
      }

      const option = this.batchOutMaterialOptions(currentRow).find(item => String(item.id) === String(materialId))
      if (!option) {
        currentRow.selected_material_id = currentRow.id
        return
      }

      const duplicateIndex = this.batchOutRows.findIndex((row, rowIndex) => rowIndex !== index && String(row.id) === String(option.id))
      if (duplicateIndex !== -1) {
        this.$message.warning("该物料已在批量出账列表中")
        currentRow.selected_material_id = currentRow.id
        return
      }

      const selectedIds = new Set(this.selectedBatchOutRows.map(row => String(row.id)))
      const wasSelected = selectedIds.delete(String(currentRow.id))
      const nextRow = Object.assign({}, option, {
        out_number: Number(option.available_quantity || 0) > 0 ? Number(option.available_quantity || 0) : 0,
        selected_material_id: option.id
      })
      if (wasSelected && this.isBatchOutRowSelectable(nextRow)) {
        selectedIds.add(String(nextRow.id))
      }
      this.$set(this.batchOutRows, index, nextRow)
      this.$nextTick(() => {
        this.syncBatchOutSelectionByIds(selectedIds)
      })
    },

    fetchAllMaterialRowsForCurrentSearch() {
      const pageSize = 100
      const searchPayload = this.cleanSearchForm()
      const basePayload = {
        ...searchPayload,
        teamScope: this.isDashboardView ? "all" : "mine",
        scopeTeam: this.user.team,
        userScope: this.isDashboardView ? "all" : "mine",
        scopeUser: this.user.username,
        pageSize
      }

      return axios.post(`${API_BASE}/material/list`, Object.assign({}, basePayload, {
        page: 1
      })).then(res => {
        if (res.data.code !== 200) {
          throw new Error(res.data.msg || "获取物料失败")
        }
        const rows = res.data.data || []
        const total = Number(res.data.total || rows.length)
        const pageCount = Math.ceil(total / pageSize)
        if (pageCount <= 1) {
          return rows
        }
        const requests = []
        for (let page = 2; page <= pageCount; page += 1) {
          requests.push(axios.post(`${API_BASE}/material/list`, Object.assign({}, basePayload, { page })))
        }
        return Promise.all(requests).then(results => {
          results.forEach(item => {
            if (item.data.code !== 200) {
              throw new Error(item.data.msg || "获取物料失败")
            }
            rows.push(...(item.data.data || []))
          })
          return rows
        })
      })
    },

    resetBatchOutDialog() {
      this.batchOutForm = emptyBatchOutForm()
      this.batchOutRows = []
      this.selectedBatchOutRows = []
      this.batchOutOptionsByReceiveCode = {}
      this.batchOutFileList = []
      this.batchOutImageFile = null
      this.batchOutLoading = false
      this.prototypeChildOptions = []
    },

    handleBatchOutProjectChange(projectName) {
      this.batchOutForm.prototype_group_key = ""
      this.batchOutForm.prototype_name = ""
      this.batchOutForm.prototype_code = ""
      this.batchOutForm.prototype_identity_code = ""
      this.batchOutForm.prototype_option_type = ""
      this.prototypeChildOptions = []
      this.fetchPrototypeOptions(projectName)
    },

    handleBatchPrototypeGroupSelect(optionKey) {
      const option = this.prototypeOptions.find(item => item.key === optionKey)
      this.batchOutForm.prototype_name = option ? option.name : ""
      this.batchOutForm.prototype_code = ""
      this.batchOutForm.prototype_identity_code = ""
      this.batchOutForm.prototype_option_type = option ? option.option_type : ""
      this.prototypeChildOptions = []
      if (!option) return
      if (option.option_type === "prototype") {
        this.batchOutForm.prototype_code = option.key
        this.batchOutForm.prototype_identity_code = option.key
        return
      }
      axios.get(`${API_BASE}/prototype/project_option_children`, {
        params: {
          projectName: this.batchOutForm.project_name,
          optionType: option.option_type,
          optionKey: option.key
        }
      }).then(res => {
        if (res.data.code !== 200) return
        this.prototypeChildOptions = res.data.data || []
      }).catch(() => {})
    },

    handleBatchPrototypeChildSelect(identityCode) {
      const prototype = this.prototypeChildOptions.find(item => item.identity_code === identityCode)
      this.batchOutForm.prototype_code = prototype ? prototype.item_name : ""
    },

    handleBatchOutEngineerSelect(item) {
      this.batchOutForm.engineer = item.value
    },

    handleBatchOutImageChange(file, fileList) {
      if (!this.validateImageFile(file)) {
        this.batchOutFileList = []
        this.batchOutImageFile = null
        return
      }
      this.batchOutFileList = fileList.slice(-1)
      this.batchOutImageFile = file.raw
    },

    handleBatchOutImageRemove() {
      this.batchOutFileList = []
      this.batchOutImageFile = null
    },

    submitBatchOutRequest() {
      const rowsToSubmit = this.selectedBatchOutRows.filter(row => this.isBatchOutRowSelectable(row))
      if (!rowsToSubmit.length) {
        this.$message.error("请选择要出账的物料")
        return
      }

      if (!this.batchOutForm.use) {
        this.$message.error("请选择用途")
        return
      }

      if (!this.batchOutForm.material_recipient) {
        this.$message.error("请输入物料领取人")
        return
      }

      if (!this.batchOutForm.project_name) {
        this.$message.error("请选择项目")
        return
      }

      if (!this.batchOutForm.prototype_name) {
        this.$message.error("请选择样机名称")
        return
      }

      if (!this.batchOutForm.prototype_code || !this.batchOutForm.prototype_identity_code) {
        this.$message.error("请选择样机编号")
        return
      }

      if (this.batchOutForm.use === "退回研发" && !String(this.batchOutForm.carry_out_number || "").trim()) {
        this.$message.error("请输入携物出门单号")
        return
      }

      const engineer = this.extractEngineerJobNumber(this.batchOutForm.engineer)
      if (!engineer) {
        this.$message.error("请选择审批工程师")
        return
      }

      const invalidRow = rowsToSubmit.find(row => Number(row.out_number || 0) <= 0)
      if (invalidRow) {
        this.$message.error(`${invalidRow.item_name} 的出账数量必须大于0`)
        return
      }

      const overRow = rowsToSubmit.find(row => Number(row.out_number || 0) > Number(row.available_quantity || 0))
      if (overRow) {
        this.$message.error(`${overRow.item_name} 的出账数量不能大于可出账数`)
        return
      }

      const formData = new FormData()
      formData.append("items", JSON.stringify(rowsToSubmit.map(row => ({
        materialId: row.id,
        outNumber: row.out_number
      }))))
      formData.append("purpose", this.batchOutForm.use || "")
      formData.append("remark", this.batchOutForm.remark || "")
      formData.append("submitter", this.user.username)
      formData.append("engineer", engineer)
      formData.append("materialRecipient", this.batchOutForm.material_recipient || "")
      formData.append("projectName", this.batchOutForm.project_name || "")
      formData.append("prototypeName", this.batchOutForm.prototype_name || "")
      formData.append("prototypeCode", this.batchOutForm.prototype_code || "")
      formData.append("prototypeIdentityCode", this.batchOutForm.prototype_identity_code || "")
      formData.append("carryOutNumber", this.batchOutForm.carry_out_number || "")

      if (this.batchOutImageFile) {
        formData.append("image", this.batchOutImageFile)
      }

      this.batchOutLoading = true
      axios.post(`${API_BASE}/material/out_request`, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.batchOutDialogVisible = false
          this.fetchMaterialData()
          return
        }

        this.$message.error(res.data.msg || "提交失败")
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.batchOutLoading = false
      })
    },

    canOutMaterial(row) {
      return Number(this.user.permissions) === 0 &&
        this.user.category === "技师" &&
        row.entry_person === this.user.username &&
        Number(row.quantity || 0) > 0
    },

    canEditMaterial(row) {
      return Boolean(row) &&
        (this.isAdmin || (!this.isEngineerUser && row.entry_person === this.user.username))
    },

    usageStatusTagType(status) {
      if (status === "已使用") {
        return "success"
      }
      if (status === "报废") {
        return "danger"
      }
      if (status === "销账中") {
        return "warning"
      }
      if (status === "已销账") {
        return "info"
      }
      return ""
    },

    materialCodeText(row) {
      return row.receiveCode || row.identityCode || "-"
    },

    projectOptionLabel(project) {
      const manager = project.project_manager ? ` / ${project.project_manager}` : ""
      return `${project.project_name}${manager}`
    },

    responsibleOptionLabel(item) {
      const name = item.name ? ` ${item.name}` : ""
      const team = item.team ? ` / ${item.team}` : ""
      return `${item.username}${name}${team}`
    },

    openScrapDialog() {
      this.scrapDialogVisible = true
      this.scrapProofFileList = []
      this.scrapProofFile = null
      this.loadDisposalCandidates("scrap", "scrapTable")
    },

    openWriteoffDialog() {
      this.writeoffDialogVisible = true
      this.loadDisposalCandidates("writeoff", "writeoffTable")
    },

    resetDisposalDialog() {
      this.disposalRows = []
      this.selectedDisposalRows = []
      this.disposalLoading = false
    },

    resetScrapDialog() {
      this.resetDisposalDialog()
      this.scrapProofFileList = []
      this.scrapProofFile = null
    },

    loadDisposalCandidates(action, tableRef) {
      this.disposalRows = []
      this.selectedDisposalRows = []
      this.disposalLoading = true

      axios.get(`${API_BASE}/material/disposal_candidates`, {
        params: {
          username: this.user.username,
          permissions: this.user.permissions,
          action
        }
      }).then(res => {
        if (res.data.code === 200) {
          this.disposalRows = res.data.data || []
          this.$nextTick(() => {
            if (tableRef && this.$refs[tableRef]) {
              this.$refs[tableRef].clearSelection()
            }
          })
          return
        }

        this.$message.error(res.data.msg || "获取物料失败")
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.disposalLoading = false
      })
    },

    handleDisposalSelectionChange(rows) {
      this.selectedDisposalRows = rows
    },

    handleScrapProofChange(file) {
      if (!this.validateImageFile(file)) {
        this.scrapProofFileList = []
        this.scrapProofFile = null
        return
      }
      this.scrapProofFileList = [file]
      this.scrapProofFile = file.raw
    },

    handleScrapProofExceed(files) {
      const rawFile = files && files[0]
      const file = {
        name: rawFile ? rawFile.name : "",
        raw: rawFile,
        uid: Date.now()
      }
      this.handleScrapProofChange(file)
    },

    handleScrapProofRemove() {
      this.scrapProofFileList = []
      this.scrapProofFile = null
    },

    submitScrap() {
      if (!this.selectedDisposalRows.length) {
        this.$message.error("请选择要报废的物料")
        return
      }

      if (!this.scrapProofFile) {
        this.$message.error("请上传评审证明")
        return
      }

      const formData = new FormData()
      formData.append("operator", this.user.username || "")
      formData.append("ids", JSON.stringify(this.selectedDisposalRows.map(item => item.id)))
      formData.append("proof", this.scrapProofFile)

      this.disposalLoading = true
      axios.post(`${API_BASE}/material/scrap`, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.scrapDialogVisible = false
          this.fetchMaterialData()
          return
        }

        this.$message.error(res.data.msg || "报废提交失败")
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.disposalLoading = false
      })
    },

    submitWriteoff() {
      if (!this.selectedDisposalRows.length) {
        this.$message.error("请选择要销账的物料")
        return
      }

      this.disposalLoading = true
      axios.post(`${API_BASE}/material/writeoff`, {
        operator: this.user.username || "",
        ids: this.selectedDisposalRows.map(item => item.id)
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.writeoffDialogVisible = false
          this.fetchMaterialData()
          return
        }

        this.$message.error(res.data.msg || "销账提交失败")
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.disposalLoading = false
      })
    },

    openMaterialTransferDialog() {
      this.materialTransferDialogVisible = true
      this.materialTransferForm = emptyMaterialTransferForm()
      this.materialTransferRows = []
      this.selectedMaterialTransferRows = []
      this.materialTransferLoading = true

      const selectedIds = this.selectedRows.map(item => item.id)
      axios.get(`${API_BASE}/project/material_transfer/candidates`, {
        params: {
          username: this.user.username,
          permissions: this.user.permissions,
          itemName: this.searchForm.itemName || ""
        }
      }).then(res => {
        if (res.data.code !== 200) {
          this.$message.error(res.data.msg || "获取可转移物料失败")
          return
        }

        const rows = res.data.data || []
        this.materialTransferRows = selectedIds.length
          ? rows.filter(item => selectedIds.includes(item.id))
          : rows

        if (selectedIds.length && !this.materialTransferRows.length) {
          this.$message.warning("所选物料没有可转移数据")
        }

        this.$nextTick(() => {
          if (this.$refs.materialTransferTable) {
            this.$refs.materialTransferTable.clearSelection()
            if (selectedIds.length) {
              this.materialTransferRows.forEach(row => {
                this.$refs.materialTransferTable.toggleRowSelection(row, true)
              })
            }
          }
        })
      }).catch(() => {
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.materialTransferLoading = false
      })
    },

    resetMaterialTransferDialog() {
      this.materialTransferForm = emptyMaterialTransferForm()
      this.materialTransferRows = []
      this.selectedMaterialTransferRows = []
      this.materialTransferLoading = false
    },

    handleMaterialTransferSelectionChange(rows) {
      this.selectedMaterialTransferRows = rows
    },

    submitMaterialTransfer() {
      if (!this.materialTransferForm.newProjectName) {
        this.$message.error("请选择转入项目")
        return
      }
      if (!this.materialTransferForm.newResponsible) {
        this.$message.error("请选择转入责任人")
        return
      }
      if (!this.selectedMaterialTransferRows.length) {
        this.$message.error("请选择要转移的物料")
        return
      }

      this.materialTransferLoading = true
      Promise.all(this.selectedMaterialTransferRows.map(row =>
        axios.post(`${API_BASE}/project/material_transfer/submit`, {
          materialId: row.id,
          newProjectName: this.materialTransferForm.newProjectName,
          newResponsible: this.materialTransferForm.newResponsible,
          applicant: this.user.username || "",
          permissions: this.user.permissions,
          remark: this.materialTransferForm.remark || ""
        }).then(res => ({
          success: res.data.code === 200,
          msg: res.data.msg
        })).catch(() => ({
          success: false,
          msg: "网络请求失败"
        }))
      )).then(results => {
        const successCount = results.filter(item => item.success).length
        const failCount = results.length - successCount
        if (successCount) {
          this.$message.success(`转移提交完成，成功 ${successCount} 条${failCount ? `，失败 ${failCount} 条` : ""}`)
          this.materialTransferDialogVisible = false
          this.fetchMaterialData()
          return
        }
        this.$message.error(results[0].msg || "转移提交失败")
      }).finally(() => {
        this.materialTransferLoading = false
      })
    },

    validateNonNegativeNumber(rule, value, callback) {
      if (Number(value) < 0) {
        callback(new Error("数量不能为负数"))
        return
      }

      callback()
    },

    validateReceiveCode(rule, value, callback) {
      if (this.isReceiveCodeRequired && !String(value || "").trim()) {
        callback(new Error("请选择领用编码"))
        return
      }
      callback()
    },

    validateEbuyField(rule, value, callback) {
      if (this.isOrderNumberRequired && !String(value || "").trim()) {
        callback(new Error("请输入领料单号"))
        return
      }

      callback()
    },

    validateUnitPrice(rule, value, callback) {
      if (this.isUnitPriceRequired && (value === undefined || value === null || value === "")) {
        callback(new Error("请输入单价"))
        return
      }

      callback()
    },

    isReadOnlyField(field) {
      if (this.dialogMode === "out") {
        return !["out_number", "use", "remark", "engineer", "material_recipient", "project_name", "prototype_name", "prototype_code", "carry_out_number"].includes(field)
      }

      if (["entry_person", "team", "engineer"].includes(field)) {
        return true
      }

      return this.dialogMode === "edit" &&
        !this.isAdmin &&
        field !== "material_storage_location" &&
        field !== "remark"
    },

    submitMaterialForm() {
      if (this.dialogMode === "out") {
        this.submitOutRequest()
        return
      }

      this.$refs.materialForm.validate(valid => {
        if (!valid) {
          return
        }

        if (this.isImageRequired && !this.selectedImageFile) {
          this.$message.error("请选择图片")
          return
        }

        this.ensureProjectAddress(
          this.materialForm.project_name,
          this.materialForm.material_storage_location
        ).then(() => {
          const formData = new FormData()
          const payload = Object.assign({}, this.materialForm)

          Object.keys(payload).forEach(key => {
            if (payload[key] !== undefined && payload[key] !== null) {
              formData.append(key, payload[key])
            }
          })

          formData.append("isAdmin", this.isAdmin ? "1" : "0")
          formData.append("operator", this.user.username || "")

          if (this.selectedImageFile) {
            formData.append("image", this.selectedImageFile)
          }

          const request = this.dialogMode === "add"
            ? axios.post(`${API_BASE}/material/add`, formData)
            : axios.post(`${API_BASE}/material/update/${this.materialForm.id}`, formData)

          request.then(res => {
            if (res.data.code === 200) {
              this.$message.success(res.data.msg)
              this.formDialogVisible = false
              this.fetchMaterialData()
            } else {
              this.$message.error(res.data.msg || "提交失败")
            }
          }).catch(err => {
            console.log(err)
            this.$message.error("网络请求失败，请检查后端是否启动")
          })
        }).catch(err => {
          this.$message.error(err.message || "地址保存失败")
        })
      })
    },

    submitOutRequest() {
      if (!this.materialForm.out_number || Number(this.materialForm.out_number) <= 0) {
        this.$message.error("出账数量必须大于0")
        return
      }

      const availableQuantity = Number(this.materialForm.available_quantity || this.materialForm.quantity || 0)

      if (availableQuantity <= 0) {
        this.$message.error("当前可出账数量为0，不能出账")
        return
      }

      if (Number(this.materialForm.out_number) > availableQuantity) {
        this.$message.error("出账数量不能大于当前可出账数量")
        return
      }

      if (!this.materialForm.use) {
        this.$message.error("请选择用途")
        return
      }

      if (!this.materialForm.material_recipient) {
        this.$message.error("请输入物料领取人")
        return
      }

      if (!this.materialForm.project_name) {
        this.$message.error("请选择项目")
        return
      }

      if (!this.materialForm.prototype_name) {
        this.$message.error("请输入样机名称")
        return
      }

      if (!this.materialForm.prototype_code) {
        this.$message.error("请输入样机编号")
        return
      }

      if (this.materialForm.use === "退回研发" && !String(this.materialForm.carry_out_number || "").trim()) {
        this.$message.error("请输入携物出门单号")
        return
      }

      const formData = new FormData()
      formData.append("materialId", this.materialForm.id)
      formData.append("outNumber", this.materialForm.out_number)
      formData.append("purpose", this.materialForm.use || "")
      formData.append("remark", this.materialForm.remark || "")
      formData.append("submitter", this.user.username)
      formData.append("engineer", this.extractEngineerJobNumber(this.materialForm.engineer))
      formData.append("materialRecipient", this.materialForm.material_recipient || "")
      formData.append("projectName", this.materialForm.project_name || "")
      formData.append("prototypeName", this.materialForm.prototype_name || "")
      formData.append("prototypeCode", this.materialForm.prototype_code || "")
      formData.append("prototypeIdentityCode", this.materialForm.prototype_identity_code || "")
      formData.append("carryOutNumber", this.materialForm.carry_out_number || "")

      if (this.selectedImageFile) {
        formData.append("image", this.selectedImageFile)
      }

      axios.post(`${API_BASE}/material/out_request`, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.formDialogVisible = false
          this.fetchMaterialData()
        } else {
          this.$message.error(res.data.msg || "提交失败")
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    resetMaterialForm() {
      this.materialForm = emptyMaterialForm()
      this.fileList = []
      this.selectedImageFile = null

      if (this.$refs.materialForm) {
        this.$refs.materialForm.clearValidate()
      }
    },

    handleImageChange(file, fileList) {
      if (!this.validateImageFile(file)) {
        this.fileList = []
        this.selectedImageFile = null
        return
      }
      this.fileList = fileList.slice(-1)
      this.selectedImageFile = file.raw
    },

    handleImageRemove() {
      this.fileList = []
      this.selectedImageFile = null
    },

    validateImageFile(file) {
      const name = (file && file.name) || (file && file.raw && file.raw.name) || ""
      const ext = name.includes(".") ? name.split(".").pop().toLowerCase() : ""
      const allowed = ["png", "jpg", "jpeg", "gif", "webp", "bmp"]
      if (!allowed.includes(ext)) {
        this.$message.error("图片格式仅支持 png、jpg、jpeg、gif、webp、bmp")
        return false
      }
      return true
    },

    handleItemSourceChange() {
      if (!["ebuy途径购买", "自行采购"].includes(this.materialForm.item_source)) {
        this.materialForm.receive_code = ""
        this.materialForm.catlog_code = ""
        this.materialForm.order_number = ""
        this.receiveCodeMatched = false
      }

      if (this.materialForm.item_source === "自行采购") {
        this.materialForm.material_provider = this.user.username || ""
      }

      this.fillItemNameByReceiveCode()
    },

    fillItemNameByReceiveCode() {
      if (!this.materialForm.receive_code) {
        this.receiveCodeMatched = false
        return
      }

      axios.get(`${API_BASE}/material/by_receive_code`, {
        params: {
          receiveCode: this.materialForm.receive_code
        }
      }).then(res => {
        if (res.data.code === 200 && res.data.data.itemName) {
          this.materialForm.item_name = res.data.data.itemName
          this.receiveCodeMatched = true
        } else {
          this.materialForm.item_name = ""
          this.receiveCodeMatched = false
        }
      }).catch(err => {
        this.materialForm.item_name = ""
        this.receiveCodeMatched = false
        console.log(err)
      })
    },

    handleReceiveCodeInput() {
      if (this.dialogMode === "add") {
        this.materialForm.item_name = ""
      }
      this.receiveCodeMatched = false
    },

    queryReceiveCodeSuggestions(queryString, callback) {
      axios.get(`${API_BASE}/catalog/list`, {
        params: {
          keyword: (queryString || "").trim()
        }
      }).then(res => {
        if (res.data.code === 200) {
          callback(res.data.data.map(item => ({
            value: `${item.receive_code} - ${item.item_name}`,
            receive_code: item.receive_code,
            item_name: item.item_name
          })))
          return
        }

        callback([])
      }).catch(() => {
        callback([])
      })
    },

    handleReceiveCodeSelect(item) {
      this.materialForm.receive_code = item.receive_code
      this.materialForm.item_name = item.item_name
      this.receiveCodeMatched = true
    },

    fillEngineerByTeam() {
      const engineers = this.teamEngineerMap[this.materialForm.team] || []

      if (engineers.length) {
        this.materialForm.engineer = engineers[0]
      }
    },

    getEngineerSuggestionOptions() {
      return this.engineerOptions.map(item => ({
        value: item.label || `${item.jobNumber} ${item.name || ""}`.trim(),
        jobNumber: item.jobNumber,
        name: item.name
      }))
    },

    queryEngineerSuggestions(queryString, callback) {
      const keyword = (queryString || "").trim().toLowerCase()
      const options = this.getEngineerSuggestionOptions()

      if (!keyword) {
        callback(options)
        return
      }

      callback(options.filter(item =>
        item.value.toLowerCase().includes(keyword) ||
        String(item.jobNumber || "").toLowerCase().includes(keyword) ||
        String(item.name || "").toLowerCase().includes(keyword)
      ))
    },

    handleEngineerInput(value) {
      if (this.dialogMode !== "out") {
        return
      }

      if (this.engineerAutoFillTimer) {
        clearTimeout(this.engineerAutoFillTimer)
      }

      this.lastEngineerInputValue = String(value || "")

      this.engineerAutoFillTimer = setTimeout(() => {
        const rawValue = String(value || "")
        if (rawValue !== this.lastEngineerInputValue) {
          return
        }

        const keyword = rawValue.trim().toLowerCase()

        if (!keyword) {
          return
        }

        const options = this.getEngineerSuggestionOptions()
        const exactMatch = options.find(item =>
          String(item.jobNumber || "").toLowerCase() === keyword ||
          String(item.name || "").toLowerCase() === keyword ||
          String(item.value || "").toLowerCase() === keyword
        )

        if (exactMatch) {
          this.materialForm.engineer = exactMatch.value
          return
        }

        if (keyword.length < 2) {
          return
        }

        const prefixMatches = options.filter(item =>
          String(item.jobNumber || "").toLowerCase().startsWith(keyword) ||
          String(item.name || "").toLowerCase().startsWith(keyword) ||
          String(item.value || "").toLowerCase().startsWith(keyword)
        )

        if (prefixMatches.length === 1) {
          this.materialForm.engineer = prefixMatches[0].value
        }
      }, 650)
    },

    handleEngineerSelect(item) {
      if (this.engineerAutoFillTimer) {
        clearTimeout(this.engineerAutoFillTimer)
      }
      this.materialForm.engineer = item.value
    },

    extractEngineerJobNumber(value) {
      return String(value || "").trim().split(/\s+/)[0] || ""
    },

    formatEngineerValue(jobNumber) {
      const engineer = this.engineerOptions.find(item => item.jobNumber === jobNumber)
      if (!engineer) {
        return jobNumber || ""
      }

      return engineer.label || `${engineer.jobNumber} ${engineer.name || ""}`.trim()
    },

    handleView(row) {
      this.currentImageUrl = row.image_path ? `${API_BASE}${row.image_path}` : ""
      this.imageDialogVisible = true
    },

    handleDelete(row) {
      this.$confirm(
        `确认删除物料 ${row.item_name}？`,
        "提示",
        {
          type: "warning"
        }
      ).then(() => {
        axios.delete(`${API_BASE}/material/delete/${row.id}`).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchMaterialData()
          } else {
            this.$message.error(res.data.msg || "删除失败")
          }
        }).catch(err => {
          console.log(err)
          this.$message.error("网络请求失败，请检查后端是否启动")
        })
      }).catch(() => {})
    },

    openRecordDialog(row) {
      this.recordItemName = row.item_name
      this.recordDialogVisible = true
      this.recordLoading = true

      axios.get(`${API_BASE}/material/records`, {
        params: {
          itemName: row.item_name,
          materialId: row.id,
          identityCode: row.identity_code
        }
      }).then(res => {
        if (res.data.code === 200) {
          this.recordRows = res.data.data
          this.recordSummary = res.data.summary
        } else {
          this.$message.error(res.data.msg || "获取记录失败")
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.recordLoading = false
      })
    },

    handleExport() {
      const identityCodes = this.selectedRows.map(item => item.identity_code).filter(Boolean)
      this.downloadExport(identityCodes.length ? { identityCodes } : this.cleanSearchForm())
    },

    handleBatchEdit() {
      if (!this.selectedRows.length) {
        this.$message.warning("请选择要修改的数据")
        return
      }

      this.batchDialogVisible = true
    },

    submitBatchEdit() {
      if (!this.batchEntryPerson) {
        this.$message.error("请输入录入人")
        return
      }

      axios.post(`${API_BASE}/material/batch_update_entry_person`, {
        ids: this.selectedRows.map(item => item.id),
        entryPerson: this.batchEntryPerson,
        permissions: this.user.permissions
      }).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.batchDialogVisible = false
          this.fetchMaterialData()
        } else {
          this.$message.error(res.data.msg || "批量修改失败")
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      })
    },

    handleBatchDelete() {
      if (!this.selectedRows.length) {
        this.$message.warning("请选择要删除的数据")
        return
      }

      this.$confirm(
        `确认删除选中的 ${this.selectedRows.length} 条数据？`,
        "提示",
        {
          type: "warning"
        }
      ).then(() => {
        axios.post(`${API_BASE}/material/delete_batch`, {
          ids: this.selectedRows.map(item => item.id)
        }).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.fetchMaterialData()
          } else {
            this.$message.error(res.data.msg || "批量删除失败")
          }
        }).catch(err => {
          console.log(err)
          this.$message.error("网络请求失败，请检查后端是否启动")
        })
      }).catch(() => {})
    },

    exportSameItem(row) {
      this.downloadExport({ identityCodes: [row.identity_code].filter(Boolean), ids: row.identity_code ? [] : [row.id] }, "物料记录导出")
    },

    downloadImportTemplate() {
      axios.get(`${API_BASE}/material/template`, {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `物料导入模板_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      }).catch(() => {
        this.$message.error("模板下载失败，请检查后端是否启动")
      })
    },

    handleImportChange(file) {
      const formData = new FormData()
      formData.append("file", file.raw)
      formData.append("entryPerson", this.user.username || "")
      formData.append("team", this.user.team || "")
      formData.append("engineer", this.user.engineer || "")

      axios.post(`${API_BASE}/material/import`, formData).then(res => {
        if (res.data.code === 200) {
          this.$message.success(res.data.msg)
          this.fetchMaterialData()
        } else {
          this.$message.error(res.data.msg || "导入失败")
        }
      }).catch(() => {
        this.$message.error("导入失败，请检查文件格式")
      })
    },

    openSummaryDialog() {
      this.summaryDialogVisible = true
      this.summaryLoading = true
      const ids = this.selectedRows.map(item => item.id)
      const payload = ids.length ? { ids } : this.cleanSearchForm()

      axios.post(`${API_BASE}/material/summary`, Object.assign({
        teamScope: this.isDashboardView ? "all" : "mine",
        scopeTeam: this.user.team,
        userScope: this.isDashboardView ? "all" : "mine",
        scopeUser: this.user.username
      }, payload)).then(res => {
        if (res.data.code === 200) {
          this.summaryRows = res.data.data.byItem
          this.summaryTotals = res.data.data.totals
        } else {
          this.$message.error(res.data.msg || "获取汇总失败")
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("网络请求失败，请检查后端是否启动")
      }).finally(() => {
        this.summaryLoading = false
      })
    },

    downloadExport(payload, filePrefix = "物料台账") {
      axios.post(`${API_BASE}/material/export`, Object.assign({
        teamScope: this.isDashboardView ? "all" : "mine",
        scopeTeam: this.user.team,
        userScope: this.isDashboardView ? "all" : "mine",
        scopeUser: this.user.username
      }, payload), {
        responseType: "blob"
      }).then(res => {
        const blob = new Blob([res.data], { type: "text/csv;charset=utf-8" })
        const link = document.createElement("a")
        link.href = URL.createObjectURL(blob)
        link.download = `${filePrefix}_${this.formatExportTime()}.csv`
        link.click()
        URL.revokeObjectURL(link.href)
      }).catch(err => {
        console.log(err)
        this.$message.error("导出失败，请检查后端是否启动")
      })
    },

    formatExportTime() {
      const date = new Date()
      const pad = value => String(value).padStart(2, "0")

      return [
        date.getFullYear(),
        pad(date.getMonth() + 1),
        pad(date.getDate())
      ].join("") + "_" + [
        pad(date.getHours()),
        pad(date.getMinutes()),
        pad(date.getSeconds())
      ].join("")
    }
  }
}
</script>

<style scoped>
.page-container {
  padding: 16px;
  background-color: #f5f7fa;
  min-height: 100vh;
  min-width: 1180px;
  overflow-x: auto;
}

.search-card,
.table-card {
  border-radius: 6px;
  border: 1px solid #ebeef5;
}

.search-card {
  margin-bottom: 16px;
}

.search-form {
  display: grid;
  grid-template-columns: repeat(4, minmax(250px, 1fr));
  column-gap: 12px;
  row-gap: 4px;
  align-items: start;
}

.search-form .el-form-item {
  margin-right: 0;
  margin-bottom: 10px;
}

.search-form .el-input,
.search-form .el-select,
.search-form .el-date-editor {
  width: 100%;
}

.search-form .el-form-item:last-child {
  grid-column: span 4;
}

.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.toolbar-title {
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.operation-buttons {
  display: grid;
  grid-template-columns: repeat(2, 72px);
  gap: 6px;
  align-items: center;
}

.operation-buttons .el-button {
  width: 72px;
  margin-left: 0;
}

.pagination-bar {
  display: flex;
  justify-content: flex-end;
  padding-top: 14px;
}

.image-box {
  min-height: 260px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
}

.material-image {
  max-width: 100%;
  max-height: 520px;
  object-fit: contain;
}

.price-separator {
  display: inline-block;
  width: 18px;
  text-align: center;
  color: #909399;
}

.record-title {
  margin-bottom: 12px;
  font-size: 16px;
  font-weight: 600;
  color: #303133;
}

.record-chart,
.summary-chart {
  padding: 12px;
  margin-bottom: 14px;
  border: 1px solid #ebeef5;
  border-radius: 6px;
  background: #fafafa;
}

.chart-row {
  display: grid;
  grid-template-columns: 70px 1fr 80px;
  gap: 10px;
  align-items: center;
  margin-bottom: 10px;
}

.chart-row:last-child {
  margin-bottom: 0;
}

.chart-label,
.chart-value {
  font-size: 13px;
  color: #606266;
}

.chart-value {
  text-align: right;
}

.chart-track {
  height: 16px;
  overflow: hidden;
  border-radius: 3px;
  background: #ebeef5;
}

.chart-bar {
  height: 100%;
  transition: width 0.2s ease;
}

.chart-bar.receive {
  background: #67c23a;
}

.chart-bar.out {
  background: #e6a23c;
}

.chart-bar.pending {
  background: #f56c6c;
}

.chart-bar.remain {
  background: #409eff;
}

.prototype-option-code {
  float: right;
  margin-left: 16px;
  color: #909399;
  font-size: 12px;
}

.proof-upload {
  width: 100%;
}

.proof-upload ::v-deep .el-upload,
.proof-upload ::v-deep .el-upload-dragger {
  width: 100%;
}

.writeoff-steps {
  margin-bottom: 12px;
}
</style>
