<template>
  <el-container class="layout">

    <!-- 左侧菜单 -->
    <el-aside width="220px">
      <Sidebar />
    </el-aside>

    <el-container>

      <!-- 顶部 -->
      <el-header>
        <Header />
      </el-header>

      <!-- 主体 -->
      <el-main>
        <ApprovalCards />
        <router-view />
      </el-main>

    </el-container>

  </el-container>
</template>

<script>
import Sidebar from './Sidebar.vue'
import Header from './Header.vue'
import ApprovalCards from './ApprovalCards.vue'

export default {
  components: {
    Sidebar,
    Header,
    ApprovalCards
  }
}
</script>

<style scoped>
.layout {
  height: 100vh;
}

.layout ::v-deep .el-main {
  background: #f5f7fa;
}
</style>
