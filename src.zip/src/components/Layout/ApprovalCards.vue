<template>
  <div v-if="user.username && canApprove" class="approval-cards">
    <button class="approval-card" type="button" @click="openDialog('assetAudit')">
      <span class="approval-card-icon material">
        <i class="el-icon-document-checked"></i>
      </span>
      <span class="approval-card-main">
        <span class="approval-card-title">样机物料审核</span>
        <span class="approval-card-desc">待处理审批</span>
      </span>
      <span class="approval-card-count">{{ assetAuditCount }}</span>
    </button>

    <button class="approval-card" type="button" @click="openDialog('monthlyAudit')">
      <span class="approval-card-icon monthly">
        <i class="el-icon-date"></i>
      </span>
      <span class="approval-card-main">
        <span class="approval-card-title">月度审核</span>
        <span class="approval-card-desc">待处理审核</span>
      </span>
      <span class="approval-card-count">{{ monthlyAuditCount }}</span>
    </button>

    <el-dialog
      :title="dialogTitle"
      :visible.sync="dialogVisible"
      width="92%"
      top="5vh"
      append-to-body
      destroy-on-close
      :close-on-click-modal="false"
      class="approval-dialog"
      @closed="fetchApprovals"
    >
      <Agent
        v-if="dialogVisible"
        :key="dialogTab"
        :initial-tab="dialogTab"
        embedded
        @approval-updated="handleApprovalUpdated"
      />
    </el-dialog>
  </div>
</template>

<script>
import axios from "axios"
import Agent from "../../views/agent/index.vue"
import { API_BASE } from "../../config/appConfig"
import { isSameData } from "../../utils/dataChange"

export default {
  components: {
    Agent
  },

  data() {
    return {
      user: {},
      approvals: [],
      dialogVisible: false,
      dialogTab: "assetAudit",
      refreshTimer: null
    }
  },

  computed: {
    isAdmin() {
      return Number(this.user.permissions) === 1
    },

    canApprove() {
      const additionalRoles = String(this.user.additionalRole || "")
        .replace(/[，、；;|/\s]+/g, ",")
        .split(",")
        .map(item => item.trim())
        .filter(Boolean)

      return this.isAdmin ||
        this.user.category === "工程师" ||
        additionalRoles.some(role => ["项目经理", "复盘人", "实验室主任", "高级专家"].includes(role))
    },

    assetAuditCount() {
      const sourceTypes = ["物料", "研发入账", "样机", "销账", "物料转移"]
      return this.approvals.filter(item => {
        return item.status === "pending" &&
          sourceTypes.includes(item.source_type) &&
          (this.isAdmin || item.can_approve)
      }).length
    },

    monthlyAuditCount() {
      return this.approvals.filter(item => {
        return item.status === "pending" &&
          item.source_type === "月度审核" &&
          (this.isAdmin || item.can_approve)
      }).length
    },

    dialogTitle() {
      return this.dialogTab === "monthlyAudit" ? "月度审核" : "样机物料审核"
    }
  },

  watch: {
    "$route.fullPath"() {
      this.dialogVisible = false
    }
  },

  created() {
    const user = localStorage.getItem("user")
    if (user) {
      this.user = JSON.parse(user)
      this.fetchApprovals()
      this.refreshTimer = setInterval(() => this.fetchApprovals(true), 10000)
    }
  },

  beforeDestroy() {
    this.dialogVisible = false
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer)
    }
  },

  methods: {
    fetchApprovals() {
      if (!this.user.username || !this.canApprove) {
        return
      }

      axios.get(`${API_BASE}/approval/list`, {
        params: {
          username: this.user.username,
          permissions: this.user.permissions
        }
      }).then(res => {
        if (res.data.code === 200) {
          const nextApprovals = res.data.data || []
          if (!isSameData(this.approvals, nextApprovals)) {
            this.approvals = nextApprovals
          }
        }
      }).catch(() => {})
    },

    openDialog(tab) {
      this.dialogTab = tab
      this.dialogVisible = true
    },

    handleApprovalUpdated(rows) {
      if (Array.isArray(rows)) {
        this.approvals = rows
      }
    }
  }
}
</script>

<style scoped>
.approval-cards {
  display: grid;
  grid-template-columns: repeat(2, minmax(220px, 1fr));
  gap: 14px;
  margin-bottom: 14px;
}

.approval-card {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 86px;
  padding: 16px 18px;
  border: 1px solid #dfe6f2;
  border-radius: 6px;
  background: #fff;
  color: #303133;
  cursor: pointer;
  text-align: left;
  box-shadow: 0 2px 8px rgba(48, 65, 86, 0.06);
}

.approval-card:hover {
  border-color: #409eff;
}

.approval-card-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 42px;
  height: 42px;
  border-radius: 6px;
  font-size: 22px;
}

.approval-card-icon.material {
  color: #409eff;
  background: #ecf5ff;
}

.approval-card-icon.monthly {
  color: #67c23a;
  background: #f0f9eb;
}

.approval-card-main {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
}

.approval-card-title {
  font-size: 16px;
  font-weight: 600;
}

.approval-card-desc {
  color: #909399;
  font-size: 13px;
}

.approval-card-count {
  min-width: 46px;
  color: #303133;
  font-size: 30px;
  font-weight: 700;
  text-align: right;
}

.approval-dialog ::v-deep .el-dialog__body {
  padding: 0;
  background: #f5f7fa;
}

@media (max-width: 900px) {
  .approval-cards {
    grid-template-columns: 1fr;
  }
}
</style>
