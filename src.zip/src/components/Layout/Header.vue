<template>

  <div class="header">

    <!-- 右边 -->
    <div class="right">

      <el-dropdown>

        <span class="el-dropdown-link">

          {{ username }}

          <i class="el-icon-arrow-down"></i>

        </span>

        <el-dropdown-menu slot="dropdown">

          <el-dropdown-item
            @click.native="openProfileDialog"
          >

            个人中心

          </el-dropdown-item>

          <el-dropdown-item
            @click.native="passwordDialogVisible = true"
          >

            修改密码

          </el-dropdown-item>

          <!-- 退出登录 -->
          <el-dropdown-item
            @click.native="logout"
          >

            退出登录

          </el-dropdown-item>

        </el-dropdown-menu>

      </el-dropdown>

    </div>

    <el-dialog
      title="修改密码"
      :visible.sync="passwordDialogVisible"
      width="420px"
      @close="resetPasswordForm"
    >

      <el-form
        ref="passwordForm"
        :model="passwordForm"
        :rules="passwordRules"
        label-width="90px"
      >

        <el-form-item
          label="原密码"
          prop="oldPassword"
        >
          <el-input
            v-model="passwordForm.oldPassword"
            show-password
            autocomplete="off"
          />
        </el-form-item>

        <el-form-item
          label="新密码"
          prop="newPassword"
        >
          <el-input
            v-model="passwordForm.newPassword"
            show-password
            autocomplete="off"
          />
        </el-form-item>

        <el-form-item
          label="确认密码"
          prop="confirmPassword"
        >
          <el-input
            v-model="passwordForm.confirmPassword"
            show-password
            autocomplete="off"
          />
        </el-form-item>

      </el-form>

      <span slot="footer">
        <el-button @click="passwordDialogVisible = false">
          取消
        </el-button>

        <el-button
          type="primary"
          @click="submitPassword"
        >
          保存
        </el-button>
      </span>

    </el-dialog>

    <el-dialog
      title="个人中心"
      :visible.sync="profileDialogVisible"
      width="420px"
      @close="resetProfileForm"
    >

      <el-form
        ref="profileForm"
        :model="profileForm"
        label-width="90px"
      >

        <el-form-item label="用户名">
          <el-input
            v-model="profileForm.username"
            disabled
          />
        </el-form-item>

        <el-form-item label="所在团队">
          <el-select
            v-model="profileForm.team"
            filterable
            clearable
            default-first-option
            :disabled="!canEditProfile"
            style="width:100%"
          >
            <el-option
              v-for="team in teamOptions"
              :key="team"
              :label="team"
              :value="team"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="对应工程师">
          <el-input
            v-model="profileForm.engineer"
            :readonly="!canEditProfile"
          />
        </el-form-item>

        <el-form-item label="邮箱">
          <el-input
            v-model="profileForm.email"
            :readonly="!canEditProfile"
          />
        </el-form-item>

        <el-form-item label="密码">
          <el-input
            v-model="profileForm.password"
            :type="profilePasswordVisible ? 'text' : 'password'"
            readonly
          >
            <el-button
              slot="append"
              :icon="profilePasswordVisible ? 'el-icon-view' : 'el-icon-view'"
              @click="profilePasswordVisible = !profilePasswordVisible"
            />
          </el-input>
        </el-form-item>

      </el-form>

      <span slot="footer">
        <el-button @click="profileDialogVisible = false">
          取消
        </el-button>

        <el-button
          v-if="canEditProfile"
          type="primary"
          @click="submitProfile"
        >
          保存
        </el-button>
      </span>

    </el-dialog>

  </div>

</template>

<script>
import axios from "axios"
import { API_BASE } from "../../config/appConfig"

export default {

  data() {

    const validateConfirmPassword = (rule, value, callback) => {
      if (value !== this.passwordForm.newPassword) {
        callback(new Error("两次输入的新密码不一致"))
        return
      }

      callback()
    }

    return {

      username: "",
      user: {},
      profileDialogVisible: false,
      passwordDialogVisible: false,
      profilePasswordVisible: false,
      teamOptions: [
        "星际光",
        "成像光",
        "空间光",
        "光电封装"
      ],
      profileForm: {
        username: "",
        team: "",
        engineer: "",
        email: "",
        password: "",
        permissions: 0,
        category: "技师"
      },
      passwordForm: {
        oldPassword: "",
        newPassword: "",
        confirmPassword: ""
      },
      passwordRules: {
        oldPassword: [
          { required: true, message: "请输入原密码", trigger: "blur" }
        ],
        newPassword: [
          { required: true, message: "请输入新密码", trigger: "blur" },
          { min: 6, message: "新密码至少6位", trigger: "blur" }
        ],
        confirmPassword: [
          { required: true, message: "请再次输入新密码", trigger: "blur" },
          { validator: validateConfirmPassword, trigger: "blur" }
        ]
      }

    }

  },

  created() {

    // 读取本地用户信息
    const user = localStorage.getItem("user")

    if (user) {

      const userInfo = JSON.parse(user)

      this.user = userInfo
      this.username = userInfo.username
      this.profileForm = {
        username: userInfo.username || "",
        team: userInfo.team || "",
        engineer: userInfo.engineer || "",
        email: userInfo.email || "",
        password: "",
        permissions: userInfo.permissions || 0,
        category: userInfo.category || "技师"
      }

    }

    this.fetchTeamOptions()

  },

  computed: {
    canEditProfile() {
      return Number(this.user.permissions) === 1
    }
  },

  methods: {
    fetchTeamOptions() {
      axios.get(`${API_BASE}/user/team_engineers`).then(res => {
        if (res.data.code === 200) {
          this.teamOptions = ["星际光", "成像光", "空间光", "光电封装"]
        }
      }).catch(() => {})
    },

    openProfileDialog() {

      this.profileDialogVisible = true

      axios.get(
        `${API_BASE}/user/profile/${encodeURIComponent(this.username)}`
      ).then(res => {
        if (res.data.code === 200) {
          this.profileForm = res.data.data
          this.user = Object.assign({}, this.user, {
            permissions: res.data.data.permissions
          })
        } else {
          this.$message.error(res.data.msg)
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("服务器连接失败")
      })

    },

    submitProfile() {
      if (!this.canEditProfile) {
        this.$message.warning("普通用户个人中心仅支持查看")
        return
      }

      axios.post(
        `${API_BASE}/user/profile/update`,
        this.profileForm
      ).then(res => {
        if (res.data.code === 200) {
          const user = JSON.parse(localStorage.getItem("user") || "{}")
          const data = Object.assign({}, res.data.data)

          localStorage.setItem(
            "user",
            JSON.stringify(Object.assign({}, user, data))
          )
          this.user = Object.assign({}, this.user, data)

          this.$message.success(res.data.msg)
          this.profileDialogVisible = false
        } else {
          this.$message.error(res.data.msg)
        }
      }).catch(err => {
        console.log(err)
        this.$message.error("服务器连接失败")
      })

    },

    resetProfileForm() {

      const user = JSON.parse(localStorage.getItem("user") || "{}")

      this.profileForm = {
        username: user.username || this.username,
        team: user.team || "",
        engineer: user.engineer || "",
        email: user.email || "",
        password: "",
        permissions: user.permissions || 0,
        category: user.category || "技师"
      }

      this.profilePasswordVisible = false

    },

    submitPassword() {

      this.$refs.passwordForm.validate(valid => {
        if (!valid) {
          return
        }

        axios.post(
          `${API_BASE}/user/update_password`,
          {
            username: this.username,
            oldPassword: this.passwordForm.oldPassword,
            newPassword: this.passwordForm.newPassword
          }
        ).then(res => {
          if (res.data.code === 200) {
            this.$message.success(res.data.msg)
            this.passwordDialogVisible = false
            localStorage.removeItem("user")
            this.$router.push("/login")
          } else {
            this.$message.error(res.data.msg)
          }
        }).catch(err => {
          console.log(err)
          this.$message.error("服务器连接失败")
        })
      })

    },

    resetPasswordForm() {

      this.passwordForm = {
        oldPassword: "",
        newPassword: "",
        confirmPassword: ""
      }

      if (this.$refs.passwordForm) {
        this.$refs.passwordForm.clearValidate()
      }

    },

    // =========================
    // 退出登录
    // =========================
    logout() {

      // 删除用户信息
      localStorage.removeItem("user")

      // 提示
      this.$message.success("退出成功")

      // 跳转登录页
      this.$router.push("/login")

    }

  }

}

</script>

<style scoped>

.header {

  height: 100%;

  display: flex;

  justify-content: flex-end;

  align-items: center;

  padding: 0 20px;

  background: white;
}

.right {

  cursor: pointer;
}

</style>
