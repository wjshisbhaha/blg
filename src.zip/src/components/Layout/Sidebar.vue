<template>
  <div class="sidebar">

    <!-- LOGO -->
    <div class="logo">
      台账管理系统
    </div>

    <el-menu
      background-color="#304156"
      text-color="#fff"
      active-text-color="#409EFF"
      router
      unique-opened
      :default-active="$route.fullPath"
    >

      <el-menu-item index="/dashboard">
        <i class="el-icon-s-home"></i>
        <span slot="title">物料管理</span>
      </el-menu-item>

      <el-menu-item index="/prototype/manage">
        <i class="el-icon-monitor"></i>
        <span slot="title">样机管理</span>
      </el-menu-item>

      <!-- 管理员菜单 -->
      <el-submenu
        v-if="Number(user.permissions) === 1"
        index="3"
      >

        <template slot="title">
          <i class="el-icon-user"></i>
          <span>用户管理</span>
        </template>

        <el-menu-item index="/user/list">
          用户列表
        </el-menu-item>

      </el-submenu>
      <el-menu-item index="/asset/inventory">
        <i class="el-icon-s-check"></i>
        <span slot="title">盘点管理</span>
      </el-menu-item>

      <el-menu-item index="/project/resource">
        <i class="el-icon-folder-opened"></i>
        <span slot="title">项目管理</span>
      </el-menu-item>

      <el-menu-item index="/asset/catalog">
        <i class="el-icon-collection"></i>
        <span slot="title">系统管理</span>
      </el-menu-item>

    </el-menu>

  </div>
</template>

<script>
export default {

  data() {
    return {
      user: {}
    }
  },

  created() {

    // 读取本地登录信息
    const user = localStorage.getItem("user")

    if (user) {
      this.user = JSON.parse(user)
    }

  }

}
</script>

<style scoped>

.sidebar {
  height: 100vh;
  background: #304156;
}

.logo {
  height: 60px;
  line-height: 60px;
  text-align: center;
  color: white;
  font-size: 20px;
  font-weight: bold;
  border-bottom: 1px solid #45566c;
}

.el-menu {
  border-right: none;
}

</style>
